#!/bin/bash

# StudyMate IBM Granite AI Service Startup Script

echo "🚀 Starting StudyMate with IBM Granite AI..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip3."
    exit 1
fi

# Install Python dependencies
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

# Create a virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "🐍 Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Install dependencies in virtual environment
echo "📦 Installing dependencies in virtual environment..."
pip install -r requirements.txt

# Function to cleanup background processes
cleanup() {
    echo "🛑 Stopping services..."
    kill $PYTHON_PID 2>/dev/null
    kill $NODE_PID 2>/dev/null
    exit 0
}

# Trap cleanup function on script exit
trap cleanup SIGINT SIGTERM

# Start Python IBM Granite AI service in background
echo "🤖 Starting IBM Granite AI service on port 5000..."
python python_ai_service.py &
PYTHON_PID=$!

# Wait a moment for Python service to start
sleep 3

# Check if Python service is running
if kill -0 $PYTHON_PID 2>/dev/null; then
    echo "✅ IBM Granite AI service started successfully (PID: $PYTHON_PID)"
else
    echo "❌ Failed to start IBM Granite AI service"
    exit 1
fi

# Start Node.js development server
echo "🌐 Starting Node.js development server..."
npm run dev &
NODE_PID=$!

# Wait a moment for Node.js service to start
sleep 3

# Check if Node.js service is running
if kill -0 $NODE_PID 2>/dev/null; then
    echo "✅ Node.js development server started successfully (PID: $NODE_PID)"
else
    echo "❌ Failed to start Node.js development server"
    kill $PYTHON_PID 2>/dev/null
    exit 1
fi

echo ""
echo "🎉 StudyMate with IBM Granite AI is now running!"
echo "📚 Main application: http://localhost:8080"
echo "🤖 IBM Granite AI service: http://localhost:5000"
echo "🧪 API test page: http://localhost:8080/api-test.html"
echo ""
echo "Press Ctrl+C to stop all services"

# Wait for services to run
wait
