# StudyMate Troubleshooting Guide

## 🐛 Common Issues and Solutions

### 1. **UUID Package Not Found Error**

**Error Message:**

```
Error [ERR_MODULE_NOT_FOUND]: Cannot find package 'uuid' imported from vite.config.ts
```

**Root Cause:**
Vite tries to bundle server-side dependencies during development, but some packages like `uuid` should remain external.

**Solution:**
✅ **Fixed in this project** - Added server dependencies to external list in `vite.config.server.ts`:

```typescript
rollupOptions: {
  external: [
    // External dependencies that should not be bundled
    "express",
    "cors",
    "uuid",          // ✅ Added
    "multer",        // ✅ Added
    "dotenv",        // ✅ Added
    "pdfjs-dist",    // ✅ Added
    "zod",           // ✅ Added
  ],
}
```

Also added to main `vite.config.ts`:

```typescript
optimizeDeps: {
  exclude: ["uuid", "multer", "pdfjs-dist"],
},
```

### 2. **Port Already in Use**

**Error Message:**

```
Port 8080 is already in use
```

**Solutions:**

```bash
# Option A: Kill process on port 8080
npx kill-port 8080

# Option B: Use different port
PORT=3000 npm run dev

# Option C: Find and kill process manually (Windows)
netstat -ano | findstr :8080
taskkill /PID <PID_NUMBER> /F

# Option C: Find and kill process manually (Mac/Linux)
lsof -ti:8080 | xargs kill -9
```

### 3. **Dependencies Installation Issues**

**Error Messages:**

```
npm ERR! network timeout
npm ERR! Cannot resolve dependency
```

**Solutions:**

```bash
# Option A: Clear npm cache
npm cache clean --force
npm install

# Option B: Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Option C: Use yarn instead of npm
npm install -g yarn
yarn install

# Option D: Use pnpm (recommended for this project)
npm install -g pnpm
pnpm install
```

### 4. **TypeScript Errors**

**Common Issues:**

```
Cannot find module '@/components/ui/button'
Property 'xyz' does not exist on type
```

**Solutions:**

```bash
# Restart TypeScript server in VS Code
Ctrl+Shift+P → "TypeScript: Restart TS Server"

# Check TypeScript version
Ctrl+Shift+P → "TypeScript: Select TypeScript Version" → "Use Workspace Version"

# Run type checking
npm run typecheck

# Clear TypeScript cache
rm -rf node_modules/.cache
```

### 5. **Vite Build Errors**

**Error Message:**

```
[vite]: Rollup failed to resolve import
```

**Solutions:**

```bash
# Clear Vite cache
rm -rf node_modules/.vite
npm run dev

# Clear dist folder
rm -rf dist
npm run build

# Check for circular dependencies
npm run typecheck
```

### 6. **File Upload Issues**

**Error Messages:**

```
Multer error: File too large
ENOENT: no such file or directory, open 'uploads/...'
```

**Solutions:**

```bash
# Create uploads directory
mkdir uploads

# Check file size limits in server/services/files.ts
# Current limit: 10MB per file, max 4 files

# Ensure proper file permissions
chmod 755 uploads/
```

### 7. **API Connection Issues**

**Error Messages:**

```
Failed to fetch
Network Error
```

**Solutions:**

```bash
# Check if backend server is running
curl http://localhost:8080/api/ping

# Restart development server
Ctrl+C (in terminal)
npm run dev

# Check for CORS issues (already configured)
# server/index.ts has cors() middleware

# Test specific endpoints
curl -X POST http://localhost:8080/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"text":"hello","language":"en"}'
```

### 8. **Voice Features Not Working**

**Issues:**

- Microphone not working
- Speech synthesis not working

**Solutions:**

```typescript
// Check browser support
if (!("webkitSpeechRecognition" in window)) {
  console.log("Speech recognition not supported");
}

if (!("speechSynthesis" in window)) {
  console.log("Speech synthesis not supported");
}

// Allow microphone permissions in browser
// Chrome: Settings → Privacy → Site Settings → Microphone
// Firefox: Preferences → Privacy → Permissions → Microphone
```

### 9. **LocalStorage Issues**

**Error Messages:**

```
QuotaExceededError
Cannot read property of undefined
```

**Solutions:**

```javascript
// Clear StudyMate data
localStorage.removeItem("studymate_history");
localStorage.removeItem("studymate_auth");
localStorage.removeItem("studymate-theme");
localStorage.removeItem("studymate-language");

// Check available storage
console.log("LocalStorage quota:", navigator.storage?.estimate());
```

### 10. **Theme/UI Issues**

**Issues:**

- Dark mode not working
- Components not styled properly
- Tailwind classes not applied

**Solutions:**

```bash
# Restart Tailwind watcher
npm run dev

# Check Tailwind config
npx tailwindcss --init

# Clear browser cache
Ctrl+Shift+R (hard refresh)

# Check if CSS is loaded
# Open DevTools → Network → Check for .css files
```

## 🛠 Debugging Commands

### **Development:**

```bash
# Start with debugging
DEBUG=* npm run dev

# Type checking only
npm run typecheck

# Format code
npm run format.fix

# Build without running
npm run build
```

### **VS Code Debugging:**

```bash
# Debug frontend: Press F5 → "Debug Frontend (Chrome)"
# Debug backend: Press F5 → "Debug Backend (Node.js)"
# Debug both: Press F5 → "Debug Full Application"
```

### **Network Debugging:**

```bash
# Test API endpoints
curl http://localhost:8080/api/ping
curl http://localhost:8080/api/files/default-user

# Check server logs
# Look at VS Code terminal where npm run dev is running
```

## 📋 Health Check Commands

Run these to verify everything is working:

```bash
# 1. Check Node.js version (should be 18+)
node --version

# 2. Check npm version
npm --version

# 3. Install dependencies
npm install

# 4. Type check
npm run typecheck

# 5. Build test
npm run build

# 6. Start development server
npm run dev

# 7. Test in browser
# Navigate to http://localhost:8080
# Try uploading a file
# Try asking a question
# Check browser console for errors
```

## 🚨 Emergency Recovery

If nothing works, try this complete reset:

```bash
# 1. Backup your work
git add .
git commit -m "Backup before reset"

# 2. Clean everything
rm -rf node_modules
rm -rf dist
rm -rf uploads
rm package-lock.json

# 3. Reinstall
npm install

# 4. Restart
npm run dev
```

## 📞 Getting Help

1. **Check browser console** for JavaScript errors
2. **Check VS Code terminal** for server errors
3. **Check network tab** in DevTools for failed API calls
4. **Restart VS Code** if IntelliSense stops working
5. **Clear browser cache** if UI looks broken
6. **Restart computer** if all else fails 😅

Happy coding! 🚀
