import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProviders } from "@/lib/contexts";
import Header from "@/components/Header";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Welcome from "./pages/Welcome";
import Home from "./pages/Home";
import AskQuestions from "./pages/AskQuestions";
import UploadPicture from "./pages/UploadPicture";
import UploadPDF from "./pages/UploadPDF";
import QuizPage from "./pages/QuizPage";
import QAGenerator from "./pages/QAGenerator";
import History from "./pages/History";
import Schedule from "./pages/Schedule";
import RatingFeedback from "./pages/RatingFeedback";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  try {
    return (
      <QueryClientProvider client={queryClient}>
        <AppProviders>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Header />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/auth" element={<Auth />} />
                <Route path="/welcome" element={<Welcome />} />
                <Route path="/home" element={<Home />} />
                <Route path="/upload-picture" element={<UploadPicture />} />
                <Route path="/upload-pdf" element={<UploadPDF />} />
                <Route path="/ask-questions" element={<AskQuestions />} />
                <Route path="/qa-generator" element={<QAGenerator />} />
                <Route path="/tests" element={<QuizPage />} />
                <Route path="/history" element={<History />} />
                <Route path="/schedule" element={<Schedule />} />
                <Route path="/chat" element={<Placeholder />} />
                <Route path="/rating" element={<RatingFeedback />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </AppProviders>
      </QueryClientProvider>
    );
  } catch (error) {
    console.error("App initialization error:", error);
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">StudyMate</h1>
          <p className="text-muted-foreground">Loading application...</p>
        </div>
      </div>
    );
  }
};

createRoot(document.getElementById("root")!).render(<App />);
