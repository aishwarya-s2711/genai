import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/lib/contexts";
import {
  FileText,
  Upload,
  MessageSquare,
  Bot,
  User,
  Loader2,
  X,
  Share2,
  Send,
  Brain,
  Award,
  BookOpen,
  Download,
  Eye,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Mic,
  MicOff,
  Volume2,
} from "lucide-react";

interface UploadedPDF {
  id: string;
  originalName: string;
  size: number;
  uploadDate: string;
  type: "pdf";
  hasContent: boolean;
  summary?: string;
}

interface ChatMessage {
  id: string;
  type: "user" | "bot";
  content: string;
  timestamp: Date;
  answerLength?: "1" | "2" | "5";
  pdfIds?: string[];
}

export default function UploadPDF() {
  const navigate = useNavigate();
  const { language } = useLanguage();

  // State management
  const [uploadedPDFs, setUploadedPDFs] = useState<UploadedPDF[]>([]);
  const [selectedPDFs, setSelectedPDFs] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [answerLength, setAnswerLength] = useState<"1" | "2" | "5">("2");
  const [isLoading, setIsLoading] = useState(false);
  const [currentTab, setCurrentTab] = useState<
    "upload" | "summary" | "chat" | "quiz" | "qna"
  >("upload");
  const [pdfSummaries, setPdfSummaries] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load user files on mount
  useEffect(() => {
    loadUserFiles();
  }, []);

  // Auto-scroll messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Clear notifications after 5 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError(null);
        setSuccess(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  const loadUserFiles = async () => {
    try {
      const response = await fetch("/api/files/default-user");
      if (response.ok) {
        const data = await response.json();
        const pdfFiles = data.files?.filter((f: any) => f.type === "pdf") || [];
        setUploadedPDFs(pdfFiles);
      } else {
        console.warn("Failed to load files:", response.statusText);
      }
    } catch (error) {
      console.error("Failed to load files:", error);
      setError("Failed to load existing files");
    }
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    try {
      const files = Array.from(event.target.files || []);
      if (files.length === 0) return;

      // Validate files
      const pdfFiles = files.filter((file) => {
        if (file.type !== "application/pdf") {
          setError(
            `File ${file.name} is not a PDF. Please select PDF files only.`,
          );
          return false;
        }
        if (file.size > 10 * 1024 * 1024) {
          setError(
            `File ${file.name} is too large. Please select files under 10MB.`,
          );
          return false;
        }
        return true;
      });

      if (pdfFiles.length === 0) return;

      // Check total file limit
      const remainingSlots = 4 - uploadedPDFs.length;
      if (remainingSlots <= 0) {
        setError(
          "Maximum 4 PDF files allowed. Please remove some files first.",
        );
        return;
      }

      const filesToUpload = pdfFiles.slice(0, remainingSlots);
      if (pdfFiles.length > remainingSlots) {
        setError(
          `Only ${remainingSlots} more files can be uploaded. Maximum is 4 total.`,
        );
      }

      setIsUploading(true);
      setError(null);

      const formData = new FormData();
      filesToUpload.forEach((file) => {
        formData.append("files", file);
      });
      formData.append("userId", "default-user");

      const response = await fetch("/api/files/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        await loadUserFiles();

        // Generate summaries for new PDFs
        for (const file of data.files) {
          if (file.type === "pdf") {
            await generateSummary(file.id, file.originalName);
          }
        }

        // Add upload message
        const uploadMessage: ChatMessage = {
          id: Date.now().toString(),
          type: "bot",
          content:
            language === "ta"
              ? `✅ ${data.files.length} PDF கோப்புகள் வெற்றிகரமாக பதிவேற்றப்பட்டன! இப்போது நீங்கள் கேள்விகள் கேட்கலாம்.`
              : `✅ ${data.files.length} PDF files uploaded successfully! You can now ask questions about them.`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, uploadMessage]);

        setSuccess(`Successfully uploaded ${data.files.length} PDF file(s)`);
        saveToHistory(
          "upload",
          `PDF Upload: ${data.files.length} files`,
          undefined,
          data.files.map((f: any) => f.originalName),
        );
        setCurrentTab("summary");
      } else {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Upload failed");
      }
    } catch (error) {
      console.error("Upload error:", error);
      setError(
        error instanceof Error ? error.message : "Failed to upload files",
      );
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const generateSummary = async (fileId: string, fileName: string) => {
    try {
      // Get file content
      const contentResponse = await fetch(`/api/files/default-user/${fileId}`);
      if (!contentResponse.ok) {
        console.warn("Failed to get file content for summary");
        return;
      }

      const contentData = await contentResponse.json();

      // Generate summary using AI
      const summaryResponse = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: "Generate a comprehensive summary",
          context: contentData.content,
          language: language,
          type: "explain",
        }),
      });

      if (summaryResponse.ok) {
        const summaryData = await summaryResponse.json();
        setPdfSummaries((prev) => ({
          ...prev,
          [fileId]:
            summaryData.response ||
            "Summary generation completed. You can ask questions about this PDF.",
        }));
      } else {
        // Fallback summary
        setPdfSummaries((prev) => ({
          ...prev,
          [fileId]: `📄 **${fileName}**\n\nThis PDF has been uploaded and processed. You can now:\n• Ask questions about its content\n• Generate quizzes\n• Create Q&A sessions\n• Get detailed explanations\n\nThe content is ready for analysis and educational assistance.`,
        }));
      }
    } catch (error) {
      console.error("Summary generation error:", error);
      // Provide fallback summary
      setPdfSummaries((prev) => ({
        ...prev,
        [fileId]: `📄 **${fileName}**\n\nPDF processed successfully. Content is available for questions and analysis.`,
      }));
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;
    if (uploadedPDFs.length === 0) {
      setError("Please upload PDF files first");
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
      answerLength,
      pdfIds: selectedPDFs,
    };

    setMessages((prev) => [...prev, userMessage]);
    const questionText = inputValue;
    setInputValue("");
    setIsLoading(true);
    setError(null);

    try {
      // Get combined content from selected PDFs or all PDFs
      let context = "";
      const pdfIds =
        selectedPDFs.length > 0
          ? selectedPDFs
          : uploadedPDFs.map((pdf) => pdf.id);

      if (pdfIds.length > 0) {
        const contextResponse = await fetch("/api/files/combined-content", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: "default-user",
            fileIds: pdfIds,
          }),
        });

        if (contextResponse.ok) {
          const contextData = await contextResponse.json();
          context = contextData.content || "";
        }
      }

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: questionText,
          context: context,
          language: language,
          answerLength: answerLength,
          type: "question",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const botMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: "bot",
          content:
            data.response ||
            "I apologize, but I could not generate a response. Please try again.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, botMessage]);

        saveToHistory("question", questionText, data.response);
      } else {
        throw new Error("Failed to get AI response");
      }
    } catch (error) {
      console.error("Chat error:", error);

      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content:
          language === "ta"
            ? `மன்னிக்கவும், உங்கள் கேள்விக்கு பதில் அளிக்க முடியவில்லை. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.`
            : `I apologize, but I couldn't answer your question right now. Please try again or rephrase your question.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      setError("Failed to get response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const generateQuiz = async () => {
    if (uploadedPDFs.length === 0) {
      setError("Please upload PDF files first");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const pdfIds =
        selectedPDFs.length > 0
          ? selectedPDFs
          : uploadedPDFs.map((pdf) => pdf.id);

      // Get combined content
      const contextResponse = await fetch("/api/files/combined-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "default-user",
          fileIds: pdfIds,
        }),
      });

      let context = "";
      if (contextResponse.ok) {
        const contextData = await contextResponse.json();
        context = contextData.content || "";
      }

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: "Generate a comprehensive quiz with multiple question types",
          context: context,
          language: language,
          type: "quiz",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const quizMessage: ChatMessage = {
          id: Date.now().toString(),
          type: "bot",
          content: `${language === "ta" ? "📝 உங்கள் PDF களிலிருந்து உருவாக்கப்பட்ட வினாடி வினா:" : "📝 Generated Quiz from your PDFs:"}\n\n${data.response}`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, quizMessage]);
        saveToHistory("quiz", "PDF-based Quiz", data.response);
        setCurrentTab("chat");
      } else {
        throw new Error("Quiz generation failed");
      }
    } catch (error) {
      console.error("Quiz generation failed:", error);
      setError("Failed to generate quiz. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const generateQA = async () => {
    if (uploadedPDFs.length === 0) {
      setError("Please upload PDF files first");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const pdfIds =
        selectedPDFs.length > 0
          ? selectedPDFs
          : uploadedPDFs.map((pdf) => pdf.id);

      const contextResponse = await fetch("/api/files/combined-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "default-user",
          fileIds: pdfIds,
        }),
      });

      let context = "";
      if (contextResponse.ok) {
        const contextData = await contextResponse.json();
        context = contextData.content || "";
      }

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: "Generate questions and answers from this content",
          context: context,
          language: language,
          type: "generate_qa",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const qaMessage: ChatMessage = {
          id: Date.now().toString(),
          type: "bot",
          content: `${language === "ta" ? "❓ உங்கள் PDF களிலிருந்து உருவாக்கப்பட்ட கேள்வி பதில்கள்:" : "❓ Generated Q&A from your PDFs:"}\n\n${data.response}`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, qaMessage]);
        saveToHistory("qa_generation", "PDF Q&A Generation", data.response);
        setCurrentTab("chat");
      } else {
        throw new Error("Q&A generation failed");
      }
    } catch (error) {
      console.error("Q&A generation failed:", error);
      setError("Failed to generate Q&A. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const saveToHistory = (
    type: string,
    title: string,
    content?: string,
    fileNames?: string[],
  ) => {
    try {
      const savedHistory = localStorage.getItem("studymate_history");
      const history = savedHistory ? JSON.parse(savedHistory) : [];

      const historyItem = {
        id: Date.now().toString(),
        type,
        title,
        content,
        timestamp: new Date().toISOString(),
        fileNames: fileNames || uploadedPDFs.map((pdf) => pdf.originalName),
        metadata: { source: "pdf_upload" },
      };

      const updatedHistory = [historyItem, ...history].slice(0, 100);
      localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
    } catch (error) {
      console.warn("Failed to save to history:", error);
    }
  };

  const shareContent = async () => {
    try {
      const shareData = {
        title: "StudyMate - PDF Analysis",
        text: `Check out my PDF analysis on StudyMate!\n\nPDFs: ${uploadedPDFs.length}\nQuestions: ${messages.filter((m) => m.type === "user").length}`,
        url: window.location.href,
      };

      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(
          `${shareData.title}\n${shareData.text}\n${shareData.url}`,
        );
        setSuccess("Content copied to clipboard!");
      }
    } catch (error) {
      console.error("Share failed:", error);
      setError("Sharing failed. Please try again.");
    }
  };

  const removePDF = async (pdfId: string) => {
    try {
      const response = await fetch(`/api/files/default-user/${pdfId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        setUploadedPDFs((prev) => prev.filter((pdf) => pdf.id !== pdfId));
        setSelectedPDFs((prev) => prev.filter((id) => id !== pdfId));
        setPdfSummaries((prev) => {
          const updated = { ...prev };
          delete updated[pdfId];
          return updated;
        });
        setMessages((prev) =>
          prev.filter((msg) => !msg.pdfIds?.includes(pdfId)),
        );
        setSuccess("PDF file removed successfully");
      } else {
        throw new Error("Failed to delete file");
      }
    } catch (error) {
      console.error("Delete error:", error);
      setError("Failed to remove PDF file");
    }
  };

  const togglePDFSelection = (pdfId: string) => {
    setSelectedPDFs((prev) =>
      prev.includes(pdfId)
        ? prev.filter((id) => id !== pdfId)
        : [...prev, pdfId],
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
              <FileText className="w-8 h-8 text-primary" />
              <span>
                {language === "ta"
                  ? "PDF பதிவேற்று மற்றும் பகுப்பாய்வு"
                  : "Upload & Analyze PDFs"}
              </span>
            </h1>
            <p className="text-muted-foreground">
              {language === "ta"
                ? "PDF கோப்புகளை பதிவேற்றி, AI பகுப்பாய்வு பெற்று, கேள்விகள் கேட்கவும்"
                : "Upload PDF files, get AI analysis, and ask questions about the content"}
            </p>
          </div>

          {/* Notifications */}
          {error && (
            <div className="mb-4 p-3 bg-red-100 dark:bg-red-900 border border-red-200 dark:border-red-800 rounded-lg flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
              <span className="text-red-800 dark:text-red-200 text-sm">
                {error}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setError(null)}
                className="ml-auto"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-100 dark:bg-green-900 border border-green-200 dark:border-green-800 rounded-lg flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span className="text-green-800 dark:text-green-200 text-sm">
                {success}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSuccess(null)}
                className="ml-auto"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className="flex flex-wrap space-x-2 mb-6">
            <Button
              variant={currentTab === "upload" ? "default" : "outline"}
              onClick={() => setCurrentTab("upload")}
              className="flex items-center space-x-2 mb-2"
            >
              <Upload className="w-4 h-4" />
              <span>{language === "ta" ? "பதிவேற்று" : "Upload"}</span>
            </Button>
            <Button
              variant={currentTab === "summary" ? "default" : "outline"}
              onClick={() => setCurrentTab("summary")}
              className="flex items-center space-x-2 mb-2"
              disabled={uploadedPDFs.length === 0}
            >
              <BookOpen className="w-4 h-4" />
              <span>{language === "ta" ? "சுருக்கம்" : "Summary"}</span>
            </Button>
            <Button
              variant={currentTab === "chat" ? "default" : "outline"}
              onClick={() => setCurrentTab("chat")}
              className="flex items-center space-x-2 mb-2"
              disabled={uploadedPDFs.length === 0}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{language === "ta" ? "கேள்வி பதில்" : "Q&A Chat"}</span>
            </Button>
            <Button
              variant={currentTab === "quiz" ? "default" : "outline"}
              onClick={() => setCurrentTab("quiz")}
              className="flex items-center space-x-2 mb-2"
              disabled={uploadedPDFs.length === 0}
            >
              <Award className="w-4 h-4" />
              <span>{language === "ta" ? "வினாடி வினா" : "Quiz"}</span>
            </Button>
            <Button
              variant={currentTab === "qna" ? "default" : "outline"}
              onClick={() => setCurrentTab("qna")}
              className="flex items-center space-x-2 mb-2"
              disabled={uploadedPDFs.length === 0}
            >
              <Brain className="w-4 h-4" />
              <span>
                {language === "ta" ? "கேள்வி உற்பத்தி" : "Q&A Generator"}
              </span>
            </Button>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Sidebar - PDF Files */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center space-x-2">
                      <FileText className="w-5 h-5" />
                      <span>
                        {language === "ta"
                          ? "பதிவேற்றப்பட்ட PDF கள்"
                          : "Uploaded PDFs"}
                      </span>
                    </span>
                    <Badge variant="secondary">{uploadedPDFs.length}/4</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Upload Button */}
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadedPDFs.length >= 4 || isUploading}
                    className="w-full"
                    variant="outline"
                  >
                    {isUploading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4 mr-2" />
                    )}
                    {language === "ta"
                      ? "புதிய PDF பதிவேற்றவும்"
                      : "Upload New PDFs"}
                  </Button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,application/pdf"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />

                  <Separator />

                  {/* PDF List */}
                  <div className="space-y-3">
                    {uploadedPDFs.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>
                          {language === "ta"
                            ? "இன்னும் PDF கள் பதிவேற்றப்படவில்லை"
                            : "No PDFs uploaded yet"}
                        </p>
                      </div>
                    ) : (
                      uploadedPDFs.map((pdf) => (
                        <div
                          key={pdf.id}
                          className={`relative border rounded-lg p-3 cursor-pointer transition-all ${
                            selectedPDFs.includes(pdf.id)
                              ? "ring-2 ring-primary bg-primary/5"
                              : "hover:shadow-md"
                          }`}
                          onClick={() => togglePDFSelection(pdf.id)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="text-sm font-medium truncate">
                                {pdf.originalName}
                              </p>
                              <div className="flex items-center justify-between mt-1">
                                <span className="text-xs text-muted-foreground">
                                  {(pdf.size / 1024).toFixed(1)} KB
                                </span>
                                <Badge variant="secondary" className="text-xs">
                                  {language === "ta"
                                    ? "செயலாக்கப்பட்டது"
                                    : "Processed"}
                                </Badge>
                              </div>
                            </div>
                            <Button
                              size="icon"
                              variant="destructive"
                              className="w-6 h-6 ml-2"
                              onClick={(e) => {
                                e.stopPropagation();
                                removePDF(pdf.id);
                              }}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {uploadedPDFs.length > 0 && (
                    <div className="space-y-2">
                      <Button
                        onClick={() =>
                          setSelectedPDFs(uploadedPDFs.map((pdf) => pdf.id))
                        }
                        variant="outline"
                        size="sm"
                        className="w-full"
                      >
                        {language === "ta"
                          ? "அனைத்தையும் தேர்ந்தெடுக்கவும்"
                          : "Select All"}
                      </Button>
                      <Button
                        onClick={() => setSelectedPDFs([])}
                        variant="outline"
                        size="sm"
                        className="w-full"
                      >
                        {language === "ta"
                          ? "அனைத்தையும் நீக்கவும்"
                          : "Clear Selection"}
                      </Button>
                      <Button
                        onClick={shareContent}
                        variant="outline"
                        size="sm"
                        className="w-full"
                      >
                        <Share2 className="w-4 h-4 mr-2" />
                        {language === "ta" ? "பகிர்வு" : "Share"}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Main Content Area */}
            <div className="lg:col-span-2">
              {currentTab === "upload" && (
                <Card className="h-[600px] flex flex-col items-center justify-center">
                  <CardContent className="text-center space-y-6">
                    <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                      <FileText className="w-12 h-12 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {language === "ta"
                          ? "உங்கள் PDF கோப்புகளை பதிவேற்றவும்"
                          : "Upload Your PDF Files"}
                      </h3>
                      <p className="text-muted-foreground max-w-md">
                        {language === "ta"
                          ? "பாடநூல்கள், குறிப்புகள் அல்லது ஆய்வு பொருட்களின் PDF கோப்புகளை பதிவேற்றவும். AI அவற்றை பகுப்பாய்வு செய்து கேள்விகளுக்கு பதில் அளிக்கும்."
                          : "Upload PDF files of textbooks, notes, or study materials. AI will analyze them and answer your questions."}
                      </p>
                    </div>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      size="lg"
                      disabled={uploadedPDFs.length >= 4}
                    >
                      <Upload className="w-5 h-5 mr-2" />
                      {language === "ta"
                        ? "PDF கோப்புகளை தேர்ந்தெடுக்கவும் (அதிகபட்சம் 4)"
                        : "Choose PDF Files (Max 4)"}
                    </Button>
                  </CardContent>
                </Card>
              )}

              {currentTab === "summary" && (
                <Card className="h-[600px]">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BookOpen className="w-5 h-5 text-primary" />
                      <span>
                        {language === "ta"
                          ? "PDF சுருக்கங்கள்"
                          : "PDF Summaries"}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[500px]">
                      <div className="space-y-4">
                        {uploadedPDFs.map((pdf) => (
                          <Card key={pdf.id} className="p-4">
                            <h4 className="font-semibold mb-2">
                              {pdf.originalName}
                            </h4>
                            <div className="text-sm text-muted-foreground whitespace-pre-wrap">
                              {pdfSummaries[pdf.id] || "Generating summary..."}
                            </div>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}

              {currentTab === "chat" && (
                <Card className="h-[600px] flex flex-col">
                  <CardHeader className="flex-shrink-0">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        <Bot className="w-5 h-5 text-primary" />
                        <span>
                          {language === "ta"
                            ? "AI உதவியாளர் அரட்டை"
                            : "AI Assistant Chat"}
                        </span>
                      </CardTitle>
                      <Select
                        value={answerLength}
                        onValueChange={(value: "1" | "2" | "5") =>
                          setAnswerLength(value)
                        }
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">
                            1 {language === "ta" ? "மதிப்பெண்" : "Mark"}
                          </SelectItem>
                          <SelectItem value="2">
                            2 {language === "ta" ? "மதிப்பெண்கள்" : "Marks"}
                          </SelectItem>
                          <SelectItem value="5">
                            5 {language === "ta" ? "மதிப்பெண்கள்" : "Marks"}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardHeader>

                  <CardContent className="flex-1 flex flex-col p-0">
                    <ScrollArea className="flex-1 p-4">
                      <div className="space-y-4">
                        {messages.length === 0 ? (
                          <div className="text-center text-muted-foreground py-8">
                            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>
                              {language === "ta"
                                ? "உங்கள் PDF களைப் பற்றி கேள்விகள் கேட்கவும்"
                                : "Ask questions about your PDFs"}
                            </p>
                          </div>
                        ) : (
                          messages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
                            >
                              <div
                                className={`max-w-[80%] rounded-lg p-3 ${
                                  message.type === "user"
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted"
                                }`}
                              >
                                <div className="flex items-start space-x-2">
                                  {message.type === "bot" ? (
                                    <Bot className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                                  ) : (
                                    <User className="w-5 h-5 flex-shrink-0 mt-0.5" />
                                  )}
                                  <div className="flex-1">
                                    <p className="text-sm whitespace-pre-wrap">
                                      {message.content}
                                    </p>
                                    <div className="flex items-center justify-between mt-2">
                                      <p className="text-xs opacity-70">
                                        {message.timestamp.toLocaleTimeString()}
                                      </p>
                                      {message.answerLength && (
                                        <Badge
                                          variant="secondary"
                                          className="text-xs"
                                        >
                                          {message.answerLength}{" "}
                                          {language === "ta"
                                            ? "மதிப்பெண்"
                                            : "mark"}
                                        </Badge>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))
                        )}

                        {isLoading && (
                          <div className="flex justify-start">
                            <div className="bg-muted rounded-lg p-3">
                              <div className="flex items-center space-x-2">
                                <Bot className="w-5 h-5 text-primary" />
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span className="text-sm">
                                  {language === "ta"
                                    ? "பகுப்பாய்வு செய்து கொண்டிருக்கிறது..."
                                    : "Analyzing..."}
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <div ref={messagesEndRef} />
                    </ScrollArea>

                    <div className="border-t p-4">
                      <div className="flex space-x-2">
                        <Input
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          onKeyPress={(e) =>
                            e.key === "Enter" &&
                            !e.shiftKey &&
                            handleSendMessage()
                          }
                          placeholder={
                            language === "ta"
                              ? "உங்கள் PDF களைப் பற்றி கேள்வி கேட்கவும்..."
                              : "Ask a question about your PDFs..."
                          }
                          disabled={isLoading || uploadedPDFs.length === 0}
                          className="flex-1"
                        />
                        <Button
                          onClick={handleSendMessage}
                          disabled={
                            !inputValue.trim() ||
                            isLoading ||
                            uploadedPDFs.length === 0
                          }
                          size="icon"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {currentTab === "quiz" && (
                <Card className="h-[600px] flex flex-col items-center justify-center">
                  <CardContent className="text-center space-y-6">
                    <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
                      <Award className="w-12 h-12 text-accent" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {language === "ta"
                          ? "PDF அடிப்படையிலான வினாடி வினா"
                          : "PDF-Based Quiz"}
                      </h3>
                      <p className="text-muted-foreground max-w-md">
                        {language === "ta"
                          ? "உங்கள் பதிவேற்றப்பட்ட PDF களிலிருந்து AI-உருவாக்கிய வினாடி வினா உருவாக்கவும்."
                          : "Generate AI-powered quiz questions based on your uploaded PDFs."}
                      </p>
                    </div>
                    <Button
                      onClick={generateQuiz}
                      size="lg"
                      disabled={uploadedPDFs.length === 0 || isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      ) : (
                        <Brain className="w-5 h-5 mr-2" />
                      )}
                      {language === "ta"
                        ? "வினாடி வினா உருவாக்கவும்"
                        : "Generate Quiz"}
                    </Button>
                  </CardContent>
                </Card>
              )}

              {currentTab === "qna" && (
                <Card className="h-[600px] flex flex-col items-center justify-center">
                  <CardContent className="text-center space-y-6">
                    <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                      <Brain className="w-12 h-12 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {language === "ta"
                          ? "கேள்வி பதில் உற்பத்தியாளர்"
                          : "Q&A Generator"}
                      </h3>
                      <p className="text-muted-foreground max-w-md">
                        {language === "ta"
                          ? "உங்கள் PDF களிலிருந்து கல்வி கேள்விகள் மற்றும் பதில்களை உருவாக்கவும்."
                          : "Generate educational questions and answers from your PDF content."}
                      </p>
                    </div>
                    <Button
                      onClick={generateQA}
                      size="lg"
                      disabled={uploadedPDFs.length === 0 || isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      ) : (
                        <Brain className="w-5 h-5 mr-2" />
                      )}
                      {language === "ta"
                        ? "கேள்வி பதில் உருவாக்கவும்"
                        : "Generate Q&A"}
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
