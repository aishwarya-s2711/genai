import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLanguage } from "@/lib/contexts";
import {
  Calendar,
  Clock,
  FileText,
  Plus,
  Bell,
  CheckCircle,
  AlertCircle,
  Trash2,
  Edit,
  Play,
  Pause,
  RotateCcw,
  Target,
  TrendingUp,
} from "lucide-react";

interface ScheduledTask {
  id: string;
  title: string;
  description: string;
  fileId?: string;
  fileName?: string;
  startDate: Date;
  endDate: Date;
  dailyGoal: number;
  currentProgress: number;
  status: "pending" | "active" | "completed" | "overdue";
  notifications: boolean;
  createdAt: Date;
  completedAt?: Date;
}

interface Notification {
  id: string;
  taskId: string;
  title: string;
  message: string;
  type: "reminder" | "deadline" | "milestone" | "completion";
  timestamp: Date;
  read: boolean;
}

export default function Schedule() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();

  const [tasks, setTasks] = useState<ScheduledTask[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [availableFiles, setAvailableFiles] = useState<any[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingTask, setEditingTask] = useState<ScheduledTask | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    fileId: "",
    startDate: "",
    endDate: "",
    dailyGoal: 1,
    notifications: true,
  });

  useEffect(() => {
    loadTasks();
    loadNotifications();
    loadAvailableFiles();
    setupNotificationChecker();
  }, []);

  const loadTasks = () => {
    try {
      const saved = localStorage.getItem("studymate_scheduled_tasks");
      if (saved) {
        const parsed = JSON.parse(saved);
        const tasksWithDates = parsed.map((task: any) => ({
          ...task,
          startDate: new Date(task.startDate),
          endDate: new Date(task.endDate),
          createdAt: new Date(task.createdAt),
          completedAt: task.completedAt
            ? new Date(task.completedAt)
            : undefined,
        }));
        setTasks(tasksWithDates);
        updateTaskStatuses(tasksWithDates);
      }
    } catch (error) {
      console.error("Failed to load tasks:", error);
    }
  };

  const loadNotifications = () => {
    try {
      const saved = localStorage.getItem("studymate_notifications");
      if (saved) {
        const parsed = JSON.parse(saved);
        setNotifications(
          parsed.map((n: any) => ({
            ...n,
            timestamp: new Date(n.timestamp),
          })),
        );
      }
    } catch (error) {
      console.error("Failed to load notifications:", error);
    }
  };

  const loadAvailableFiles = async () => {
    try {
      const response = await fetch("/api/files/default-user");
      if (response.ok) {
        const data = await response.json();
        setAvailableFiles(data.files);
      }
    } catch (error) {
      console.error("Failed to load files:", error);
    }
  };

  const setupNotificationChecker = () => {
    // Check for notifications every minute
    const interval = setInterval(() => {
      checkForNotifications();
    }, 60000);

    return () => clearInterval(interval);
  };

  const updateTaskStatuses = (tasksToUpdate: ScheduledTask[]) => {
    const now = new Date();
    const updatedTasks = tasksToUpdate.map((task) => {
      let status = task.status;

      if (task.status === "completed") return task;

      if (now < task.startDate) {
        status = "pending";
      } else if (now >= task.startDate && now <= task.endDate) {
        status = "active";
      } else if (now > task.endDate && task.currentProgress < 100) {
        status = "overdue";
      }

      return { ...task, status };
    });

    if (JSON.stringify(updatedTasks) !== JSON.stringify(tasksToUpdate)) {
      setTasks(updatedTasks);
      localStorage.setItem(
        "studymate_scheduled_tasks",
        JSON.stringify(updatedTasks),
      );
    }
  };

  const checkForNotifications = () => {
    const now = new Date();
    tasks.forEach((task) => {
      if (!task.notifications || task.status === "completed") return;

      // Daily reminder
      const lastNotification = notifications
        .filter((n) => n.taskId === task.id && n.type === "reminder")
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];

      const hoursSinceLastReminder = lastNotification
        ? (now.getTime() - lastNotification.timestamp.getTime()) /
          (1000 * 60 * 60)
        : 24;

      if (hoursSinceLastReminder >= 24 && task.status === "active") {
        createNotification(
          task.id,
          "reminder",
          language === "ta" ? "दैनिक रिमाइंडर" : "Daily Reminder",
          language === "ta"
            ? `आपका अध्ययन लक्ष्य: ${task.title}`
            : `Your study goal: ${task.title}`,
        );
      }

      // Deadline warning (1 day before)
      const timeUntilDeadline = task.endDate.getTime() - now.getTime();
      const daysUntilDeadline = timeUntilDeadline / (1000 * 60 * 60 * 24);

      if (daysUntilDeadline <= 1 && daysUntilDeadline > 0) {
        const hasDeadlineWarning = notifications.some(
          (n) => n.taskId === task.id && n.type === "deadline",
        );

        if (!hasDeadlineWarning) {
          createNotification(
            task.id,
            "deadline",
            language === "ta" ? "डेडलाइन चेतावनी" : "Deadline Warning",
            language === "ta"
              ? `${task.title} कल समाप्त हो रहा है!`
              : `${task.title} is due tomorrow!`,
          );
        }
      }
    });
  };

  const createNotification = (
    taskId: string,
    type: Notification["type"],
    title: string,
    message: string,
  ) => {
    const notification: Notification = {
      id: Date.now().toString(),
      taskId,
      title,
      message,
      type,
      timestamp: new Date(),
      read: false,
    };

    const updatedNotifications = [notification, ...notifications];
    setNotifications(updatedNotifications);
    localStorage.setItem(
      "studymate_notifications",
      JSON.stringify(updatedNotifications),
    );

    // Show browser notification if supported
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, {
        body: message,
        icon: "/favicon.ico",
      });
    }
  };

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission();
      return permission === "granted";
    }
    return false;
  };

  const createTask = async () => {
    if (!formData.title.trim() || !formData.startDate || !formData.endDate) {
      alert(
        language === "ta"
          ? "कृपया सभी आवश्य��� फ़ील्ड भरें"
          : "Please fill all required fields",
      );
      return;
    }

    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);

    if (endDate <= startDate) {
      alert(
        language === "ta"
          ? "समाप्ति तिथि शुरुआती तिथि के बाद होनी चाहिए"
          : "End date must be after start date",
      );
      return;
    }

    const selectedFile = availableFiles.find((f) => f.id === formData.fileId);

    const newTask: ScheduledTask = {
      id: Date.now().toString(),
      title: formData.title,
      description: formData.description,
      fileId: formData.fileId || undefined,
      fileName: selectedFile?.originalName,
      startDate,
      endDate,
      dailyGoal: formData.dailyGoal,
      currentProgress: 0,
      status: "pending",
      notifications: formData.notifications,
      createdAt: new Date(),
    };

    const updatedTasks = [newTask, ...tasks];
    setTasks(updatedTasks);
    localStorage.setItem(
      "studymate_scheduled_tasks",
      JSON.stringify(updatedTasks),
    );

    // Request notification permission if notifications are enabled
    if (formData.notifications) {
      await requestNotificationPermission();
    }

    // Save to history
    saveToHistory(
      "schedule_created",
      `Created schedule: ${formData.title}`,
      formData.description,
    );

    // Reset form
    setFormData({
      title: "",
      description: "",
      fileId: "",
      startDate: "",
      endDate: "",
      dailyGoal: 1,
      notifications: true,
    });
    setShowCreateForm(false);
  };

  const updateTaskProgress = (taskId: string, progress: number) => {
    const updatedTasks = tasks.map((task) => {
      if (task.id === taskId) {
        const newProgress = Math.min(100, Math.max(0, progress));
        const updatedTask = {
          ...task,
          currentProgress: newProgress,
          status: newProgress === 100 ? "completed" : task.status,
          completedAt: newProgress === 100 ? new Date() : undefined,
        };

        // Create completion notification
        if (newProgress === 100 && task.currentProgress < 100) {
          createNotification(
            taskId,
            "completion",
            language === "ta" ? "बधाई!" : "Congratulations!",
            language === "ta"
              ? `आपने ${task.title} पूरा कर लिया है!`
              : `You have completed ${task.title}!`,
          );
        }

        return updatedTask;
      }
      return task;
    });

    setTasks(updatedTasks);
    localStorage.setItem(
      "studymate_scheduled_tasks",
      JSON.stringify(updatedTasks),
    );
  };

  const deleteTask = (taskId: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId);
    setTasks(updatedTasks);
    localStorage.setItem(
      "studymate_scheduled_tasks",
      JSON.stringify(updatedTasks),
    );

    // Remove related notifications
    const updatedNotifications = notifications.filter(
      (n) => n.taskId !== taskId,
    );
    setNotifications(updatedNotifications);
    localStorage.setItem(
      "studymate_notifications",
      JSON.stringify(updatedNotifications),
    );
  };

  const markNotificationAsRead = (notificationId: string) => {
    const updatedNotifications = notifications.map((n) =>
      n.id === notificationId ? { ...n, read: true } : n,
    );
    setNotifications(updatedNotifications);
    localStorage.setItem(
      "studymate_notifications",
      JSON.stringify(updatedNotifications),
    );
  };

  const saveToHistory = (type: string, title: string, content: string) => {
    try {
      const savedHistory = localStorage.getItem("studymate_history");
      const history = savedHistory ? JSON.parse(savedHistory) : [];

      const historyItem = {
        id: Date.now().toString(),
        type,
        title,
        content,
        timestamp: new Date().toISOString(),
        metadata: { source: "schedule" },
      };

      const updatedHistory = [historyItem, ...history].slice(0, 100);
      localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
    } catch (error) {
      console.error("Failed to save to history:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-blue-100 text-blue-800";
      case "active":
        return "bg-green-100 text-green-800";
      case "completed":
        return "bg-purple-100 text-purple-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "active":
        return <Play className="w-4 h-4" />;
      case "completed":
        return <CheckCircle className="w-4 h-4" />;
      case "overdue":
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const unreadNotifications = notifications.filter((n) => !n.read);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
                <Calendar className="w-8 h-8 text-primary" />
                <span>
                  {language === "ta" ? "अध्ययन अनुसूची" : "Study Schedule"}
                </span>
              </h1>
              <p className="text-muted-foreground">
                {language === "ta"
                  ? "अपनी पढ़ाई को व्यवस्थित करें और लक्ष्यों को ट्रैक करें"
                  : "Organize your study sessions and track your learning goals"}
              </p>
            </div>
            <div className="flex items-center space-x-3">
              {unreadNotifications.length > 0 && (
                <div className="relative">
                  <Bell className="w-6 h-6 text-primary" />
                  <Badge className="absolute -top-2 -right-2 w-5 h-5 rounded-full p-0 flex items-center justify-center">
                    {unreadNotifications.length}
                  </Badge>
                </div>
              )}
              <Button onClick={() => setShowCreateForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                {language === "ta" ? "नया शेड्यूल" : "New Schedule"}
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-4 gap-6">
            {/* Task List */}
            <div className="lg:col-span-3 space-y-6">
              {/* Active Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="w-5 h-5" />
                    <span>
                      {language === "ta" ? "सक्रिय कार्य" : "Active Tasks"}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {tasks.filter((task) => task.status === "active").length ===
                  0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>
                        {language === "ta"
                          ? "कोई सक्रिय कार्य नहीं"
                          : "No active tasks"}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tasks
                        .filter((task) => task.status === "active")
                        .map((task) => (
                          <div key={task.id} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center space-x-3">
                                <Badge className={getStatusColor(task.status)}>
                                  {getStatusIcon(task.status)}
                                  <span className="ml-1">{task.status}</span>
                                </Badge>
                                <h3 className="font-semibold">{task.title}</h3>
                                {task.fileName && (
                                  <Badge variant="outline" className="text-xs">
                                    <FileText className="w-3 h-3 mr-1" />
                                    {task.fileName}
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setEditingTask(task)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => deleteTask(task.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>

                            <p className="text-sm text-muted-foreground mb-3">
                              {task.description}
                            </p>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span>
                                  {language === "ta" ? "प्रगति" : "Progress"}
                                </span>
                                <span>{task.currentProgress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-primary h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${task.currentProgress}%` }}
                                />
                              </div>
                            </div>

                            <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
                              <span>
                                {language === "ta" ? "शुरू" : "Start"}:{" "}
                                {task.startDate.toLocaleDateString()}
                              </span>
                              <span>
                                {language === "ta" ? "समाप्ति" : "End"}:{" "}
                                {task.endDate.toLocaleDateString()}
                              </span>
                            </div>

                            <div className="flex items-center space-x-2 mt-3">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  updateTaskProgress(
                                    task.id,
                                    task.currentProgress + 10,
                                  )
                                }
                                disabled={task.currentProgress >= 100}
                              >
                                +10%
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() =>
                                  updateTaskProgress(
                                    task.id,
                                    task.currentProgress + 25,
                                  )
                                }
                                disabled={task.currentProgress >= 100}
                              >
                                +25%
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateTaskProgress(task.id, 100)}
                                disabled={task.currentProgress >= 100}
                              >
                                {language === "ta" ? "पूर्ण" : "Complete"}
                              </Button>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* All Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {language === "ta" ? "सभी कार्य" : "All Tasks"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {tasks.map((task) => (
                      <div
                        key={task.id}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <Badge className={getStatusColor(task.status)}>
                            {getStatusIcon(task.status)}
                            <span className="ml-1">{task.status}</span>
                          </Badge>
                          <div>
                            <h4 className="font-medium">{task.title}</h4>
                            <p className="text-xs text-muted-foreground">
                              {task.startDate.toLocaleDateString()} -{" "}
                              {task.endDate.toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium">
                            {task.currentProgress}%
                          </span>
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full"
                              style={{ width: `${task.currentProgress}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Notifications */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell className="w-5 h-5" />
                    <span>
                      {language === "ta" ? "सूचनाएं" : "Notifications"}
                    </span>
                    {unreadNotifications.length > 0 && (
                      <Badge>{unreadNotifications.length}</Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {notifications.slice(0, 10).map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            notification.read
                              ? "bg-muted/30"
                              : "bg-primary/5 border-primary/20"
                          }`}
                          onClick={() =>
                            markNotificationAsRead(notification.id)
                          }
                        >
                          <h5 className="font-medium text-sm">
                            {notification.title}
                          </h5>
                          <p className="text-xs text-muted-foreground mt-1">
                            {notification.message}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {notification.timestamp.toLocaleString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>{language === "ta" ? "आंकड़े" : "Statistics"}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{tasks.length}</div>
                    <div className="text-xs text-muted-foreground">
                      {language === "ta" ? "कुल कार्य" : "Total Tasks"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {tasks.filter((t) => t.status === "completed").length}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === "ta" ? "पूर्ण" : "Completed"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {tasks.filter((t) => t.status === "active").length}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === "ta" ? "सक्रिय" : "Active"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Create Task Form Modal */}
          {showCreateForm && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <Card className="w-full max-w-md">
                <CardHeader>
                  <CardTitle>
                    {language === "ta"
                      ? "नया अध्ययन शेड्यूल"
                      : "New Study Schedule"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="task-title">
                      {language === "ta" ? "शीर्षक" : "Title"}
                    </Label>
                    <Input
                      id="task-title"
                      value={formData.title}
                      onChange={(e) =>
                        setFormData({ ...formData, title: e.target.value })
                      }
                      placeholder={
                        language === "ta" ? "कार्य का नाम..." : "Task name..."
                      }
                    />
                  </div>

                  <div>
                    <Label htmlFor="task-description">
                      {language === "ta" ? "विवरण" : "Description"}
                    </Label>
                    <Textarea
                      id="task-description"
                      value={formData.description}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          description: e.target.value,
                        })
                      }
                      placeholder={
                        language === "ta"
                          ? "कार्य का विवरण..."
                          : "Task description..."
                      }
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>
                      {language === "ta"
                        ? "PDF फ़ाइल (वैकल्पिक)"
                        : "PDF File (Optional)"}
                    </Label>
                    <Select
                      value={formData.fileId}
                      onValueChange={(value) =>
                        setFormData({ ...formData, fileId: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue
                          placeholder={
                            language === "ta" ? "फ़ाइल चुनें" : "Select file"
                          }
                        />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">
                          {language === "ta" ? "कोई फ़ाइल नहीं" : "No file"}
                        </SelectItem>
                        {availableFiles.map((file) => (
                          <SelectItem key={file.id} value={file.id}>
                            {file.originalName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="start-date">
                        {language === "ta" ? "प्रारंभ तिथि" : "Start Date"}
                      </Label>
                      <Input
                        id="start-date"
                        type="date"
                        value={formData.startDate}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            startDate: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="end-date">
                        {language === "ta" ? "समाप्ति तिथि" : "End Date"}
                      </Label>
                      <Input
                        id="end-date"
                        type="date"
                        value={formData.endDate}
                        onChange={(e) =>
                          setFormData({ ...formData, endDate: e.target.value })
                        }
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifications">
                      {language === "ta"
                        ? "सूचनाएं सक्षम करें"
                        : "Enable Notifications"}
                    </Label>
                    <input
                      id="notifications"
                      type="checkbox"
                      checked={formData.notifications}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          notifications: e.target.checked,
                        })
                      }
                      className="w-4 h-4"
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={createTask} className="flex-1">
                      {language === "ta" ? "शेड्यूल बनाएं" : "Create Schedule"}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowCreateForm(false)}
                    >
                      {language === "ta" ? "रद्द करें" : "Cancel"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
