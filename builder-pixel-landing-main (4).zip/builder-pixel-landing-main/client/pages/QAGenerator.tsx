import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/lib/contexts";
import {
  Brain,
  FileText,
  ImageIcon,
  Loader2,
  Share2,
  Download,
  RefreshCw,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

interface UploadedFile {
  id: string;
  originalName: string;
  type: "pdf" | "image";
  size: number;
  uploadDate: string;
}

interface GeneratedQA {
  id: string;
  question: string;
  answer: string;
  difficulty: "1" | "2" | "3" | "5";
  topic?: string;
  sourceFiles: string[];
  timestamp: Date;
}

export default function QAGenerator() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [generatedQAs, setGeneratedQAs] = useState<GeneratedQA[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState<
    "select" | "generate" | "review"
  >("select");

  useEffect(() => {
    loadUserFiles();
    loadGeneratedQAs();
  }, []);

  const loadUserFiles = async () => {
    try {
      const response = await fetch("/api/files/default-user");
      if (response.ok) {
        const data = await response.json();
        setFiles(data.files);
      }
    } catch (error) {
      console.error("Failed to load files:", error);
    }
  };

  const loadGeneratedQAs = () => {
    try {
      const saved = localStorage.getItem("studymate_generated_qa");
      if (saved) {
        const parsed = JSON.parse(saved);
        setGeneratedQAs(
          parsed.map((qa: any) => ({
            ...qa,
            timestamp: new Date(qa.timestamp),
          })),
        );
      }
    } catch (error) {
      console.error("Failed to load generated Q&As:", error);
    }
  };

  const saveGeneratedQAs = (qas: GeneratedQA[]) => {
    try {
      localStorage.setItem("studymate_generated_qa", JSON.stringify(qas));
    } catch (error) {
      console.error("Failed to save generated Q&As:", error);
    }
  };

  const generateQA = async () => {
    if (selectedFiles.length === 0) return;

    setIsGenerating(true);
    setCurrentStep("generate");

    try {
      // Get combined content from selected files
      const contextResponse = await fetch("/api/files/combined-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "default-user",
          fileIds: selectedFiles,
        }),
      });

      if (!contextResponse.ok) throw new Error("Failed to get file content");

      const contextData = await contextResponse.json();

      // Generate Q&As using AI
      const qaResponse = await fetch("/api/ai/generate-qa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: contextData.content,
          language: language,
          type: "generate_qa",
        }),
      });

      if (!qaResponse.ok) throw new Error("Failed to generate Q&A");

      const qaData = await qaResponse.json();
      const parsedQAs = parseQAResponse(qaData.response);

      // Add to existing Q&As
      const newQAs = [...parsedQAs, ...generatedQAs];
      setGeneratedQAs(newQAs);
      saveGeneratedQAs(newQAs);

      // Save to history
      saveToHistory();

      setCurrentStep("review");
    } catch (error) {
      console.error("Q&A generation error:", error);
      alert(language === "ta" ? "Q&A उत्पादन असफल" : "Q&A generation failed");
    } finally {
      setIsGenerating(false);
    }
  };

  const parseQAResponse = (response: string): GeneratedQA[] => {
    const qas: GeneratedQA[] = [];
    const lines = response.split("\n").filter((line) => line.trim());

    let currentQ = "";
    let currentA = "";
    let difficulty: "1" | "2" | "3" | "5" = "2";

    for (const line of lines) {
      if (line.match(/^Q\d+:|Question \d+:/i)) {
        // Save previous Q&A if exists
        if (currentQ && currentA) {
          qas.push({
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            question: currentQ,
            answer: currentA,
            difficulty,
            sourceFiles: selectedFiles.map((id) => {
              const file = files.find((f) => f.id === id);
              return file?.originalName || "Unknown";
            }),
            timestamp: new Date(),
          });
        }

        // Start new question
        currentQ = line.replace(/^Q\d+:|Question \d+:/i, "").trim();
        currentA = "";

        // Determine difficulty based on question complexity
        if (currentQ.length < 50) difficulty = "1";
        else if (currentQ.length < 100) difficulty = "2";
        else if (currentQ.includes("explain") || currentQ.includes("describe"))
          difficulty = "3";
        else if (currentQ.includes("analyze") || currentQ.includes("evaluate"))
          difficulty = "5";
      } else if (line.match(/^A\d+:|Answer \d+:/i)) {
        currentA = line.replace(/^A\d+:|Answer \d+:/i, "").trim();
      } else if (currentA) {
        // Continue building answer
        currentA += " " + line.trim();
      } else if (currentQ && !line.match(/^Q\d+:|^A\d+:/i)) {
        // Continue building question
        currentQ += " " + line.trim();
      }
    }

    // Save last Q&A
    if (currentQ && currentA) {
      qas.push({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        question: currentQ,
        answer: currentA,
        difficulty,
        sourceFiles: selectedFiles.map((id) => {
          const file = files.find((f) => f.id === id);
          return file?.originalName || "Unknown";
        }),
        timestamp: new Date(),
      });
    }

    return qas.length > 0
      ? qas
      : [
          {
            id: "sample_1",
            question:
              language === "ta"
                ? "यह एक नमूना प्रश्न है।"
                : "This is a sample question.",
            answer:
              language === "ta"
                ? "यह एक नमूना उत्तर है।"
                : "This is a sample answer.",
            difficulty: "2",
            sourceFiles: selectedFiles.map((id) => {
              const file = files.find((f) => f.id === id);
              return file?.originalName || "Unknown";
            }),
            timestamp: new Date(),
          },
        ];
  };

  const saveToHistory = () => {
    try {
      const savedHistory = localStorage.getItem("studymate_history");
      const history = savedHistory ? JSON.parse(savedHistory) : [];

      const historyItem = {
        id: Date.now().toString(),
        type: "qa_generated",
        title: `Generated Q&A from ${selectedFiles.length} files`,
        content: `Generated ${generatedQAs.length} question-answer pairs`,
        timestamp: new Date().toISOString(),
        fileNames: selectedFiles.map((id) => {
          const file = files.find((f) => f.id === id);
          return file?.originalName || "Unknown";
        }),
        metadata: {
          source: "qa_generator",
          questionCount: generatedQAs.length,
        },
      };

      const updatedHistory = [historyItem, ...history].slice(0, 100);
      localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
    } catch (error) {
      console.error("Failed to save to history:", error);
    }
  };

  const shareQAs = async () => {
    try {
      const qaText = generatedQAs
        .map(
          (qa, index) =>
            `Q${index + 1}: ${qa.question}\nA${index + 1}: ${qa.answer}\n`,
        )
        .join("\n");

      const shareData = {
        title: "StudyMate - Generated Q&A",
        text: `Generated Questions & Answers from StudyMate:\n\n${qaText}`,
        url: window.location.href,
      };

      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(
          `${shareData.title}\n${shareData.text}`,
        );
        alert(
          language === "ta" ? "Q&A कॉपी हो गया" : "Q&A copied to clipboard!",
        );
      }
    } catch (error) {
      console.error("Share failed:", error);
    }
  };

  const downloadQAs = () => {
    const qaText = generatedQAs
      .map(
        (qa, index) =>
          `Question ${index + 1} (${qa.difficulty} mark${qa.difficulty === "1" ? "" : "s"}):\n${qa.question}\n\nAnswer ${index + 1}:\n${qa.answer}\n\nSource: ${qa.sourceFiles.join(", ")}\n\n---\n\n`,
      )
      .join("");

    const blob = new Blob([qaText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "StudyMate_Generated_QA.txt";
    link.click();
    URL.revokeObjectURL(url);
  };

  const toggleFileSelection = (fileId: string) => {
    setSelectedFiles((prev) =>
      prev.includes(fileId)
        ? prev.filter((id) => id !== fileId)
        : [...prev, fileId],
    );
  };

  const resetGenerator = () => {
    setCurrentStep("select");
    setSelectedFiles([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
              <Brain className="w-8 h-8 text-primary" />
              <span>
                {language === "ta"
                  ? "स्वचालित Q&A जेनरेटर"
                  : "Automatic Q&A Generator"}
              </span>
            </h1>
            <p className="text-muted-foreground">
              {language === "ta"
                ? "आपकी अपलोड की गई फाइलों से बुद्धिमत्ता के साथ प्रश्न और उत्तर बनाएं"
                : "Intelligently generate questions and answers from your uploaded content"}
            </p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-4">
              <div
                className={`flex items-center space-x-2 ${currentStep === "select" ? "text-primary" : "text-muted-foreground"}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === "select" ? "bg-primary text-white" : "bg-muted"}`}
                >
                  1
                </div>
                <span>
                  {language === "ta" ? "फाइलें चुनें" : "Select Files"}
                </span>
              </div>
              <div className="w-8 h-0.5 bg-border"></div>
              <div
                className={`flex items-center space-x-2 ${currentStep === "generate" ? "text-primary" : "text-muted-foreground"}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === "generate" ? "bg-primary text-white" : "bg-muted"}`}
                >
                  2
                </div>
                <span>{language === "ta" ? "जेनरेट करें" : "Generate"}</span>
              </div>
              <div className="w-8 h-0.5 bg-border"></div>
              <div
                className={`flex items-center space-x-2 ${currentStep === "review" ? "text-primary" : "text-muted-foreground"}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === "review" ? "bg-primary text-white" : "bg-muted"}`}
                >
                  3
                </div>
                <span>{language === "ta" ? "समीक्षा करें" : "Review"}</span>
              </div>
            </div>
          </div>

          {/* Step 1: File Selection */}
          {currentStep === "select" && (
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="w-5 h-5" />
                    <span>
                      {language === "ta" ? "उपलब्ध फाइलें" : "Available Files"}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {files.length === 0 ? (
                    <div className="text-center py-8">
                      <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        {language === "ta"
                          ? "कोई फाइल अपलोड नहीं हुई"
                          : "No files uploaded yet"}
                      </p>
                      <Button
                        className="mt-4"
                        onClick={() => navigate("/upload-pdf")}
                      >
                        {language === "ta"
                          ? "फाइलें अपलोड करें"
                          : "Upload Files"}
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {files.map((file) => (
                        <div
                          key={file.id}
                          className={`p-3 rounded border cursor-pointer transition-colors ${
                            selectedFiles.includes(file.id)
                              ? "bg-primary/10 border-primary"
                              : "bg-muted/30 border-border hover:bg-muted/50"
                          }`}
                          onClick={() => toggleFileSelection(file.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              {file.type === "pdf" ? (
                                <FileText className="w-5 h-5 text-red-500" />
                              ) : (
                                <ImageIcon className="w-5 h-5 text-blue-500" />
                              )}
                              <div>
                                <p className="font-medium">
                                  {file.originalName}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {(file.size / 1024).toFixed(1)} KB
                                </p>
                              </div>
                            </div>
                            {selectedFiles.includes(file.id) && (
                              <CheckCircle className="w-5 h-5 text-primary" />
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>
                    {language === "ta"
                      ? "जेनरेशन सेटिंग्स"
                      : "Generation Settings"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-2">
                      {language === "ta"
                        ? "चुनी गई फाइलें:"
                        : "Selected Files:"}
                    </p>
                    <Badge variant="secondary">
                      {selectedFiles.length}{" "}
                      {language === "ta" ? "फाइलें" : "files"}
                    </Badge>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Brain className="w-5 h-5 text-primary" />
                      <span className="font-medium">
                        {language === "ta" ? "AI जेनरेशन" : "AI Generation"}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {language === "ta"
                        ? "IBM Granite AI आपकी फाइलों से बुद्धिमान प्रश्न और उत्तर बनाएगा"
                        : "IBM Granite AI will analyze your files and create intelligent questions and answers"}
                    </p>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>
                        •{" "}
                        {language === "ta"
                          ? "विभिन्न कठिनाई स्तर (1-5 अंक)"
                          : "Various difficulty levels (1-5 marks)"}
                      </li>
                      <li>
                        •{" "}
                        {language === "ta"
                          ? "विषय-आधारित वर्गीकरण"
                          : "Topic-based categorization"}
                      </li>
                      <li>
                        •{" "}
                        {language === "ta"
                          ? "संदर्भ-जागरूक उत्तर"
                          : "Context-aware answers"}
                      </li>
                    </ul>
                  </div>

                  <Button
                    onClick={generateQA}
                    disabled={selectedFiles.length === 0 || isGenerating}
                    className="w-full"
                    size="lg"
                  >
                    {isGenerating ? (
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    ) : (
                      <Brain className="w-5 h-5 mr-2" />
                    )}
                    {language === "ta" ? "Q&A जेनरेट करें" : "Generate Q&A"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 2: Generation in Progress */}
          {currentStep === "generate" && (
            <Card className="max-w-2xl mx-auto">
              <CardContent className="p-8 text-center space-y-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Loader2 className="w-10 h-10 text-primary animate-spin" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">
                    {language === "ta"
                      ? "Q&A जेनरेट कर रहा है..."
                      : "Generating Q&A..."}
                  </h3>
                  <p className="text-muted-foreground">
                    {language === "ta"
                      ? "IBM Granite AI आपकी फाइलों का विश्लेषण कर रहा है और प्रश्न-उत्तर बना रहा है"
                      : "IBM Granite AI is analyzing your files and creating questions and answers"}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Review Generated Q&As */}
          {currentStep === "review" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">
                    {language === "ta" ? "जेनरेट किए गए Q&A" : "Generated Q&A"}
                  </h2>
                  <p className="text-muted-foreground">
                    {generatedQAs.length}{" "}
                    {language === "ta"
                      ? "प्रश्न-उत्तर जोड़े"
                      : "question-answer pairs"}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={shareQAs}>
                    <Share2 className="w-4 h-4 mr-2" />
                    {language === "ta" ? "साझा करें" : "Share"}
                  </Button>
                  <Button variant="outline" onClick={downloadQAs}>
                    <Download className="w-4 h-4 mr-2" />
                    {language === "ta" ? "डाउनलोड" : "Download"}
                  </Button>
                  <Button onClick={resetGenerator}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    {language === "ta" ? "नया बनाएं" : "Generate New"}
                  </Button>
                </div>
              </div>

              <div className="grid gap-4">
                {generatedQAs.map((qa, index) => (
                  <Card key={qa.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">
                          {language === "ta" ? "प्रश्न" : "Question"}{" "}
                          {index + 1}
                        </CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">
                            {qa.difficulty} {language === "ta" ? "अंक" : "mark"}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {qa.sourceFiles.join(", ")}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium text-primary mb-2">
                          {language === "ta" ? "प्रश्न:" : "Question:"}
                        </h4>
                        <p className="text-sm">{qa.question}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-accent mb-2">
                          {language === "ta" ? "उत्तर:" : "Answer:"}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {qa.answer}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
