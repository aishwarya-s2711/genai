import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/lib/contexts";
import {
  FileText,
  MessageSquare,
  Brain,
  Search,
  Download,
  Share2,
  Calendar,
  Award,
  Clock,
  Filter,
  Trash2,
  Eye,
} from "lucide-react";

interface HistoryItem {
  id: string;
  type: "upload" | "question" | "quiz" | "qa_generated";
  title: string;
  content?: string;
  timestamp: string;
  score?: number;
  fileNames?: string[];
  metadata?: any;
}

export default function History() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [filteredHistory, setFilteredHistory] = useState<HistoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  useEffect(() => {
    filterHistory();
  }, [history, searchTerm, selectedType]);

  const loadHistory = async () => {
    setIsLoading(true);
    try {
      // Simulate loading from localStorage or API
      const savedHistory = localStorage.getItem("studymate_history");
      if (savedHistory) {
        const parsed = JSON.parse(savedHistory);
        setHistory(parsed);
      } else {
        // Create some sample history for demonstration
        const sampleHistory: HistoryItem[] = [
          {
            id: "1",
            type: "upload",
            title:
              language === "ta"
                ? "கணித வீர் फайल.pdf"
                : "Mathematics_Chapter1.pdf",
            timestamp: new Date(Date.now() - 86400000).toISOString(),
            fileNames: ["Mathematics_Chapter1.pdf"],
          },
          {
            id: "2",
            type: "question",
            title:
              language === "ta"
                ? "வகையியல் பற்றி கேள்வி"
                : "Question about derivatives",
            content:
              language === "ta"
                ? "வகையியல் என்றால் என்ன?"
                : "What are derivatives in calculus?",
            timestamp: new Date(Date.now() - 7200000).toISOString(),
            fileNames: ["Mathematics_Chapter1.pdf"],
          },
          {
            id: "3",
            type: "quiz",
            title: language === "ta" ? "கணித வினाडี வினா" : "Mathematics Quiz",
            score: 85,
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            fileNames: ["Mathematics_Chapter1.pdf"],
            metadata: { questionsCount: 10, timeSpent: 15 },
          },
        ];
        setHistory(sampleHistory);
        localStorage.setItem(
          "studymate_history",
          JSON.stringify(sampleHistory),
        );
      }
    } catch (error) {
      console.error("Failed to load history:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterHistory = () => {
    let filtered = history;

    if (selectedType !== "all") {
      filtered = filtered.filter((item) => item.type === selectedType);
    }

    if (searchTerm) {
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.content?.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    // Sort by timestamp, most recent first
    filtered.sort(
      (a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(),
    );

    setFilteredHistory(filtered);
  };

  const shareHistory = async (item: HistoryItem) => {
    try {
      const shareData = {
        title: `StudyMate - ${item.title}`,
        text: `Check out this ${item.type} from StudyMate: ${item.title}`,
        url: window.location.href,
      };

      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        // Fallback: copy to clipboard
        await navigator.clipboard.writeText(
          `${shareData.title}\n${shareData.text}\n${shareData.url}`,
        );
        alert(
          language === "ta"
            ? "लिंक कॉपी كر दिया गया"
            : "Link copied to clipboard",
        );
      }
    } catch (error) {
      console.error("Failed to share:", error);
    }
  };

  const downloadHistory = () => {
    const dataStr = JSON.stringify(history, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "studymate_history.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  const deleteHistoryItem = (id: string) => {
    const updatedHistory = history.filter((item) => item.id !== id);
    setHistory(updatedHistory);
    localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "upload":
        return <FileText className="w-4 h-4" />;
      case "question":
        return <MessageSquare className="w-4 h-4" />;
      case "quiz":
        return <Award className="w-4 h-4" />;
      case "qa_generated":
        return <Brain className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "upload":
        return "bg-blue-100 text-blue-800";
      case "question":
        return "bg-green-100 text-green-800";
      case "quiz":
        return "bg-purple-100 text-purple-800";
      case "qa_generated":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffHours < 1) {
      return language === "ta" ? "अभी अभी" : "Just now";
    } else if (diffHours < 24) {
      return language === "ta"
        ? `${diffHours} மணி मुंहे`
        : `${diffHours} hours ago`;
    } else {
      return language === "ta"
        ? `${diffDays} दिन पहले`
        : `${diffDays} days ago`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2">
              {language === "ta" ? "पढ़ाई का इतिहास" : "Study History"}
            </h1>
            <p className="text-muted-foreground">
              {language === "ta"
                ? "आपकी सभी पढ़ाई की गतिविधियों का ट्रैक रखें और पुराने काम को फिर से देखें"
                : "Track all your study activities and revisit previous work"}
            </p>
          </div>

          {/* Controls */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="flex flex-1 gap-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder={language === "ta" ? "खोजें..." : "Search..."}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="px-3 py-2 border border-input bg-background rounded-md text-sm"
                  >
                    <option value="all">
                      {language === "ta" ? "सभी" : "All Types"}
                    </option>
                    <option value="upload">
                      {language === "ta" ? "अपलोड" : "Uploads"}
                    </option>
                    <option value="question">
                      {language === "ta" ? "प्रश्न" : "Questions"}
                    </option>
                    <option value="quiz">
                      {language === "ta" ? "क्विज़" : "Quizzes"}
                    </option>
                    <option value="qa_generated">
                      {language === "ta" ? "जनरेट किए गए Q&A" : "Generated Q&A"}
                    </option>
                  </select>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={downloadHistory}>
                    <Download className="w-4 h-4 mr-2" />
                    {language === "ta" ? "डाउनलोड" : "Download"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* History List */}
          <div className="space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {language === "ta"
                      ? "इतिहास लोड किया जा रहा है..."
                      : "Loading history..."}
                  </p>
                </CardContent>
              </Card>
            ) : filteredHistory.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">
                    {language === "ta"
                      ? "कोई इतिहास नहीं मिला"
                      : "No History Found"}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm || selectedType !== "all"
                      ? language === "ta"
                        ? "फ़िल्टर के लिए कोई परिणाम नहीं मिले"
                        : "No results match your filters"
                      : language === "ta"
                        ? "अभी तक कोई गतिविधि नहीं है"
                        : "No activity yet"}
                  </p>
                  <Button onClick={() => navigate("/home")}>
                    {language === "ta" ? "पढ़ाई शुरू करें" : "Start Studying"}
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredHistory.map((item) => (
                <Card
                  key={item.id}
                  className="hover:shadow-md transition-shadow"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <div
                          className={`p-2 rounded-lg ${getTypeColor(item.type)}`}
                        >
                          {getTypeIcon(item.type)}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold truncate">
                              {item.title}
                            </h3>
                            {item.score && (
                              <Badge variant="secondary" className="text-xs">
                                {item.score}%
                              </Badge>
                            )}
                          </div>

                          {item.content && (
                            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                              {item.content}
                            </p>
                          )}

                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {formatDate(item.timestamp)}
                            </span>

                            {item.fileNames && (
                              <span className="flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                {item.fileNames.length}{" "}
                                {language === "ta" ? "फ़ाइलें" : "files"}
                              </span>
                            )}

                            {item.metadata?.questionsCount && (
                              <span>
                                {item.metadata.questionsCount}{" "}
                                {language === "ta" ? "प्रश्न" : "questions"}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => shareHistory(item)}
                          title={language === "ta" ? "साझा करें" : "Share"}
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>

                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteHistoryItem(item.id)}
                          title={language === "ta" ? "हटाएं" : "Delete"}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Stats Summary */}
          {filteredHistory.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">
                  {language === "ta" ? "गतिविधि सारांश" : "Activity Summary"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {history.filter((h) => h.type === "upload").length}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "अपलोड" : "Uploads"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {history.filter((h) => h.type === "question").length}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "प्रश्न" : "Questions"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {history.filter((h) => h.type === "quiz").length}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "क्विज़" : "Quizzes"}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {Math.round(
                        history
                          .filter((h) => h.score)
                          .reduce(
                            (avg, h, _, arr) =>
                              avg + (h.score || 0) / arr.length,
                            0,
                          ),
                      ) || 0}
                      %
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "औसत स्कोर" : "Avg Score"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
