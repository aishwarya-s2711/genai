import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  GraduationCap,
  Construction,
  ArrowLeft,
  MessageSquare,
} from "lucide-react";

export default function Placeholder() {
  const navigate = useNavigate();
  const location = useLocation();

  const getPageInfo = () => {
    const path = location.pathname;
    switch (path) {
      case "/upload-picture":
        return {
          title: "Upload Picture",
          description:
            "Capture or upload images for AI analysis and text extraction",
          icon: "📷",
        };
      case "/upload-pdf":
        return {
          title: "Upload PDF",
          description:
            "Upload 1-4 PDF documents for comprehensive study material analysis",
          icon: "📄",
        };
      case "/ask-questions":
        return {
          title: "Ask Questions",
          description:
            "Get intelligent answers from your uploaded materials with customizable detail levels",
          icon: "❓",
        };
      case "/qa-generator":
        return {
          title: "Q&A Generator",
          description:
            "Automatically generate questions and answers from your uploaded content",
          icon: "🧠",
        };
      case "/tests":
        return {
          title: "Tests & Quizzes",
          description:
            "Take AI-generated tests with multiple choice, fill-in-the-blanks, and graded questions",
          icon: "📝",
        };
      default:
        return {
          title: "Feature Page",
          description: "This feature is being developed",
          icon: "🔧",
        };
    }
  };

  const pageInfo = getPageInfo();

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      {/* Header */}
      <header className="border-b bg-white/70 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                StudyMate
              </h1>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => navigate("/home")}>
                Back to Home
              </Button>
              <Button variant="outline" onClick={() => navigate("/")}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate("/home")}
            className="mb-6 p-0 h-auto text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>

          <Card className="border-2 shadow-xl">
            <CardHeader className="text-center space-y-4">
              <div className="w-20 h-20 bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl flex items-center justify-center mx-auto">
                <Construction className="w-10 h-10 text-primary" />
              </div>
              <div>
                <CardTitle className="text-3xl mb-2">
                  {pageInfo.icon} {pageInfo.title}
                </CardTitle>
                <CardDescription className="text-lg">
                  {pageInfo.description}
                </CardDescription>
              </div>
            </CardHeader>

            <CardContent className="text-center space-y-6">
              <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-3">Coming Soon!</h3>
                <p className="text-muted-foreground mb-4">
                  This feature is currently being developed and will be
                  available in the next update. Our team is working hard to
                  bring you the best learning experience possible.
                </p>
                <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                  <MessageSquare className="w-4 h-4" />
                  <span>Want to see this feature next? Let us know!</span>
                </div>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={() => navigate("/home")}
                  className="w-full"
                  size="lg"
                >
                  Return to Home
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate("/home")}
                  className="w-full"
                >
                  Explore Other Features
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
