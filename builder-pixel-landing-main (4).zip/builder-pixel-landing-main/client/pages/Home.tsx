import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/lib/contexts";
import {
  Upload,
  FileText,
  MessageSquare,
  Brain,
  Camera,
  BookOpen,
  ChevronRight,
} from "lucide-react";

export default function Home() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [recentActivity] = useState([
    { type: "upload", title: "Mathematics Notes.pdf", time: "2 hours ago" },
    {
      type: "test",
      title: "Physics Quiz - Chapter 3",
      score: "85%",
      time: "1 day ago",
    },
    {
      type: "question",
      title: "Asked about thermodynamics",
      time: "2 days ago",
    },
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">Welcome back, Student!</h2>
            <p className="text-muted-foreground text-lg">
              Ready to continue your learning journey? Choose what you'd like to
              do today.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Features - Left Column */}
            <div className="lg:col-span-2 space-y-6">
              <h3 className="text-2xl font-semibold mb-4">Main Features</h3>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Upload Picture */}
                <Card
                  className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-primary/20"
                  onClick={() => navigate("/upload-picture")}
                >
                  <CardHeader className="pb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <Camera className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl flex items-center justify-between">
                      Upload Picture
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </CardTitle>
                    <CardDescription className="text-base">
                      Capture or upload images of notes, textbooks, or
                      handwritten content for AI analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        Instant OCR
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Text Extraction
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Upload PDF */}
                <Card
                  className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-accent/20"
                  onClick={() => navigate("/upload-pdf")}
                >
                  <CardHeader className="pb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-accent to-accent/80 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <FileText className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl flex items-center justify-between">
                      Upload PDF
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-accent group-hover:translate-x-1 transition-all" />
                    </CardTitle>
                    <CardDescription className="text-base">
                      Upload 1-4 PDF documents for comprehensive study material
                      analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        1-4 Files
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Smart Analysis
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Ask Questions */}
                <Card
                  className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-primary/20"
                  onClick={() => navigate("/ask-questions")}
                >
                  <CardHeader className="pb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <MessageSquare className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl flex items-center justify-between">
                      Ask Questions
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </CardTitle>
                    <CardDescription className="text-base">
                      Get intelligent answers from your uploaded materials with
                      customizable detail levels
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        1-3 Marks
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Context-Aware
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Automatic Q&A Generator */}
                <Card
                  className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-accent/20"
                  onClick={() => navigate("/qa-generator")}
                >
                  <CardHeader className="pb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-accent to-accent/80 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <Brain className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl flex items-center justify-between">
                      Q&A Generator
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-accent group-hover:translate-x-1 transition-all" />
                    </CardTitle>
                    <CardDescription className="text-base">
                      Automatically generate questions and answers from your
                      uploaded content
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        Auto-Generate
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        Multiple Types
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Test Taking Section */}
              <div className="mt-8">
                <h3 className="text-2xl font-semibold mb-4">Test Taking</h3>
                <Card className="p-6 border-2">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="text-xl font-semibold mb-2">
                        Practice Tests & Quizzes
                      </h4>
                      <p className="text-muted-foreground">
                        Test your knowledge with AI-generated quizzes tailored
                        to your uploaded content
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <h5 className="font-semibold">Multiple Choice</h5>
                      <p className="text-sm text-muted-foreground">
                        Choose the best answer
                      </p>
                    </div>
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <h5 className="font-semibold">Fill in the Blanks</h5>
                      <p className="text-sm text-muted-foreground">
                        Complete the sentences
                      </p>
                    </div>
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <h5 className="font-semibold">Graded Questions</h5>
                      <p className="text-sm text-muted-foreground">
                        1, 2, 5-mark questions
                      </p>
                    </div>
                  </div>

                  <Button
                    className="w-full md:w-auto"
                    onClick={() => navigate("/tests")}
                  >
                    Start Taking Tests
                    <ChevronRight className="ml-2 w-4 h-4" />
                  </Button>
                </Card>
              </div>
            </div>

            {/* Sidebar - Right Column */}
            <div className="space-y-6">
              {/* Quick Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Your Progress</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Documents Uploaded
                    </span>
                    <Badge variant="secondary">12</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Tests Completed
                    </span>
                    <Badge variant="secondary">8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Average Score
                    </span>
                    <Badge className="bg-green-100 text-green-800">87%</Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 p-3 rounded-lg bg-muted/30"
                    >
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        {activity.type === "upload" && (
                          <Upload className="w-4 h-4 text-primary" />
                        )}
                        {activity.type === "test" && (
                          <Brain className="w-4 h-4 text-accent" />
                        )}
                        {activity.type === "question" && (
                          <MessageSquare className="w-4 h-4 text-primary" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {activity.title}
                        </p>
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-muted-foreground">
                            {activity.time}
                          </p>
                          {activity.score && (
                            <Badge variant="secondary" className="text-xs">
                              {activity.score}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
