import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/lib/contexts";
import {
  Star,
  Send,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  TrendingUp,
  Users,
  Award,
  CheckCircle,
  Lightbulb,
  Heart,
  AlertTriangle,
  Plus,
} from "lucide-react";

interface Rating {
  id: string;
  category: string;
  rating: number;
  comment: string;
  timestamp: Date;
  userName: string;
}

interface Feedback {
  id: string;
  type: "suggestion" | "bug" | "feature" | "general";
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  timestamp: Date;
  userName: string;
  likes: number;
  status: "pending" | "reviewed" | "implemented";
}

export default function RatingFeedback() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();

  // Rating states
  const [currentRating, setCurrentRating] = useState({
    overall: 0,
    aiAccuracy: 0,
    userInterface: 0,
    features: 0,
    performance: 0,
  });
  const [ratingComment, setRatingComment] = useState("");

  // Feedback states
  const [feedbackType, setFeedbackType] = useState<
    "suggestion" | "bug" | "feature" | "general"
  >("general");
  const [feedbackTitle, setFeedbackTitle] = useState("");
  const [feedbackDescription, setFeedbackDescription] = useState("");
  const [feedbackPriority, setFeedbackPriority] = useState<
    "low" | "medium" | "high"
  >("medium");

  // Data states
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentTab, setCurrentTab] = useState<
    "rate" | "feedback" | "community"
  >("rate");

  useEffect(() => {
    loadRatingsAndFeedback();
  }, []);

  const loadRatingsAndFeedback = () => {
    try {
      // Load ratings
      const savedRatings = localStorage.getItem("studymate_ratings");
      if (savedRatings) {
        const parsed = JSON.parse(savedRatings);
        setRatings(
          parsed.map((r: any) => ({ ...r, timestamp: new Date(r.timestamp) })),
        );
      }

      // Load feedback
      const savedFeedback = localStorage.getItem("studymate_feedback");
      if (savedFeedback) {
        const parsed = JSON.parse(savedFeedback);
        setFeedbacks(
          parsed.map((f: any) => ({ ...f, timestamp: new Date(f.timestamp) })),
        );
      }
    } catch (error) {
      console.error("Failed to load ratings and feedback:", error);
    }
  };

  const submitRating = async () => {
    if (currentRating.overall === 0) {
      alert(
        language === "ta"
          ? "कृपया कम से कम समग्र रेटिंग दें"
          : "Please provide at least an overall rating",
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const newRating: Rating = {
        id: Date.now().toString(),
        category: "overall",
        rating: currentRating.overall,
        comment: ratingComment,
        timestamp: new Date(),
        userName: "Student", // In real app, get from auth
      };

      const updatedRatings = [newRating, ...ratings].slice(0, 100);
      setRatings(updatedRatings);
      localStorage.setItem("studymate_ratings", JSON.stringify(updatedRatings));

      // Save to history
      saveToHistory(
        "rating",
        `Rated StudyMate ${currentRating.overall} stars`,
        ratingComment,
      );

      // Reset form
      setCurrentRating({
        overall: 0,
        aiAccuracy: 0,
        userInterface: 0,
        features: 0,
        performance: 0,
      });
      setRatingComment("");

      alert(
        language === "ta"
          ? "आपकी रेटिंग सबमिट हो गई!"
          : "Your rating has been submitted!",
      );
    } catch (error) {
      console.error("Failed to submit rating:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const submitFeedback = async () => {
    if (!feedbackTitle.trim() || !feedbackDescription.trim()) {
      alert(
        language === "ta"
          ? "कृपया शीर्षक और विवरण भरें"
          : "Please fill in title and description",
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const newFeedback: Feedback = {
        id: Date.now().toString(),
        type: feedbackType,
        title: feedbackTitle,
        description: feedbackDescription,
        priority: feedbackPriority,
        timestamp: new Date(),
        userName: "Student",
        likes: 0,
        status: "pending",
      };

      const updatedFeedback = [newFeedback, ...feedbacks].slice(0, 100);
      setFeedbacks(updatedFeedback);
      localStorage.setItem(
        "studymate_feedback",
        JSON.stringify(updatedFeedback),
      );

      // Save to history
      saveToHistory(
        "feedback",
        `Submitted ${feedbackType}: ${feedbackTitle}`,
        feedbackDescription,
      );

      // Reset form
      setFeedbackTitle("");
      setFeedbackDescription("");
      setFeedbackType("general");
      setFeedbackPriority("medium");

      alert(
        language === "ta"
          ? "आपकी फीडबैक सबमिट हो गई!"
          : "Your feedback has been submitted!",
      );
    } catch (error) {
      console.error("Failed to submit feedback:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const saveToHistory = (type: string, title: string, content: string) => {
    try {
      const savedHistory = localStorage.getItem("studymate_history");
      const history = savedHistory ? JSON.parse(savedHistory) : [];

      const historyItem = {
        id: Date.now().toString(),
        type,
        title,
        content,
        timestamp: new Date().toISOString(),
        metadata: { source: "rating_feedback" },
      };

      const updatedHistory = [historyItem, ...history].slice(0, 100);
      localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
    } catch (error) {
      console.error("Failed to save to history:", error);
    }
  };

  const likeFeedback = (feedbackId: string) => {
    const updatedFeedbacks = feedbacks.map((f) =>
      f.id === feedbackId ? { ...f, likes: f.likes + 1 } : f,
    );
    setFeedbacks(updatedFeedbacks);
    localStorage.setItem(
      "studymate_feedback",
      JSON.stringify(updatedFeedbacks),
    );
  };

  const renderStarRating = (
    rating: number,
    setRating: (rating: number) => void,
    size: "sm" | "lg" = "sm",
  ) => {
    const starSize = size === "lg" ? "w-8 h-8" : "w-5 h-5";

    return (
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => setRating(star)}
            className={`${starSize} transition-colors ${
              star <= rating ? "text-yellow-400" : "text-gray-300"
            } hover:text-yellow-400`}
          >
            <Star className="w-full h-full fill-current" />
          </button>
        ))}
      </div>
    );
  };

  const getAverageRating = () => {
    if (ratings.length === 0) return 0;
    const sum = ratings.reduce((acc, rating) => acc + rating.rating, 0);
    return (sum / ratings.length).toFixed(1);
  };

  const getFeedbackTypeIcon = (type: string) => {
    switch (type) {
      case "suggestion":
        return <Lightbulb className="w-4 h-4" />;
      case "bug":
        return <AlertTriangle className="w-4 h-4" />;
      case "feature":
        return <Plus className="w-4 h-4" />;
      default:
        return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getFeedbackTypeColor = (type: string) => {
    switch (type) {
      case "suggestion":
        return "bg-blue-100 text-blue-800";
      case "bug":
        return "bg-red-100 text-red-800";
      case "feature":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
              <Star className="w-8 h-8 text-yellow-500" />
              <span>
                {language === "ta" ? "रेटिंग और फीडबैक" : "Rating & Feedback"}
              </span>
            </h1>
            <p className="text-muted-foreground">
              {language === "ta"
                ? "StudyMate को रेट करें और अपनी राय साझा करें"
                : "Rate StudyMate and share your thoughts to help us improve"}
            </p>
          </div>

          {/* Tabs */}
          <div className="flex space-x-2 mb-6">
            <Button
              variant={currentTab === "rate" ? "default" : "outline"}
              onClick={() => setCurrentTab("rate")}
              className="flex items-center space-x-2"
            >
              <Star className="w-4 h-4" />
              <span>{language === "ta" ? "रेटिंग दें" : "Rate App"}</span>
            </Button>
            <Button
              variant={currentTab === "feedback" ? "default" : "outline"}
              onClick={() => setCurrentTab("feedback")}
              className="flex items-center space-x-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>{language === "ta" ? "फीडबैक दें" : "Give Feedback"}</span>
            </Button>
            <Button
              variant={currentTab === "community" ? "default" : "outline"}
              onClick={() => setCurrentTab("community")}
              className="flex items-center space-x-2"
            >
              <Users className="w-4 h-4" />
              <span>{language === "ta" ? "समुदाय" : "Community"}</span>
            </Button>
          </div>

          {/* Rating Tab */}
          {currentTab === "rate" && (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {language === "ta"
                        ? "StudyMate को रेट करें"
                        : "Rate StudyMate"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Overall Rating */}
                    <div>
                      <Label className="text-base font-medium">
                        {language === "ta" ? "समग्र रेटिंग" : "Overall Rating"}
                      </Label>
                      <div className="flex items-center space-x-4 mt-2">
                        {renderStarRating(
                          currentRating.overall,
                          (rating) =>
                            setCurrentRating((prev) => ({
                              ...prev,
                              overall: rating,
                            })),
                          "lg",
                        )}
                        <span className="text-lg font-medium">
                          {currentRating.overall}/5
                        </span>
                      </div>
                    </div>

                    <Separator />

                    {/* Detailed Ratings */}
                    <div className="space-y-4">
                      <h4 className="font-medium">
                        {language === "ta"
                          ? "विस्तृत रेटिंग"
                          : "Detailed Ratings"}
                      </h4>

                      <div className="grid gap-4">
                        <div className="flex items-center justify-between">
                          <span>
                            {language === "ta" ? "AI की सटीकता" : "AI Accuracy"}
                          </span>
                          {renderStarRating(
                            currentRating.aiAccuracy,
                            (rating) =>
                              setCurrentRating((prev) => ({
                                ...prev,
                                aiAccuracy: rating,
                              })),
                          )}
                        </div>

                        <div className="flex items-center justify-between">
                          <span>
                            {language === "ta"
                              ? "यूजर इंटरफेस"
                              : "User Interface"}
                          </span>
                          {renderStarRating(
                            currentRating.userInterface,
                            (rating) =>
                              setCurrentRating((prev) => ({
                                ...prev,
                                userInterface: rating,
                              })),
                          )}
                        </div>

                        <div className="flex items-center justify-between">
                          <span>
                            {language === "ta" ? "फीचर्स" : "Features"}
                          </span>
                          {renderStarRating(currentRating.features, (rating) =>
                            setCurrentRating((prev) => ({
                              ...prev,
                              features: rating,
                            })),
                          )}
                        </div>

                        <div className="flex items-center justify-between">
                          <span>
                            {language === "ta" ? "प्रदर्शन" : "Performance"}
                          </span>
                          {renderStarRating(
                            currentRating.performance,
                            (rating) =>
                              setCurrentRating((prev) => ({
                                ...prev,
                                performance: rating,
                              })),
                          )}
                        </div>
                      </div>
                    </div>

                    <Separator />

                    {/* Comment */}
                    <div>
                      <Label htmlFor="rating-comment">
                        {language === "ta"
                          ? "टिप्पणी (वैकल्पिक)"
                          : "Comment (Optional)"}
                      </Label>
                      <Textarea
                        id="rating-comment"
                        placeholder={
                          language === "ta"
                            ? "अपना अनुभव साझा करें..."
                            : "Share your experience..."
                        }
                        value={ratingComment}
                        onChange={(e) => setRatingComment(e.target.value)}
                        className="mt-2"
                        rows={3}
                      />
                    </div>

                    <Button
                      onClick={submitRating}
                      disabled={isSubmitting || currentRating.overall === 0}
                      className="w-full"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {isSubmitting
                        ? language === "ta"
                          ? "सबमिट कर रहे हैं..."
                          : "Submitting..."
                        : language === "ta"
                          ? "रेटिंग सबमिट करें"
                          : "Submit Rating"}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Rating Stats */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5" />
                      <span>
                        {language === "ta" ? "रेटिंग स्टेट्स" : "Rating Stats"}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center space-y-2">
                      <div className="text-4xl font-bold text-primary">
                        {getAverageRating()}
                      </div>
                      <div className="flex justify-center">
                        {renderStarRating(
                          Math.round(Number(getAverageRating())),
                          () => {},
                          "sm",
                        )}
                      </div>
                      <p className="text-muted-foreground">
                        {ratings.length}{" "}
                        {language === "ta" ? "रेटिंग्स" : "ratings"}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>
                      {language === "ta" ? "हाल की रेटिंग्स" : "Recent Ratings"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-48">
                      <div className="space-y-3">
                        {ratings.slice(0, 5).map((rating) => (
                          <div key={rating.id} className="border-b pb-2">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">
                                {rating.userName}
                              </span>
                              <div className="flex">
                                {renderStarRating(
                                  rating.rating,
                                  () => {},
                                  "sm",
                                )}
                              </div>
                            </div>
                            {rating.comment && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {rating.comment}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Feedback Tab */}
          {currentTab === "feedback" && (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {language === "ta"
                        ? "फीडबैक और सुझाव"
                        : "Feedback & Suggestions"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label>
                          {language === "ta"
                            ? "फीडबैक का प्रकार"
                            : "Feedback Type"}
                        </Label>
                        <select
                          value={feedbackType}
                          onChange={(e) =>
                            setFeedbackType(e.target.value as any)
                          }
                          className="w-full mt-2 p-2 border rounded-md"
                        >
                          <option value="general">
                            {language === "ta" ? "सामान्य" : "General"}
                          </option>
                          <option value="suggestion">
                            {language === "ta" ? "सुझाव" : "Suggestion"}
                          </option>
                          <option value="bug">
                            {language === "ta" ? "बग रिपोर्ट" : "Bug Report"}
                          </option>
                          <option value="feature">
                            {language === "ta" ? "नया फीचर" : "Feature Request"}
                          </option>
                        </select>
                      </div>

                      <div>
                        <Label>
                          {language === "ta" ? "प्राथमिकता" : "Priority"}
                        </Label>
                        <select
                          value={feedbackPriority}
                          onChange={(e) =>
                            setFeedbackPriority(e.target.value as any)
                          }
                          className="w-full mt-2 p-2 border rounded-md"
                        >
                          <option value="low">
                            {language === "ta" ? "कम" : "Low"}
                          </option>
                          <option value="medium">
                            {language === "ta" ? "मध्यम" : "Medium"}
                          </option>
                          <option value="high">
                            {language === "ta" ? "उच्च" : "High"}
                          </option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="feedback-title">
                        {language === "ta" ? "शीर्षक" : "Title"}
                      </Label>
                      <Input
                        id="feedback-title"
                        placeholder={
                          language === "ta"
                            ? "फीडबैक का शीर्षक..."
                            : "Feedback title..."
                        }
                        value={feedbackTitle}
                        onChange={(e) => setFeedbackTitle(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="feedback-description">
                        {language === "ta" ? "विवरण" : "Description"}
                      </Label>
                      <Textarea
                        id="feedback-description"
                        placeholder={
                          language === "ta"
                            ? "विस्तार से बताएं..."
                            : "Describe in detail..."
                        }
                        value={feedbackDescription}
                        onChange={(e) => setFeedbackDescription(e.target.value)}
                        className="mt-2"
                        rows={5}
                      />
                    </div>

                    <Button
                      onClick={submitFeedback}
                      disabled={
                        isSubmitting ||
                        !feedbackTitle.trim() ||
                        !feedbackDescription.trim()
                      }
                      className="w-full"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {isSubmitting
                        ? language === "ta"
                          ? "सबमिट कर रहे हैं..."
                          : "Submitting..."
                        : language === "ta"
                          ? "फीडबैक सबमिट करें"
                          : "Submit Feedback"}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Feedback */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {language === "ta" ? "हाल का फीडबैक" : "Recent Feedback"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-3">
                        {feedbacks.slice(0, 10).map((feedback) => (
                          <div
                            key={feedback.id}
                            className="border rounded-lg p-3"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <Badge
                                className={getFeedbackTypeColor(feedback.type)}
                              >
                                {getFeedbackTypeIcon(feedback.type)}
                                <span className="ml-1">{feedback.type}</span>
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {feedback.timestamp.toLocaleDateString()}
                              </span>
                            </div>
                            <h4 className="font-medium text-sm">
                              {feedback.title}
                            </h4>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {feedback.description}
                            </p>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-xs text-muted-foreground">
                                {feedback.userName}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => likeFeedback(feedback.id)}
                                className="h-6 px-2"
                              >
                                <Heart className="w-3 h-3 mr-1" />
                                {feedback.likes}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Community Tab */}
          {currentTab === "community" && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6 text-center">
                    <Star className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                    <div className="text-3xl font-bold">
                      {getAverageRating()}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "औसत रेटिंग" : "Average Rating"}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <Users className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                    <div className="text-3xl font-bold">{ratings.length}</div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "कुल रेटिंग्स" : "Total Ratings"}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <MessageSquare className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <div className="text-3xl font-bold">{feedbacks.length}</div>
                    <div className="text-sm text-muted-foreground">
                      {language === "ta" ? "कुल फीडबैक" : "Total Feedback"}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Top Feedback */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {language === "ta" ? "टॉप फीडबैक" : "Top Feedback"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {feedbacks
                      .sort((a, b) => b.likes - a.likes)
                      .slice(0, 5)
                      .map((feedback) => (
                        <div
                          key={feedback.id}
                          className="border-l-4 border-primary pl-4"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{feedback.title}</h4>
                            <div className="flex items-center space-x-2">
                              <Badge
                                className={getFeedbackTypeColor(feedback.type)}
                              >
                                {feedback.type}
                              </Badge>
                              <span className="flex items-center text-sm text-muted-foreground">
                                <Heart className="w-4 h-4 mr-1" />
                                {feedback.likes}
                              </span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {feedback.description}
                          </p>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
