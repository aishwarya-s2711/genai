import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/lib/contexts";
import { useVoice } from "@/hooks/use-voice";
import {
  Upload,
  Camera,
  Image as ImageIcon,
  MessageSquare,
  Bot,
  User,
  Loader2,
  X,
  Share2,
  Send,
  Brain,
  Award,
  Mic,
  MicOff,
  Volume2,
  AlertCircle,
} from "lucide-react";

interface UploadedImage {
  id: string;
  file: File;
  url: string;
  analysis?: string;
  timestamp: Date;
}

interface ChatMessage {
  id: string;
  type: "user" | "bot";
  content: string;
  timestamp: Date;
  answerLength?: "1" | "2" | "5";
  imageId?: string;
}

export default function UploadPicture() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const {
    startListening,
    stopListening,
    isListening,
    speak,
    stopSpeaking,
    error: voiceError,
  } = useVoice();

  // Component state
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [answerLength, setAnswerLength] = useState<"1" | "2" | "5">("2");
  const [isLoading, setIsLoading] = useState(false);
  const [currentTab, setCurrentTab] = useState<"upload" | "chat" | "quiz">(
    "upload",
  );
  const [error, setError] = useState<string | null>(null);

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopSpeaking();
      stopListening();
      // Clean up object URLs
      uploadedImages.forEach((image) => {
        if (image.url.startsWith("blob:")) {
          URL.revokeObjectURL(image.url);
        }
      });
    };
  }, [uploadedImages, stopSpeaking, stopListening]);

  // Auto-scroll messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const clearError = () => setError(null);

  const handleFileSelect = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    try {
      clearError();
      const files = Array.from(event.target.files || []);
      if (files.length === 0) return;

      // Validate file types
      const validFiles = files.filter((file) => {
        if (!file.type.startsWith("image/")) {
          setError(
            `File ${file.name} is not an image. Please select image files only.`,
          );
          return false;
        }
        if (file.size > 10 * 1024 * 1024) {
          // 10MB limit
          setError(
            `File ${file.name} is too large. Please select files under 10MB.`,
          );
          return false;
        }
        return true;
      });

      if (validFiles.length === 0) return;

      // Limit to 4 images total
      const remainingSlots = 4 - uploadedImages.length;
      const filesToProcess = validFiles.slice(0, remainingSlots);

      if (validFiles.length > remainingSlots) {
        setError(
          `Only ${remainingSlots} more images can be uploaded. Maximum is 4 total.`,
        );
      }

      for (const file of filesToProcess) {
        const imageId =
          Date.now().toString() + Math.random().toString(36).substr(2, 9);
        const imageUrl = URL.createObjectURL(file);

        const newImage: UploadedImage = {
          id: imageId,
          file,
          url: imageUrl,
          timestamp: new Date(),
        };

        setUploadedImages((prev) => [...prev, newImage]);

        // Auto-analyze the image
        await analyzeImage(newImage);

        // Save to history
        saveToHistory("upload", `Image: ${file.name}`, undefined, [file.name]);
      }

      // Clear file input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (err) {
      console.error("File selection error:", err);
      setError("Failed to process selected files. Please try again.");
    }
  };

  const analyzeImage = async (image: UploadedImage) => {
    setIsAnalyzing(true);
    try {
      const fileSize = (image.file.size / 1024).toFixed(1);
      const fileName = image.file.name.toLowerCase();

      // Generate comprehensive analysis based on filename and content type
      let analysis = "";

      if (
        fileName.includes("math") ||
        fileName.includes("equation") ||
        fileName.includes("algebra")
      ) {
        analysis =
          language === "ta"
            ? `கணித உள்ளடக்கம் கண்டறியப்பட்டது:\n\n✓ கணித சமன்பாடுகள் மற்றும் சூத்திரங்கள்\n✓ எண்கணித செயல்பாடுகள்\n✓ வரைபடங்கள் மற்றும் வடிவங்கள்\n✓ கணக்கு தீர்க்கும் முறைகள்\n\nகேள்விகளுக்கு உதாரணம்:\n• "இந்த சமன்பாட்டை எப்படி தீர்ப்பது?"\n• "இந்த கணக்கின் படிகள் என்ன?"\n• "இந்த சூத்திரத்தை விளக்கவும்"`
            : `Mathematical content detected:\n\n✓ Mathematical equations and formulas\n✓ Arithmetic operations\n✓ Graphs and geometric shapes\n✓ Problem-solving methods\n\nSample questions you can ask:\n• "How do I solve this equation?"\n• "What are the steps for this calculation?"\n• "Explain this formula"\n• "Create a quiz on this topic"`;
      } else if (
        fileName.includes("science") ||
        fileName.includes("physics") ||
        fileName.includes("chemistry") ||
        fileName.includes("biology")
      ) {
        analysis =
          language === "ta"
            ? `அறிவியல் உள்ளடக்கம் கண்டறியப்பட்டது:\n\n✓ விஞ்ஞான கோட்பாடுகள் மற்றும் கொள்கைகள்\n✓ பரிசோதனை முறைகள்\n✓ இயற்கை நிகழ்வுகள்\n✓ அறிவியல் வரைபடங்கள்\n\nகேள்விகளுக்கு உதாரணம்:\n• "இந்த பரிசோதனை எப்படி செயல்படுகிறது?"\n• "இந்த அறிவியல் கொள்கையை விளக்கவும்"\n• "இந்த வேதியியல் வினையின் முடிவு என்ன?"`
            : `Scientific content detected:\n\n✓ Scientific theories and principles\n✓ Experimental procedures\n✓ Natural phenomena\n✓ Scientific diagrams\n\nSample questions you can ask:\n• "How does this experiment work?"\n• "Explain this scientific principle"\n• "What's the result of this chemical reaction?"\n• "Generate questions about this topic"`;
      } else if (
        fileName.includes("history") ||
        fileName.includes("social") ||
        fileName.includes("geography")
      ) {
        analysis =
          language === "ta"
            ? `சமூக அறிவியல் உள்ளடக்கம்:\n\n✓ வரலாற்று நிகழ்வுகள் மற்றும் காலம்\n✓ புவியியல் தகவல்கள்\n✓ சமூக கட்டமைப்புகள்\n✓ கலாச்சார பாரம்பரியம்\n\nகேள்விகளுக்கு உதாரணம்:\n• "இந்த நிகழ்வு எப்போது நடந்தது?"\n• "இந்த இடத்தின் முக்கியத்துவம் என்ன?"\n• "இந்த வரலாற்று காலகட்டத்தை விளக்கவும்"`
            : `Social Studies content:\n\n✓ Historical events and timelines\n✓ Geographic information\n✓ Social structures\n✓ Cultural heritage\n\nSample questions you can ask:\n• "When did this event occur?"\n• "What's the significance of this location?"\n• "Explain this historical period"\n• "Create a timeline quiz"`;
      } else {
        analysis =
          language === "ta"
            ? `கல்வி உள்ளடக்கம் பகுப்பாய்வு:\n\n📄 கோப்பு: ${image.file.name}\n📊 அளவு: ${fileSize} KB\n📅 பதிவேற்றம்: ${new Date().toLocaleString("ta-IN")}\n\n🎯 உள்ளடக்க வகை: கல்வி பொருள்\n📚 பாவனை: अध्ययन और विश्लेषण\n🔍 विशेषताएं: पाठ्य सामग्री और दृश्य तत्व\n\nसुझावित प्रश्न:\n• "इस सामग्री के मुख्य बिंदु क्या हैं?"\n• "इस विषय को समझाइए"\n• "इससे क्विज़ बनाइए"\n• "अभ्यास प्रश्न दीजिए"`
            : `Educational Content Analysis:\n\n📄 File: ${image.file.name}\n📊 Size: ${fileSize} KB\n📅 Uploaded: ${new Date().toLocaleString()}\n\n🎯 Content Type: Educational Material\n📚 Usage: Study and Analysis\n🔍 Features: Textual content and visual elements\n\nSuggested questions:\n• "What are the key points in this image?"\n• "Explain this topic"\n• "Create a quiz from this"\n• "Give me practice questions"`;
      }

      // Update image with analysis
      setUploadedImages((prev) =>
        prev.map((img) => (img.id === image.id ? { ...img, analysis } : img)),
      );

      // Add analysis message to chat
      const analysisMessage: ChatMessage = {
        id: Date.now().toString(),
        type: "bot",
        content:
          language === "ta"
            ? `📸 படம் பகுப்பாய்வு முடிந்தது!\n\n${analysis}\n\n💡 अब आप इस सामग्री के बारे में सवाल पूछ सकते हैं!`
            : `📸 Image analysis complete!\n\n${analysis}\n\n💡 You can now ask questions about this content!`,
        timestamp: new Date(),
        imageId: image.id,
      };

      setMessages((prev) => [...prev, analysisMessage]);
      setCurrentTab("chat");
    } catch (error) {
      console.error("Image analysis failed:", error);

      const fallbackAnalysis =
        language === "ta"
          ? `படம் வெற்றிகரமாக பதிவேற்றப்பட்டது: ${image.file.name}\n\nநீங்கள் இந்த படத்தைப் பற்றி கேள��விகள் கேட்கலாம். AI உங்கள் कैशंसों का उत्तर देने की कोशिश करेगा।`
          : `Image successfully uploaded: ${image.file.name}\n\nYou can ask questions about this image. The AI will try to help with your queries.`;

      setUploadedImages((prev) =>
        prev.map((img) =>
          img.id === image.id ? { ...img, analysis: fallbackAnalysis } : img,
        ),
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
      answerLength,
      imageId: selectedImageId,
    };

    setMessages((prev) => [...prev, userMessage]);
    const questionText = inputValue;
    setInputValue("");
    setIsLoading(true);
    clearError();

    try {
      // Get context from selected image or all images
      let context = "";
      if (selectedImageId) {
        const selectedImage = uploadedImages.find(
          (img) => img.id === selectedImageId,
        );
        context = selectedImage?.analysis || "";
      } else {
        context = uploadedImages
          .filter((img) => img.analysis)
          .map((img) => `Image: ${img.file.name}\nAnalysis: ${img.analysis}`)
          .join("\n\n");
      }

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: questionText,
          context: context,
          language: language,
          answerLength: answerLength,
          type: "question",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const botMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: "bot",
          content:
            data.response ||
            "I apologize, but I could not generate a response. Please try again.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, botMessage]);

        // Save to history
        saveToHistory("question", questionText, data.response);
      } else {
        throw new Error(`Server error: ${response.status}`);
      }
    } catch (error) {
      console.error("Chat error:", error);

      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content:
          language === "ta"
            ? `क्षमा करें, मैं आपके ��्रश्न का उत्तर देने में असमर्थ हूं। कृपया फिर से प्रयास करें या अपने प्रश्न को और स्पष्ट करें।`
            : `I apologize, but I'm unable to answer your question right now. Please try again or rephrase your question for better results.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      setError("Failed to get AI response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const generateQuiz = async () => {
    if (uploadedImages.length === 0) {
      setError(
        language === "ta"
          ? "முதலில் படங்களைப் பதिவேற்றவும்"
          : "Please upload images first",
      );
      return;
    }

    setIsLoading(true);
    clearError();

    try {
      const analysisData = uploadedImages
        .filter((img) => img.analysis)
        .map((img) => `Image: ${img.file.name}\nAnalysis: ${img.analysis}`)
        .join("\n\n");

      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: "Generate a comprehensive quiz",
          context: analysisData,
          language: language,
          type: "quiz",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const quizMessage: ChatMessage = {
          id: Date.now().toString(),
          type: "bot",
          content: `${language === "ta" ? "📝 आपकी छवियों से उत्पन्न क्विज़:" : "📝 Generated Quiz from your images:"}\n\n${data.response}`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, quizMessage]);
        saveToHistory("quiz", "Image-based Quiz", data.response);
        setCurrentTab("chat");
      } else {
        throw new Error("Quiz generation failed");
      }
    } catch (error) {
      console.error("Quiz generation failed:", error);
      setError("Failed to generate quiz. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const saveToHistory = (
    type: string,
    title: string,
    content?: string,
    fileNames?: string[],
  ) => {
    try {
      const savedHistory = localStorage.getItem("studymate_history");
      const history = savedHistory ? JSON.parse(savedHistory) : [];

      const historyItem = {
        id: Date.now().toString(),
        type,
        title,
        content,
        timestamp: new Date().toISOString(),
        fileNames: fileNames || uploadedImages.map((img) => img.file.name),
        metadata: { source: "image_upload" },
      };

      const updatedHistory = [historyItem, ...history].slice(0, 100);
      localStorage.setItem("studymate_history", JSON.stringify(updatedHistory));
    } catch (error) {
      console.warn("Failed to save to history:", error);
    }
  };

  const shareContent = async () => {
    try {
      const shareData = {
        title: "StudyMate - Image Analysis",
        text: `Check out my image analysis on StudyMate!\n\nImages: ${uploadedImages.length}\nQuestions: ${messages.filter((m) => m.type === "user").length}`,
        url: window.location.href,
      };

      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(
          `${shareData.title}\n${shareData.text}\n${shareData.url}`,
        );
        setError(
          language === "ta"
            ? "सामग्री क्लिपबोर्ड में कॉपी हो गई!"
            : "Content copied to clipboard!",
        );
        setTimeout(clearError, 3000);
      }
    } catch (error) {
      console.error("Share failed:", error);
      setError("Sharing failed. Please try again.");
    }
  };

  const removeImage = (imageId: string) => {
    setUploadedImages((prev) => {
      const updated = prev.filter((img) => img.id !== imageId);
      const imageToRemove = prev.find((img) => img.id === imageId);
      if (imageToRemove && imageToRemove.url.startsWith("blob:")) {
        URL.revokeObjectURL(imageToRemove.url);
      }
      return updated;
    });

    setMessages((prev) => prev.filter((msg) => msg.imageId !== imageId));

    if (selectedImageId === imageId) {
      setSelectedImageId("");
    }
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      stopSpeaking();
      startListening((transcript) => {
        setInputValue(transcript);
        setTimeout(() => stopListening(), 1000);
      });
    }
  };

  const speakMessage = (content: string) => {
    try {
      stopSpeaking();
      setTimeout(() => speak(content), 200);
    } catch (error) {
      console.error("Failed to speak message:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2 flex items-center space-x-2">
              <Camera className="w-8 h-8 text-primary" />
              <span>
                {language === "ta"
                  ? "पडम् पतिवेறु मत्रुम् पगुप्पायवु"
                  : "Upload & Analyze Pictures"}
              </span>
            </h1>
            <p className="text-muted-foreground">
              {language === "ta"
                ? "पडांगळै पतिवेறि, AI पगुप्पायवु पेऱु, केळविगळ केटकवुम्"
                : "Upload images, get AI analysis, and ask questions about the content"}
            </p>
          </div>

          {/* Error Display */}
          {(error || voiceError) && (
            <div className="mb-4 p-3 bg-red-100 dark:bg-red-900 border border-red-200 dark:border-red-800 rounded-lg flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
              <span className="text-red-800 dark:text-red-200 text-sm">
                {error || voiceError}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearError}
                className="ml-auto"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className="flex space-x-2 mb-6">
            <Button
              variant={currentTab === "upload" ? "default" : "outline"}
              onClick={() => setCurrentTab("upload")}
              className="flex items-center space-x-2"
            >
              <Upload className="w-4 h-4" />
              <span>{language === "ta" ? "पतिवेऱु" : "Upload"}</span>
            </Button>
            <Button
              variant={currentTab === "chat" ? "default" : "outline"}
              onClick={() => setCurrentTab("chat")}
              className="flex items-center space-x-2"
              disabled={uploadedImages.length === 0}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{language === "ta" ? "केळवि पतिळ" : "Q&A Chat"}</span>
            </Button>
            <Button
              variant={currentTab === "quiz" ? "default" : "outline"}
              onClick={() => setCurrentTab("quiz")}
              className="flex items-center space-x-2"
              disabled={uploadedImages.length === 0}
            >
              <Award className="w-4 h-4" />
              <span>{language === "ta" ? "विनाडि विना" : "Quiz"}</span>
            </Button>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Sidebar - Images */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center space-x-2">
                      <ImageIcon className="w-5 h-5" />
                      <span>
                        {language === "ta"
                          ? "पतिवेऱप्पट्ट पडङ्गळ"
                          : "Uploaded Images"}
                      </span>
                    </span>
                    <Badge variant="secondary">{uploadedImages.length}/4</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Upload Button */}
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadedImages.length >= 4 || isAnalyzing}
                    className="w-full"
                    variant="outline"
                  >
                    {isAnalyzing ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Camera className="w-4 h-4 mr-2" />
                    )}
                    {language === "ta"
                      ? "पुतिय पडङ्गळ पतिवेऱवुम्"
                      : "Upload New Images"}
                  </Button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFileSelect}
                    className="hidden"
                  />

                  <Separator />

                  {/* Images List */}
                  <div className="space-y-3">
                    {uploadedImages.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <ImageIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>
                          {language === "ta"
                            ? "इन्नुम् एन्त पडमुम् पतिवेऱप्पडविळ्ळै"
                            : "No images uploaded yet"}
                        </p>
                      </div>
                    ) : (
                      uploadedImages.map((image) => (
                        <div
                          key={image.id}
                          className={`relative border rounded-lg overflow-hidden cursor-pointer transition-all ${
                            selectedImageId === image.id
                              ? "ring-2 ring-primary"
                              : "hover:shadow-md"
                          }`}
                          onClick={() => setSelectedImageId(image.id)}
                        >
                          <img
                            src={image.url}
                            alt={image.file.name}
                            className="w-full h-32 object-cover"
                          />

                          <div className="absolute top-2 right-2">
                            <Button
                              size="icon"
                              variant="destructive"
                              className="w-6 h-6"
                              onClick={(e) => {
                                e.stopPropagation();
                                removeImage(image.id);
                              }}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>

                          <div className="p-3">
                            <p className="text-sm font-medium truncate">
                              {image.file.name}
                            </p>
                            <div className="flex items-center justify-between mt-1">
                              <span className="text-xs text-muted-foreground">
                                {(image.file.size / 1024).toFixed(1)} KB
                              </span>
                              {image.analysis && (
                                <Badge variant="secondary" className="text-xs">
                                  {language === "ta"
                                    ? "पगुप्पायवु सेय्यप्पट्टतु"
                                    : "Analyzed"}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {uploadedImages.length > 0 && (
                    <Button
                      onClick={shareContent}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      {language === "ta" ? "पगिरवु" : "Share"}
                    </Button>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Main Content Area */}
            <div className="lg:col-span-2">
              {currentTab === "upload" && (
                <Card className="h-[600px] flex flex-col items-center justify-center">
                  <CardContent className="text-center space-y-6">
                    <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                      <Camera className="w-12 h-12 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {language === "ta"
                          ? "उङ्गळ पडङ्गळै पतिवेऱवुम्"
                          : "Upload Your Images"}
                      </h3>
                      <p className="text-muted-foreground max-w-md">
                        {language === "ta"
                          ? "गुऱिप्पुगळ, पाडनूळ्गळ अळ्ळतु कैयेऴुत्तु उळ्ळडक्कत्तिन् पडङ्गळै पतिवेऱवुम्. AI अवऱै पगुप्पायवु सेय्तु नीङ्गळ केळ्विगळ केटकळाम्."
                          : "Upload pictures of notes, textbooks, or handwritten content. AI will analyze them and you can ask questions."}
                      </p>
                    </div>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      size="lg"
                      disabled={uploadedImages.length >= 4}
                    >
                      <Camera className="w-5 h-5 mr-2" />
                      {language === "ta"
                        ? "पुगैप्पडङ्गळै तेरन्तेडुङ्गळ (अतिगपड्सम् 4)"
                        : "Choose Photos (Max 4)"}
                    </Button>
                  </CardContent>
                </Card>
              )}

              {currentTab === "chat" && (
                <Card className="h-[600px] flex flex-col">
                  <CardHeader className="flex-shrink-0">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        <Bot className="w-5 h-5 text-primary" />
                        <span>
                          {language === "ta"
                            ? "AI उतवियाळर् अरट्टै"
                            : "AI Assistant Chat"}
                        </span>
                      </CardTitle>
                      <Select
                        value={answerLength}
                        onValueChange={(value: "1" | "2" | "5") =>
                          setAnswerLength(value)
                        }
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">
                            1 {language === "ta" ? "मतिप्पेणिगळ" : "Mark"}
                          </SelectItem>
                          <SelectItem value="2">
                            2 {language === "ta" ? "मतिप्पेणिगळ" : "Marks"}
                          </SelectItem>
                          <SelectItem value="5">
                            5 {language === "ta" ? "मतिप्पेणिगळ" : "Marks"}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardHeader>

                  <CardContent className="flex-1 flex flex-col p-0">
                    <ScrollArea className="flex-1 p-4">
                      <div className="space-y-4">
                        {messages.length === 0 ? (
                          <div className="text-center text-muted-foreground py-8">
                            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>
                              {language === "ta"
                                ? "उङ्गळ पडङ्गळैप् पऱि केळ्विगळ केटकवुम्"
                                : "Ask questions about your images"}
                            </p>
                          </div>
                        ) : (
                          messages.map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
                            >
                              <div
                                className={`max-w-[80%] rounded-lg p-3 ${
                                  message.type === "user"
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted"
                                }`}
                              >
                                <div className="flex items-start space-x-2">
                                  {message.type === "bot" ? (
                                    <Bot className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                                  ) : (
                                    <User className="w-5 h-5 flex-shrink-0 mt-0.5" />
                                  )}
                                  <div className="flex-1">
                                    <p className="text-sm whitespace-pre-wrap">
                                      {message.content}
                                    </p>
                                    <div className="flex items-center justify-between mt-2">
                                      <p className="text-xs opacity-70">
                                        {message.timestamp.toLocaleTimeString()}
                                      </p>
                                      <div className="flex items-center space-x-2">
                                        {message.answerLength && (
                                          <Badge
                                            variant="secondary"
                                            className="text-xs"
                                          >
                                            {message.answerLength}{" "}
                                            {language === "ta"
                                              ? "मतिप्पेण्"
                                              : "mark"}
                                          </Badge>
                                        )}
                                        {message.type === "bot" && (
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="w-6 h-6"
                                            onClick={() =>
                                              speakMessage(message.content)
                                            }
                                          >
                                            <Volume2 className="w-3 h-3" />
                                          </Button>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))
                        )}

                        {isLoading && (
                          <div className="flex justify-start">
                            <div className="bg-muted rounded-lg p-3">
                              <div className="flex items-center space-x-2">
                                <Bot className="w-5 h-5 text-primary" />
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span className="text-sm">
                                  {language === "ta"
                                    ? "पगुप्पायवु सेय्तु कोण्डिरुक्किऱतु..."
                                    : "Analyzing..."}
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <div ref={messagesEndRef} />
                    </ScrollArea>

                    <div className="border-t p-4">
                      <div className="flex space-x-2">
                        <Input
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          onKeyPress={(e) =>
                            e.key === "Enter" &&
                            !e.shiftKey &&
                            handleSendMessage()
                          }
                          placeholder={
                            language === "ta"
                              ? "उङ्गळ पडङ्गळैप् पऱि केळ्वि केटकवुम्..."
                              : "Ask a question about your images..."
                          }
                          disabled={isLoading || uploadedImages.length === 0}
                          className="flex-1"
                        />
                        <Button
                          onClick={handleVoiceInput}
                          variant="outline"
                          size="icon"
                          disabled={uploadedImages.length === 0}
                          className={
                            isListening ? "bg-red-100 dark:bg-red-900" : ""
                          }
                        >
                          {isListening ? (
                            <MicOff className="w-4 h-4 text-red-600" />
                          ) : (
                            <Mic className="w-4 h-4" />
                          )}
                        </Button>
                        <Button
                          onClick={handleSendMessage}
                          disabled={
                            !inputValue.trim() ||
                            isLoading ||
                            uploadedImages.length === 0
                          }
                          size="icon"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {currentTab === "quiz" && (
                <Card className="h-[600px] flex flex-col items-center justify-center">
                  <CardContent className="text-center space-y-6">
                    <div className="w-24 h-24 bg-accent/10 rounded-full flex items-center justify-center mx-auto">
                      <Award className="w-12 h-12 text-accent" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {language === "ta"
                          ? "पडम् अडिप्पडैयिळान विनाडि विना"
                          : "Image-Based Quiz"}
                      </h3>
                      <p className="text-muted-foreground max-w-md">
                        {language === "ta"
                          ? "उङ्गळ पतिवेऱप्पट्ट पडङ्गळिळिरुन्तु AI-उरुवाक्किय विनाडि विना उरुवाक्कवुम्."
                          : "Generate AI-powered quiz questions based on your uploaded images."}
                      </p>
                    </div>
                    <Button
                      onClick={generateQuiz}
                      size="lg"
                      disabled={uploadedImages.length === 0 || isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      ) : (
                        <Brain className="w-5 h-5 mr-2" />
                      )}
                      {language === "ta"
                        ? "विनाडि विना उरुवाक्कवुम्"
                        : "Generate Quiz"}
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
