import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to auth page on app load
    navigate("/auth");
  }, [navigate]);

  return null;
}
