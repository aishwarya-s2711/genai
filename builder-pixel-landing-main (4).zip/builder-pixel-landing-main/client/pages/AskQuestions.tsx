import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useLanguage } from "@/lib/contexts";
import { useVoice } from "@/hooks/use-voice";
import {
  Send,
  Upload,
  FileText,
  Bot,
  User,
  Loader2,
  RefreshCw,
  Trash2,
  Download,
  Eye,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Copy,
  Share2,
} from "lucide-react";

interface Message {
  id: string;
  type: "user" | "bot";
  content: string;
  timestamp: Date;
  answerLength?: "1" | "2" | "3";
  flowchart?: string;
}

interface UploadedFile {
  id: string;
  originalName: string;
  size: number;
  uploadDate: string;
  type: "pdf" | "image";
  hasContent: boolean;
}

export default function AskQuestions() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const {
    isListening,
    isSupported: voiceSupported,
    isSpeaking,
    transcript,
    error: voiceError,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    clearTranscript,
  } = useVoice();

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "bot",
      content:
        language === "ta"
          ? "வணக்கம்! நான் StudyMate AI உதவியாளர். நீங்கள் PDF பதிவேற்றி, கேள்விகள் கேட்கலாம். எந்த உதவி தேவை?"
          : "Hello! I'm StudyMate AI assistant. You can upload PDFs and ask me questions. How can I help you today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [answerLength, setAnswerLength] = useState<"1" | "2" | "3">("2");
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [conversation, setConversation] = useState<
    { id: string; context: string }[]
  >([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle voice input
  useEffect(() => {
    if (transcript && transcript.trim()) {
      setInputValue(transcript);
    }
  }, [transcript]);

  // Auto-speak bot responses if enabled
  useEffect(() => {
    if (autoSpeak && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.type === "bot" && lastMessage.id !== "1") {
        speak(lastMessage.content);
      }
    }
  }, [messages, autoSpeak, speak]);

  const generateFallbackResponse = (
    question: string,
    context: string,
    language: string,
  ): string => {
    const lowerQuestion = question.toLowerCase();

    // Math-related questions
    if (
      lowerQuestion.includes("math") ||
      lowerQuestion.includes("equation") ||
      lowerQuestion.includes("solve") ||
      lowerQuestion.includes("calculate")
    ) {
      return language === "ta"
        ? `गणित का प्रश्न: "${question}"\n\nमैं इस गणित समस्या में आपकी मदद कर सकता हूं:\n\n1. समीकरण को व्यवस्थित करें\n2. चरों को अलग करें\n3. चरणों का पालन करें\n4. उत्तर की जांच करें\n\nयदि आपके पास विशिष्ट समीकरण या संख्याएं हैं, तो कृपया उन्हें साझा करें।`
        : `Math Question: "${question}"\n\nI can help you with this math problem:\n\n1. Organize the equation\n2. Isolate variables\n3. Follow step-by-step process\n4. Verify the answer\n\nIf you have specific equations or numbers, please share them for detailed help.`;
    }

    // Science-related questions
    if (
      lowerQuestion.includes("science") ||
      lowerQuestion.includes("physics") ||
      lowerQuestion.includes("chemistry") ||
      lowerQuestion.includes("biology")
    ) {
      return language === "ta"
        ? `विज्ञान का प्रश्न: "${question}"\n\nविज्ञान की अवधारणाओं को समझाने में मैं आपकी मदद कर सकता हूं:\n\n• भौतिकी: बल, गति, ऊर्जा\n• रसायन: परमाणु, अणु, अभिक्रियाएं\n• जीव विज्ञान: कोशिकाएं, जैविक प्रक्रियाएं\n\nकृपया अधिक विशिष्ट प्रश्न पूछें।`
        : `Science Question: "${question}"\n\nI can help explain scientific concepts:\n\n• Physics: Forces, motion, energy\n• Chemistry: Atoms, molecules, reactions\n• Biology: Cells, biological processes\n\nPlease ask more specific questions for detailed explanations.`;
    }

    // Quiz generation requests
    if (
      lowerQuestion.includes("quiz") ||
      lowerQuestion.includes("test") ||
      lowerQuestion.includes("question")
    ) {
      return language === "ta"
        ? `क्विज़ अनुरोध: "${question}"\n\nमैं आपके लिए क्विज़ बना सकता हूं:\n\n📝 बहुविकल्पीय प्रश्न\n📝 रिक्त स्थान भरें\n📝 लघु उत्तरीय प्रश्न (2 अंक)\n📝 विस्तृत प्रश्न (5 अंक)\n\nकृपया विषय या सामग्री निर्दिष्ट करें।`
        : `Quiz Request: "${question}"\n\nI can create quizzes for you:\n\n📝 Multiple choice questions\n📝 Fill in the blanks\n📝 Short answer questions (2 marks)\n📝 Long answer questions (5 marks)\n\nPlease specify the topic or material.`;
    }

    // General study help
    if (
      lowerQuestion.includes("help") ||
      lowerQuestion.includes("explain") ||
      lowerQuestion.includes("understand")
    ) {
      return language === "ta"
        ? `अध्ययन सहायता: "${question}"\n\n मैं निम्नलिखित में आपकी मदद कर सकता हूं:\n\n📚 अवधारणाओं की व्याख्या\n📚 उदाहरण प��रदान करना\n📚 चरणबद्ध समाधान\n📚 अभ्यास प्रश्न बनाना\n\nकृपया बताएं कि आपको किस विषय में मदद चाहिए।`
        : `Study Help: "${question}"\n\nI can assist you with:\n\n📚 Explaining concepts\n📚 Providing examples\n📚 Step-by-step solutions\n📚 Creating practice questions\n\nPlease let me know which subject you need help with.`;
    }

    // Default response with context
    if (context) {
      return language === "ta"
        ? `आपका प्रश्न: "${question}"\n\nआपके अपलोड किए गए दस्तावेजों के आधार पर, मैं आपकी मदद करने की कोशिश कर रहा हूं। कृपया अधिक विशिष्ट प्रश्न पूछें या मुझे बताएं कि आप क्या जानना चाहते हैं।\n\nउदाहरण प्रश्न:\n• "मुख्य विषय क्या है?"\n• "इसकी व्याख्या करें"\n• "इससे क्विज़ बनाएं"`
        : `Your Question: "${question}"\n\nBased on your uploaded documents, I'm trying to help you. Please ask more specific questions or tell me what you'd like to know.\n\nExample questions:\n• "What is the main topic?"\n• "Explain this concept"\n• "Create a quiz from this"`;
    }

    return language === "ta"
      ? `मैं आपके प्रश्न "${question}" को समझने की कोशिश कर रहा हूं। कृपया अधिक विशिष्ट होकर पूछें या निम्नलिखित कार्य करें:\n\n📤 PDF या इमेज अपलोड करें\n❓ स्पष्ट प्रश्न पूछें\n📝 क्विज़ या टेस्ट के लिए कहें\n📖 किसी विषय की व्याख्या मांगें`
      : `I'm trying to understand your question "${question}". Please be more specific or:\n\n📤 Upload a PDF or image\n❓ Ask a clear question\n📝 Request a quiz or test\n📖 Ask for explanation of a topic`;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    loadUserFiles();
  }, []);

  const loadUserFiles = async () => {
    try {
      const response = await fetch("/api/files/default-user");
      if (response.ok) {
        const data = await response.json();
        setUploadedFiles(data.files);
      }
    } catch (error) {
      console.error("Failed to load files:", error);
    }
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const formData = new FormData();

    Array.from(files).forEach((file) => {
      formData.append("files", file);
    });
    formData.append("userId", "default-user");

    try {
      const response = await fetch("/api/files/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        await loadUserFiles();

        // Add upload success message
        const uploadMessage: Message = {
          id: Date.now().toString(),
          type: "bot",
          content:
            language === "ta"
              ? `${data.files.length} கோப்புகள் வெற்றிகரமாக பதிவேற்றப்பட்டன. இப்போது நீங்கள் இந்த ஆவணங்களைப் பற்றி கேள்விகள் கேட்கலாம்!`
              : `${data.files.length} files uploaded successfully! You can now ask questions about these documents.`,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, uploadMessage]);
      } else {
        throw new Error("Upload failed");
      }
    } catch (error) {
      console.error("Upload error:", error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        type: "bot",
        content:
          language === "ta"
            ? "மன்னிக்கவும், கோப்பு பதிவேற்றத்தில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்."
            : "Sorry, there was an error uploading the files. Please try again.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
      answerLength,
    };

    setMessages((prev) => [...prev, userMessage]);
    const currentInput = inputValue;
    setInputValue("");
    clearTranscript();
    setIsLoading(true);

    try {
      // Get combined content from selected files
      let context = "";
      if (selectedFiles.length > 0) {
        const contextResponse = await fetch("/api/files/combined-content", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: "default-user",
            fileIds: selectedFiles,
          }),
        });

        if (contextResponse.ok) {
          const contextData = await contextResponse.json();
          context = contextData.content;
        }
      }

      // Build conversation context for ChatGPT-like continuity
      const conversationHistory = messages
        .slice(-6) // Last 6 messages for context
        .map(
          (msg) =>
            `${msg.type === "user" ? "User" : "Assistant"}: ${msg.content}`,
        )
        .join("\n");

      const enhancedPrompt = `You are StudyMate AI, an intelligent educational assistant. Maintain conversation context and provide helpful, educational responses.

${context ? `Available documents context:\n${context}\n\n` : ""}

${conversationHistory ? `Recent conversation:\n${conversationHistory}\n\n` : ""}

Current question: ${currentInput}

Please provide a helpful response in ${language === "ta" ? "Tamil" : "English"} language. Be conversational and maintain context from previous messages.`;

      // Send to AI
      const aiResponse = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: enhancedPrompt,
          context: context,
          language: language,
          answerLength: answerLength,
          type: "question",
        }),
      });

      if (aiResponse.ok) {
        const data = await aiResponse.json();
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "bot",
          content: data.response,
          timestamp: new Date(),
          flowchart: data.flowchart,
        };
        setMessages((prev) => [...prev, botMessage]);

        // Save conversation context
        setConversation((prev) =>
          [
            ...prev,
            { id: userMessage.id, context: currentInput },
            { id: botMessage.id, context: data.response },
          ].slice(-10),
        ); // Keep last 10 exchanges
      } else {
        // Create intelligent fallback response based on question
        const fallbackResponse = generateFallbackResponse(
          currentInput,
          context,
          language,
        );
        const fallbackMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "bot",
          content: fallbackResponse,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, fallbackMessage]);
      }
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content:
          language === "ta"
            ? "மன்னிக்கவும், தற்போது பதில் அளிக்க முடியவில்லை. பின்னர் முயற்சிக்கவும்."
            : "Sorry, I cannot provide an answer right now. Please try again later.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: "1",
        type: "bot",
        content:
          language === "ta"
            ? "அரட்டை துடைக்கப்பட்��து. புதிய கேள்வி கேட்கலாம்!"
            : "Chat cleared. You can start asking new questions!",
        timestamp: new Date(),
      },
    ]);
  };

  const toggleFileSelection = (fileId: string) => {
    setSelectedFiles((prev) =>
      prev.includes(fileId)
        ? prev.filter((id) => id !== fileId)
        : [...prev, fileId],
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-4 gap-6">
          {/* Sidebar - File Management */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center space-x-2">
                  <FileText className="w-5 h-5" />
                  <span>{language === "ta" ? "ஆவணங்கள்" : "Documents"}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full"
                  variant="outline"
                >
                  {isUploading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4 mr-2" />
                  )}
                  {language === "ta" ? "PDF பதிவேற்று" : "Upload PDF"}
                </Button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,image/*"
                  multiple
                  max={4}
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <Separator />

                <div className="space-y-2">
                  <p className="text-sm font-medium">
                    {language === "ta"
                      ? "பதிவேற்றப்பட்ட கோப்புகள்:"
                      : "Uploaded Files:"}
                  </p>

                  {uploadedFiles.length === 0 ? (
                    <p className="text-xs text-muted-foreground">
                      {language === "ta"
                        ? "கோப்புகள் இல்லை"
                        : "No files uploaded"}
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {uploadedFiles.map((file) => (
                        <div
                          key={file.id}
                          className={`p-2 rounded border cursor-pointer transition-colors ${
                            selectedFiles.includes(file.id)
                              ? "bg-primary/10 border-primary"
                              : "bg-muted/30 border-border hover:bg-muted/50"
                          }`}
                          onClick={() => toggleFileSelection(file.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">
                                {file.originalName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {(file.size / 1024).toFixed(1)} KB
                              </p>
                            </div>
                            <Badge
                              variant={
                                file.type === "pdf" ? "default" : "secondary"
                              }
                              className="text-xs"
                            >
                              {file.type.toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedFiles.length > 0 && (
                    <p className="text-xs text-primary font-medium">
                      {selectedFiles.length}{" "}
                      {language === "ta"
                        ? "கோப்புகள் தேர்ந்தெடுக்கப்பட்டன"
                        : "files selected"}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Answer Length Selector */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">
                  {language === "ta" ? "பதில் நீளம்" : "Answer Length"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Select
                  value={answerLength}
                  onValueChange={(value: "1" | "2" | "3") =>
                    setAnswerLength(value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">
                      {language === "ta"
                        ? "1 மதிப்பெண் (சுருக்கம்)"
                        : "1 Mark (Brief)"}
                    </SelectItem>
                    <SelectItem value="2">
                      {language === "ta"
                        ? "2 மதிப்பெண் (விரிவான)"
                        : "2 Marks (Detailed)"}
                    </SelectItem>
                    <SelectItem value="3">
                      {language === "ta"
                        ? "3 மதிப்பெண் (முழுமையான)"
                        : "3 Marks (Comprehensive)"}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </div>

          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            <Card className="h-[80vh] flex flex-col">
              <CardHeader className="flex-shrink-0 pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Bot className="w-5 h-5 text-primary" />
                    <span>
                      {language === "ta" ? "AI உதவியாளர்" : "AI Assistant"}
                    </span>
                  </CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={clearChat}>
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              {/* Messages */}
              <CardContent className="flex-1 flex flex-col p-0">
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.type === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          <div className="flex items-start space-x-2">
                            {message.type === "bot" ? (
                              <Bot className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            ) : (
                              <User className="w-5 h-5 flex-shrink-0 mt-0.5" />
                            )}
                            <div className="flex-1">
                              <p className="text-sm whitespace-pre-wrap">
                                {message.content}
                              </p>

                              {message.flowchart && (
                                <div className="mt-3 p-3 bg-background/50 rounded border">
                                  <p className="text-xs font-medium mb-2">
                                    {language === "ta"
                                      ? "प्रवाह चार्ट:"
                                      : "Flowchart:"}
                                  </p>
                                  <pre className="text-xs whitespace-pre-wrap font-mono">
                                    {message.flowchart}
                                  </pre>
                                </div>
                              )}

                              <div className="flex items-center justify-between mt-2">
                                <p className="text-xs opacity-70">
                                  {message.timestamp.toLocaleTimeString()}
                                </p>
                                <div className="flex items-center space-x-1">
                                  {message.answerLength && (
                                    <Badge
                                      variant="secondary"
                                      className="text-xs"
                                    >
                                      {message.answerLength}{" "}
                                      {language === "ta" ? "மதிப்பெண்" : "mark"}
                                    </Badge>
                                  )}
                                  {message.type === "bot" && (
                                    <>
                                      {voiceSupported && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() => speak(message.content)}
                                          className="h-6 px-2"
                                        >
                                          <Volume2 className="w-3 h-3" />
                                        </Button>
                                      )}
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() =>
                                          navigator.clipboard.writeText(
                                            message.content,
                                          )
                                        }
                                        className="h-6 px-2"
                                      >
                                        <Copy className="w-3 h-3" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                          if (navigator.share) {
                                            navigator.share({
                                              title: "StudyMate AI Response",
                                              text: message.content,
                                            });
                                          }
                                        }}
                                        className="h-6 px-2"
                                      >
                                        <Share2 className="w-3 h-3" />
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}

                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-muted rounded-lg p-3">
                          <div className="flex items-center space-x-2">
                            <Bot className="w-5 h-5 text-primary" />
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span className="text-sm">
                              {language === "ta"
                                ? "சிந்திக்கிறது..."
                                : "Thinking..."}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div ref={messagesEndRef} />
                </ScrollArea>

                {/* Input Area */}
                <div className="border-t p-4">
                  <div className="flex space-x-2">
                    <Input
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={
                        isListening
                          ? language === "ta"
                            ? "बोल रहे हैं..."
                            : "Listening..."
                          : language === "ta"
                            ? "உங்கள் கேள்வியை இங்கே எழுதுங்கள்..."
                            : "Type your question here..."
                      }
                      disabled={isLoading}
                      className="flex-1"
                    />

                    {voiceSupported && (
                      <Button
                        variant={isListening ? "destructive" : "outline"}
                        size="icon"
                        onClick={isListening ? stopListening : startListening}
                        disabled={isLoading}
                      >
                        {isListening ? (
                          <MicOff className="w-4 h-4" />
                        ) : (
                          <Mic className="w-4 h-4" />
                        )}
                      </Button>
                    )}

                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputValue.trim() || isLoading}
                      size="icon"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>

                  {voiceError && (
                    <p className="text-xs text-destructive mt-1">
                      {voiceError}
                    </p>
                  )}

                  {selectedFiles.length > 0 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      {language === "ta"
                        ? `${selectedFiles.length} ஆவணங்களிலிருந்து பதில் தரப்படும்`
                        : `Answer will be based on ${selectedFiles.length} selected document(s)`}
                    </p>
                  )}

                  {voiceSupported && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {language === "ta"
                        ? "माइक बटन दबाकर बोलें या टाइप करें"
                        : "Press mic button to speak or type your question"}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
