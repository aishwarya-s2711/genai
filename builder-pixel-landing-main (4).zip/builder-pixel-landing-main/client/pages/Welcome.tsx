import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/lib/contexts";
import {
  Upload,
  FileText,
  MessageSquare,
  Brain,
  ArrowRight,
  Sparkles,
} from "lucide-react";

export default function Welcome() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const handleGetStarted = () => {
    navigate("/home");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          {/* Welcome Message */}
          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Sparkles className="w-8 h-8 text-primary animate-pulse" />
              <h2 className="text-5xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                {t("welcomeMessage")}
              </h2>
              <Sparkles className="w-8 h-8 text-accent animate-pulse" />
            </div>
            <p className="text-2xl text-muted-foreground font-medium">
              Upload, Read, Take Tests, and Learn
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Your intelligent study companion powered by IBM Granite AI is
              ready to help you learn smarter, not harder. Get personalized
              insights, generate custom tests, and master any subject.
            </p>
          </div>

          {/* Feature Preview Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 my-12">
            <Card className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2">
              <CardContent className="p-0 text-center space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Upload Content</h3>
                <p className="text-sm text-muted-foreground">
                  Upload pictures and PDFs to get started with your studies
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2">
              <CardContent className="p-0 text-center space-y-3">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mx-auto">
                  <FileText className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-semibold text-lg">Smart Reading</h3>
                <p className="text-sm text-muted-foreground">
                  AI reads your documents and provides intelligent insights
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2">
              <CardContent className="p-0 text-center space-y-3">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Ask Questions</h3>
                <p className="text-sm text-muted-foreground">
                  Get relevant answers with customizable detail levels
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2">
              <CardContent className="p-0 text-center space-y-3">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mx-auto">
                  <Brain className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-semibold text-lg">Generate Tests</h3>
                <p className="text-sm text-muted-foreground">
                  Auto-create quizzes and tests from your content
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Call to Action */}
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border-2">
              <h3 className="text-2xl font-bold mb-4">
                Ready to Transform Your Learning?
              </h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Join thousands of students who are already using StudyMate to
                excel in their studies. Let's unlock your learning potential
                together.
              </p>
              <Button
                onClick={handleGetStarted}
                size="lg"
                className="text-lg px-8 py-6 h-auto group"
              >
                {t("getStarted")}
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
