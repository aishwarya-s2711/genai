import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useLanguage } from "@/lib/contexts";
import {
  Clock,
  CheckCircle,
  XCircle,
  RotateCcw,
  FileText,
  Award,
  Loader2,
  Play,
  BookOpen,
} from "lucide-react";

interface QuizQuestion {
  id: string;
  type: "multiple_choice" | "fill_blank" | "short_answer" | "long_answer";
  question: string;
  options?: string[];
  correctAnswer: string;
  points: number;
  explanation?: string;
}

interface UploadedFile {
  id: string;
  originalName: string;
}

export default function QuizPage() {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [isQuizStarted, setIsQuizStarted] = useState(false);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes
  const [isTimerActive, setIsTimerActive] = useState(false);

  useEffect(() => {
    loadUserFiles();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => {
          if (time <= 1) {
            setIsTimerActive(false);
            handleSubmitQuiz();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerActive, timeLeft]);

  const loadUserFiles = async () => {
    try {
      const response = await fetch("/api/files/default-user");
      if (response.ok) {
        const data = await response.json();
        setFiles(data.files);
      }
    } catch (error) {
      console.error("Failed to load files:", error);
    }
  };

  const generateQuiz = async () => {
    if (selectedFiles.length === 0) {
      alert(
        language === "ta"
          ? "முதலில் கோப்புகளை தேர்ந்தெடுக்கவும்"
          : "Please select files first",
      );
      return;
    }

    setIsGenerating(true);
    try {
      // Get combined content
      const contextResponse = await fetch("/api/files/combined-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "default-user",
          fileIds: selectedFiles,
        }),
      });

      if (!contextResponse.ok) throw new Error("Failed to get content");

      const contextData = await contextResponse.json();

      // Generate quiz using AI
      const quizResponse = await fetch("/api/ai/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: contextData.content,
          language: language,
          type: "quiz",
        }),
      });

      if (!quizResponse.ok) throw new Error("Failed to generate quiz");

      const quizData = await quizResponse.json();
      const parsedQuestions = parseQuizResponse(quizData.response);
      setQuestions(parsedQuestions);
      setIsQuizStarted(true);
      setIsTimerActive(true);
    } catch (error) {
      console.error("Quiz generation error:", error);
      alert(
        language === "ta"
          ? "வினாடி வினா உருவாக்கம் தோல்வியடைந்தது"
          : "Failed to generate quiz",
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const parseQuizResponse = (response: string): QuizQuestion[] => {
    const questions: QuizQuestion[] = [];
    const sections = response.split(
      /MULTIPLE CHOICE:|FILL IN THE BLANKS:|SHORT ANSWER|LONG ANSWER/i,
    );

    // Parse multiple choice questions
    const mcSection = sections[1];
    if (mcSection) {
      const mcQuestions = mcSection.split(/\d+\./).filter((q) => q.trim());
      mcQuestions.forEach((q, index) => {
        const lines = q
          .trim()
          .split("\n")
          .filter((line) => line.trim());
        if (lines.length >= 5) {
          const questionText = lines[0];
          const options = lines
            .slice(1, 5)
            .map((opt) => opt.replace(/^[a-d]\)\s*/, ""));
          const correctLine = lines.find((line) =>
            line.toLowerCase().includes("correct answer:"),
          );
          const correctAnswer = correctLine
            ? options[
                correctLine.charCodeAt(correctLine.indexOf(":") + 2) - 97
              ] || options[0]
            : options[0];

          questions.push({
            id: `mc_${index}`,
            type: "multiple_choice",
            question: questionText,
            options,
            correctAnswer,
            points: 2,
          });
        }
      });
    }

    // Parse fill in the blanks
    const fibSection = sections[2];
    if (fibSection) {
      const fibQuestions = fibSection.split(/\d+\./).filter((q) => q.trim());
      fibQuestions.forEach((q, index) => {
        const lines = q
          .trim()
          .split("\n")
          .filter((line) => line.trim());
        if (lines.length >= 2) {
          const questionText = lines[0];
          const answerLine = lines.find((line) =>
            line.toLowerCase().includes("answer:"),
          );
          const correctAnswer = answerLine
            ? answerLine.split(":")[1]?.trim() || ""
            : "";

          questions.push({
            id: `fib_${index}`,
            type: "fill_blank",
            question: questionText,
            correctAnswer,
            points: 2,
          });
        }
      });
    }

    // Parse short answer (2 marks)
    const shortSection = sections[3];
    if (shortSection) {
      const shortQuestions = shortSection
        .split(/\d+\./)
        .filter((q) => q.trim());
      shortQuestions.forEach((q, index) => {
        const questionText = q.trim().split("\n")[0];
        if (questionText) {
          questions.push({
            id: `short_${index}`,
            type: "short_answer",
            question: questionText,
            correctAnswer: "",
            points: 2,
          });
        }
      });
    }

    // Parse long answer (5 marks)
    const longSection = sections[4];
    if (longSection) {
      const longQuestions = longSection.split(/\d+\./).filter((q) => q.trim());
      longQuestions.forEach((q, index) => {
        const questionText = q.trim().split("\n")[0];
        if (questionText) {
          questions.push({
            id: `long_${index}`,
            type: "long_answer",
            question: questionText,
            correctAnswer: "",
            points: 5,
          });
        }
      });
    }

    return questions.length > 0
      ? questions
      : [
          {
            id: "sample_1",
            type: "multiple_choice",
            question:
              language === "ta"
                ? "இது ஒரு மாதிரி கேள்வி. உங்கள் PDF இலிருந்து கேள்விகள் உருவாக்கப்படும்."
                : "This is a sample question. Questions will be generated from your PDFs.",
            options: ["Option A", "Option B", "Option C", "Option D"],
            correctAnswer: "Option A",
            points: 2,
          },
        ];
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }));
  };

  const handleSubmitQuiz = () => {
    setIsTimerActive(false);

    let totalScore = 0;
    const totalPossible = questions.reduce((sum, q) => sum + q.points, 0);

    questions.forEach((question) => {
      const userAnswer = answers[question.id];
      if (
        question.type === "multiple_choice" ||
        question.type === "fill_blank"
      ) {
        if (
          userAnswer?.toLowerCase().trim() ===
          question.correctAnswer.toLowerCase().trim()
        ) {
          totalScore += question.points;
        }
      } else {
        // For short/long answers, give partial credit based on length and presence
        if (userAnswer && userAnswer.trim().length > 10) {
          totalScore += Math.floor(question.points * 0.7); // 70% credit for attempt
        }
      }
    });

    setScore(Math.round((totalScore / totalPossible) * 100));
    setIsQuizCompleted(true);
  };

  const restartQuiz = () => {
    setIsQuizStarted(false);
    setIsQuizCompleted(false);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setTimeLeft(1800);
    setScore(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  if (isQuizCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
              <Award className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-3xl">
              {language === "ta" ? "வினாடி வினா முடிந்தது!" : "Quiz Completed!"}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="text-6xl font-bold text-primary">{score}%</div>
            <p className="text-xl text-muted-foreground">
              {language === "ta"
                ? `${questions.length} கேள்விகளில் ${Math.floor((questions.length * score) / 100)} சரி`
                : `${Math.floor((questions.length * score) / 100)} out of ${questions.length} questions correct`}
            </p>

            <div className="flex justify-center space-x-4">
              <Button onClick={restartQuiz} variant="outline">
                <RotateCcw className="w-4 h-4 mr-2" />
                {language === "ta" ? "மீண்டும் முயற்சி" : "Retake Quiz"}
              </Button>
              <Button onClick={() => navigate("/home")}>
                {language === "ta" ? "முகப்புக்கு செல்" : "Back to Home"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isQuizStarted) {
    const currentQuestion = questions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="container mx-auto px-4 py-6">
          <div className="max-w-4xl mx-auto">
            {/* Quiz Header */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Badge variant="outline">
                      {language === "ta" ? "கேள்வி" : "Question"}{" "}
                      {currentQuestionIndex + 1} / {questions.length}
                    </Badge>
                    <Badge variant="secondary">
                      {currentQuestion.points}{" "}
                      {language === "ta" ? "மதிப்பெண்கள்" : "points"}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4" />
                      <span
                        className={`font-mono ${timeLeft < 300 ? "text-destructive" : ""}`}
                      >
                        {formatTime(timeLeft)}
                      </span>
                    </div>
                  </div>
                </div>
                <Progress value={progress} className="mt-4" />
              </CardContent>
            </Card>

            {/* Question */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">
                  {currentQuestion.question}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentQuestion.type === "multiple_choice" && (
                  <RadioGroup
                    value={answers[currentQuestion.id] || ""}
                    onValueChange={(value) =>
                      handleAnswerChange(currentQuestion.id, value)
                    }
                  >
                    {currentQuestion.options?.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <RadioGroupItem value={option} id={`option-${index}`} />
                        <Label htmlFor={`option-${index}`} className="flex-1">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}

                {currentQuestion.type === "fill_blank" && (
                  <Input
                    placeholder={
                      language === "ta" ? "உங்கள் பதில்..." : "Your answer..."
                    }
                    value={answers[currentQuestion.id] || ""}
                    onChange={(e) =>
                      handleAnswerChange(currentQuestion.id, e.target.value)
                    }
                  />
                )}

                {currentQuestion.type === "short_answer" && (
                  <Textarea
                    placeholder={
                      language === "ta"
                        ? "உங்கள் பதில் (2-3 வாக்கியங்கள்)..."
                        : "Your answer (2-3 sentences)..."
                    }
                    value={answers[currentQuestion.id] || ""}
                    onChange={(e) =>
                      handleAnswerChange(currentQuestion.id, e.target.value)
                    }
                    rows={3}
                  />
                )}

                {currentQuestion.type === "long_answer" && (
                  <Textarea
                    placeholder={
                      language === "ta"
                        ? "விரிவான பதில் (பல பத்திகள்)..."
                        : "Detailed answer (multiple paragraphs)..."
                    }
                    value={answers[currentQuestion.id] || ""}
                    onChange={(e) =>
                      handleAnswerChange(currentQuestion.id, e.target.value)
                    }
                    rows={6}
                  />
                )}

                <div className="flex justify-between pt-4">
                  <Button
                    variant="outline"
                    onClick={() =>
                      setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))
                    }
                    disabled={currentQuestionIndex === 0}
                  >
                    {language === "ta" ? "முந்தைய" : "Previous"}
                  </Button>

                  {currentQuestionIndex === questions.length - 1 ? (
                    <Button
                      onClick={handleSubmitQuiz}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      {language === "ta" ? "சமர்ப்பிக்கவும்" : "Submit Quiz"}
                    </Button>
                  ) : (
                    <Button
                      onClick={() =>
                        setCurrentQuestionIndex((prev) =>
                          Math.min(questions.length - 1, prev + 1),
                        )
                      }
                    >
                      {language === "ta" ? "அடுத்த" : "Next"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center space-x-2">
                <BookOpen className="w-6 h-6" />
                <span>
                  {language === "ta" ? "AI वினাडী வינা" : "AI Quiz Generator"}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-3">
                  {language === "ta"
                    ? "கோப்புகளை தேர்ந்தெடுக்கவும்:"
                    : "Select Files for Quiz:"}
                </h3>

                {files.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      {language === "ta"
                        ? "வினாடி வினா உருவாக்க முதலில் PDF கோப்புகளை பதிவேற்றவும்"
                        : "Upload PDF files first to generate quizzes"}
                    </p>
                    <Button
                      className="mt-4"
                      onClick={() => navigate("/ask-questions")}
                    >
                      {language === "ta"
                        ? "கோப்புகள் பதிவேற்று"
                        : "Upload Files"}
                    </Button>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-3">
                    {files.map((file) => (
                      <div
                        key={file.id}
                        className={`p-3 rounded border cursor-pointer transition-colors ${
                          selectedFiles.includes(file.id)
                            ? "bg-primary/10 border-primary"
                            : "bg-muted/30 border-border hover:bg-muted/50"
                        }`}
                        onClick={() => {
                          setSelectedFiles((prev) =>
                            prev.includes(file.id)
                              ? prev.filter((id) => id !== file.id)
                              : [...prev, file.id],
                          );
                        }}
                      >
                        <div className="flex items-center space-x-2">
                          <FileText className="w-4 h-4" />
                          <span className="font-medium">
                            {file.originalName}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {selectedFiles.length > 0 && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    {language === "ta"
                      ? `${selectedFiles.length} கோப்புகள் தேர்ந்தெடுக்கப்பட்டன. AI இந்த ஆவணங்களிலிருந்து கேள்விகளை உருவாக்கும்.`
                      : `${selectedFiles.length} files selected. AI will generate questions from these documents.`}
                  </p>

                  <Button
                    onClick={generateQuiz}
                    disabled={isGenerating}
                    size="lg"
                    className="w-full"
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {language === "ta"
                          ? "வினாডী வினா உருவാக்கிறது..."
                          : "Generating Quiz..."}
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        {language === "ta"
                          ? "வினाडী வினா தொடங்கு"
                          : "Start Quiz"}
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
