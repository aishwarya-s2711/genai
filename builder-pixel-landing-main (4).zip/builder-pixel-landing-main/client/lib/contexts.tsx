import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";

type Theme = "light" | "dark";
type Language = "en" | "ta";

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);
const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined,
);

// Language translations
const translations = {
  en: {
    // Common
    studymate: "StudyMate",
    welcome: "Welcome",
    home: "Home",
    logout: "Logout",
    back: "Back",
    loading: "Loading...",
    error: "Error",
    success: "Success",
    cancel: "Cancel",
    confirm: "Confirm",
    save: "Save",
    delete: "Delete",
    edit: "Edit",
    upload: "Upload",
    download: "Download",
    share: "Share",

    // Navigation
    sign_in: "Sign In",
    sign_up: "Sign Up",
    upload_pdf: "Upload PDF",
    upload_picture: "Upload Picture",
    ask_questions: "Ask Questions",
    schedule: "Schedule",
    history: "History",
    rating_feedback: "Rating & Feedback",

    // Forms
    email: "Email",
    password: "Password",
    confirm_password: "Confirm Password",
    full_name: "Full Name",
    remember_me: "Remember me",
    forgot_password: "Forgot password?",
    dont_have_account: "Don't have an account?",
    already_have_account: "Already have an account?",

    // Messages
    welcome_back: "Welcome back!",
    create_account: "Create your account",
    sign_in_continue: "Sign in to continue to StudyMate",
    sign_up_start: "Sign up to start learning with StudyMate",
    invalid_credentials: "Invalid email or password",
    account_created: "Account created successfully!",
    something_went_wrong: "Something went wrong. Please try again.",

    // Features
    upload_analyze: "Upload & Analyze",
    ai_powered: "AI-Powered Learning Assistant",
    ask_questions_desc: "Ask questions and get intelligent answers",
    generate_quiz: "Generate Quiz",
    voice_support: "Voice Support",
    multi_language: "Multi-language Support",

    // File operations
    upload_pdf_desc: "Upload PDF files for analysis",
    upload_picture_desc: "Upload pictures for analysis",
    no_files: "No files uploaded yet",
    file_uploaded: "File uploaded successfully",
    file_deleted: "File deleted successfully",
    max_files: "Maximum files limit reached",

    // AI features
    ai_analyzing: "AI is analyzing...",
    generating_response: "Generating response...",
    analysis_complete: "Analysis complete",
    ask_question: "Ask a question",
    get_answer: "Get Answer",
    quiz_generated: "Quiz generated successfully",
    qa_generated: "Q&A generated successfully",
  },
  ta: {
    // Common
    studymate: "ஸ்ட்டடிமேட்",
    welcome: "வரவேற்கிறோம்",
    home: "முகப்பு",
    logout: "வெளியேறு",
    back: "திரும்பு",
    loading: "ஏற்றுகிறது...",
    error: "பிழை",
    success: "வெற்றி",
    cancel: "ரத்து",
    confirm: "உறுதி",
    save: "சேமி",
    delete: "நீக்கு",
    edit: "திருத்து",
    upload: "பதிவேற்று",
    download: "பதிவிறக்கு",
    share: "பகிர்",

    // Navigation
    sign_in: "உள்நுழைவு",
    sign_up: "பதிவு",
    upload_pdf: "PDF பதிவேற்று",
    upload_picture: "படம் ப���ிவேற்று",
    ask_questions: "கேள்விகள் கேட்கவும்",
    schedule: "அட்டவணை",
    history: "வரலாறு",
    rating_feedback: "மதிப்பீடு & கருத்து",

    // Forms
    email: "மின்னஞ்சல்",
    password: "கடவுச்சொல்",
    confirm_password: "கடவுச்சொல் உறுதி",
    full_name: "முழு பெயர்",
    remember_me: "என்னை நினைவில் கொள்",
    forgot_password: "கடவுச்சொல் மறந்தீர்களா?",
    dont_have_account: "கணக்கு இல்லையா?",
    already_have_account: "ஏற்கனவே கணக்கு உள்ளதா?",

    // Messages
    welcome_back: "மீண்டும் வரவேற்கிறோம்!",
    create_account: "உங்கள் கணக்கை உருவாக்கவும்",
    sign_in_continue: "ஸ்ட்டடிமேட்டில் தொடர உள்நுழையவும்",
    sign_up_start: "ஸ்ட்டடிமேட்டுடன் கற்க பதிவு ��ெய்யவும்",
    invalid_credentials: "தவறான மின்னஞ்சல் அல்லது கடவுச்சொல்",
    account_created: "கணக்கு ���ெற்றிகரமாக உருவாக்கப்பட்டது!",
    something_went_wrong: "ஏதோ தவறு நடந்தது. மீண்டும் முயற்சிக்கவும்.",

    // Features
    upload_analyze: "பதிவேற்று & பகுப்பாய்வு",
    ai_powered: "AI-இயங்கும் கற்றல் உதவியாளர்",
    ask_questions_desc:
      "கேள்விகள் கேட்டு புத்திசாலித்தனமான பதில்களைப் பெறுங்கள்",
    generate_quiz: "வினாடி வினா உருவாக்கு",
    voice_support: "குரல் ஆதரவு",
    multi_language: "பல மொழி ஆதரவு",

    // File operations
    upload_pdf_desc: "பகுப்பாய்விற்காக PDF கோப்புகளை பதிவேற்றவும்",
    upload_picture_desc: "பகுப்பாய்விற்காக படங்களை பதிவேற்றவும்",
    no_files: "இன்னும் கோப்புகள் பதிவேற்றப்படவில்லை",
    file_uploaded: "கோப்பு வெற்றிகரமாக பதிவேற்றப்பட்டது",
    file_deleted: "கோப்பு வெற்றிகரமாக நீக்கப்பட்டது",
    max_files: "அதிகபட்ச கோப்புகள் வரம்பு அடைந்தது",

    // AI features
    ai_analyzing: "AI பகுப்பாய்வு செய்கிறது...",
    generating_response: "பதிலை உருவாக்குகிறது...",
    analysis_complete: "பகுப்பாய்வு முடிந்தது",
    ask_question: "ஒரு கேள்வி கேட்கவும்",
    get_answer: "பதில் பெறுங்கள்",
    quiz_generated: "வினாடி வினா வெற்றிகரமாக உருவாக்கப்பட்டது",
    qa_generated: "கேள்வி-பதில் வெற்றிகரமாக உருவாக்கப்பட்டது",
  },
};

interface ThemeProviderProps {
  children: ReactNode;
}

interface LanguageProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem("studymate-theme");
      return (saved as Theme) || "light";
    } catch {
      return "light";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("studymate-theme", theme);

      // Apply theme to document
      const root = document.documentElement;
      root.classList.remove("light", "dark");
      root.classList.add(theme);
    } catch (error) {
      console.warn("Failed to save theme preference:", error);
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  const value = {
    theme,
    setTheme,
    toggleTheme,
  };

  return (
    <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
  );
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem("studymate-language");
      return (saved as Language) || "en";
    } catch {
      return "en";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("studymate-language", language);
    } catch (error) {
      console.warn("Failed to save language preference:", error);
    }
  }, [language]);

  const t = (key: string): string => {
    try {
      return translations[language][key] || translations.en[key] || key;
    } catch {
      return key;
    }
  };

  const value = {
    language,
    setLanguage,
    t,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}

// Combined provider for easier usage
interface AppProvidersProps {
  children: ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <ThemeProvider>
      <LanguageProvider>{children}</LanguageProvider>
    </ThemeProvider>
  );
}
