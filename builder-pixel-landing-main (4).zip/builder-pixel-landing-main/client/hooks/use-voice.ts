import { useState, useRef, useCallback, useEffect } from "react";
import { useLanguage } from "@/lib/contexts";

interface VoiceConfig {
  language: string;
  voice?: SpeechSynthesisVoice;
  rate?: number;
  pitch?: number;
  volume?: number;
}

interface UseVoiceReturn {
  isListening: boolean;
  isSupported: boolean;
  isSpeaking: boolean;
  transcript: string;
  error: string | null;
  startListening: (callback?: (transcript: string) => void) => void;
  stopListening: () => void;
  speak: (text: string, config?: Partial<VoiceConfig>) => void;
  stopSpeaking: () => void;
  clearTranscript: () => void;
  getAvailableVoices: () => SpeechSynthesisVoice[];
}

export function useVoice(): UseVoiceReturn {
  const { language } = useLanguage();
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const callbackRef = useRef<((transcript: string) => void) | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Check if speech APIs are supported
  const isSupported =
    typeof window !== "undefined" &&
    ("SpeechRecognition" in window ||
      "webkitSpeechRecognition" in window ||
      "speechSynthesis" in window);

  // Initialize speech synthesis
  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopListening();
      stopSpeaking();
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const initializeRecognition = useCallback(() => {
    if (!isSupported || typeof window === "undefined") return null;

    try {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) return null;

      const recognition = new SpeechRecognition();

      // Configure recognition settings
      recognition.continuous = false; // Set to false for better control
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      // Set language based on current language preference
      const langMap: Record<string, string> = {
        en: "en-US",
        ta: "ta-IN",
      };
      recognition.lang = langMap[language] || "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
        console.log("Speech recognition started");
      };

      recognition.onresult = (event) => {
        try {
          let finalTranscript = "";
          let interimTranscript = "";

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
          }

          const currentTranscript = finalTranscript || interimTranscript;
          setTranscript(currentTranscript);

          // Call the callback if provided and we have final results
          if (finalTranscript && callbackRef.current) {
            callbackRef.current(finalTranscript);
            setIsListening(false);
          }
        } catch (err) {
          console.error("Error processing speech result:", err);
          setError("Error processing speech");
        }
      };

      recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);

        // Filter out common harmless errors
        if (event.error === "no-speech" || event.error === "aborted") {
          setError(null);
        } else {
          setError(`Speech recognition error: ${event.error}`);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        console.log("Speech recognition ended");
      };

      return recognition;
    } catch (err) {
      console.error("Failed to initialize speech recognition:", err);
      setError("Speech recognition not available");
      return null;
    }
  }, [language, isSupported]);

  const startListening = useCallback(
    (callback?: (transcript: string) => void) => {
      if (!isSupported) {
        setError("Speech recognition is not supported in this browser");
        return;
      }

      try {
        // Store the callback
        callbackRef.current = callback || null;

        // Stop any existing recognition
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }

        // Clear previous transcript
        setTranscript("");
        setError(null);

        // Initialize new recognition
        recognitionRef.current = initializeRecognition();
        if (recognitionRef.current) {
          recognitionRef.current.start();

          // Auto-stop after 10 seconds for safety
          timeoutRef.current = setTimeout(() => {
            stopListening();
          }, 10000);
        } else {
          throw new Error("Failed to initialize speech recognition");
        }
      } catch (err) {
        console.error("Error starting speech recognition:", err);
        setError("Failed to start speech recognition");
        setIsListening(false);
      }
    },
    [initializeRecognition, isSupported],
  );

  const stopListening = useCallback(() => {
    try {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }

      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }

      setIsListening(false);
      callbackRef.current = null;
    } catch (err) {
      console.error("Error stopping speech recognition:", err);
      setIsListening(false);
    }
  }, []);

  const speak = useCallback(
    (text: string, config: Partial<VoiceConfig> = {}) => {
      if (!text || !text.trim()) return;

      if (!isSupported || !synthRef.current) {
        setError("Speech synthesis is not supported in this browser");
        return;
      }

      try {
        // Stop any current speech first
        if (synthRef.current.speaking) {
          synthRef.current.cancel();
        }

        // Wait a bit to prevent interruption errors
        setTimeout(() => {
          performSpeak();
        }, 100);

        function performSpeak() {
          if (!synthRef.current) return;

          const utterance = new SpeechSynthesisUtterance(text);

          // Configure voice settings
          const langMap: Record<string, string> = {
            en: "en-US",
            ta: "ta-IN",
          };

          utterance.lang = config.language || langMap[language] || "en-US";
          utterance.rate = config.rate || 0.9;
          utterance.pitch = config.pitch || 1;
          utterance.volume = config.volume || 0.8;

          // Try to find a voice that matches the language
          try {
            const voices = synthRef.current!.getVoices();
            const preferredVoice = voices.find((voice) =>
              voice.lang.startsWith(utterance.lang.split("-")[0]),
            );

            if (preferredVoice) {
              utterance.voice = preferredVoice;
            }
          } catch (voiceErr) {
            console.warn("Could not set voice:", voiceErr);
          }

          utterance.onstart = () => {
            setIsSpeaking(true);
            setError(null);
          };

          utterance.onend = () => {
            setIsSpeaking(false);
          };

          utterance.onerror = (event) => {
            console.error("Speech synthesis error:", event.error);

            // Only set error for serious issues
            if (event.error !== "interrupted" && event.error !== "canceled") {
              setError(`Speech error: ${event.error}`);
            }
            setIsSpeaking(false);
          };

          // Speak the text
          if (synthRef.current && !synthRef.current.speaking) {
            synthRef.current.speak(utterance);
          }
        }
      } catch (err) {
        console.error("Error in speech synthesis:", err);
        setError("Failed to speak text");
        setIsSpeaking(false);
      }
    },
    [isSupported, language],
  );

  const stopSpeaking = useCallback(() => {
    try {
      if (synthRef.current && synthRef.current.speaking) {
        synthRef.current.cancel();
      }
      setIsSpeaking(false);
      setError(null);
    } catch (err) {
      console.error("Error stopping speech:", err);
      setIsSpeaking(false);
    }
  }, []);

  const clearTranscript = useCallback(() => {
    setTranscript("");
    setError(null);
  }, []);

  const getAvailableVoices = useCallback(() => {
    if (!isSupported || !synthRef.current) return [];

    try {
      return synthRef.current.getVoices();
    } catch (err) {
      console.error("Error getting voices:", err);
      return [];
    }
  }, [isSupported]);

  return {
    isListening,
    isSupported,
    isSpeaking,
    transcript,
    error,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    clearTranscript,
    getAvailableVoices,
  };
}
