# StudyMate Development Guide

## 🚀 Running in VS Code - Step by Step

### 1. **Initial Setup**

```bash
# 1.1 Open VS Code
# Option A: From command line
code .

# Option B: File → Open Folder → Select studymate folder
```

```bash
# 1.2 Install all dependencies
npm install

# This installs:
# - React, TypeScript, Vite (frontend)
# - Express, Node.js dependencies (backend)
# - UI libraries (Shadcn/ui, Tailwind)
# - Development tools (ESLint, Prettier)
```

### 2. **Start Development Server**

```bash
# 2.1 Start both frontend and backend
npm run dev

# What this does:
# ✅ Starts Vite dev server on port 8080 (frontend)
# ✅ Starts Express server for APIs (backend)
# ✅ Enables hot reload for both
# ✅ Opens browser automatically
```

```bash
# 2.2 Alternative commands
npm run dev:client    # Frontend only
npm run dev:server    # Backend only
npm run build        # Production build
npm run preview      # Preview production build
```

### 3. **VS Code Features Setup**

#### 3.1 **Install Recommended Extensions**

```bash
# VS Code will prompt to install recommended extensions
# Or install manually with Ctrl+Shift+X

# Essential extensions:
# - TypeScript and JavaScript Language Features
# - ES7+ React/Redux/React-Native snippets
# - Tailwind CSS IntelliSense
# - Prettier - Code formatter
# - ESLint
# - Thunder Client (API testing)
```

#### 3.2 **Use Built-in Tasks**

```bash
# Press Ctrl+Shift+P and type "Tasks: Run Task"

# Available tasks:
# - 📦 Install Dependencies
# - 🚀 Start Development Server
# - 🔧 Build Production
# - 🧪 Type Check
# - 🧹 Clean Build
# - 🌐 Open in Browser
```

#### 3.3 **Debugging Setup**

```bash
# Press F5 or go to Run and Debug panel

# Debug configurations:
# - 🔍 Debug Frontend (Chrome) - Debug React app
# - 🛠 Debug Backend (Node.js) - Debug Express APIs
# - 🚀 Launch Full Stack - Run entire app
# - 🎯 Debug Full Application - Debug both simultaneously
```

## 📁 Project Structure with Comments

```
studymate/
├── .vscode/                    # VS Code configuration
│   ├── settings.json          # Workspace settings
│   ├── launch.json            # Debug configurations
│   ├── tasks.json             # Automated tasks
│   └── extensions.json        # Recommended extensions
│
├── client/                     # Frontend React application
│   ├── components/            # Reusable UI components
│   │   ├── ui/               # Shadcn/ui base components
│   │   │   ├── button.tsx    # Button component
│   │   │   ├── card.tsx      # Card component
│   │   │   ├── input.tsx     # Input component
│   │   │   └── ...           # More UI components
│   │   └── Header.tsx        # Main navigation header
│   │
│   ├── hooks/                # Custom React hooks
│   │   ├── use-voice.ts      # Voice recognition & synthesis
│   │   ├── use-toast.ts      # Toast notifications
│   │   └── use-mobile.tsx    # Mobile detection
│   │
│   ├── lib/                  # Utility libraries
│   │   ├── contexts.tsx      # React contexts (Theme, Language)
│   │   └── utils.ts          # Helper functions
│   │
│   ├── pages/                # Application pages/routes
│   │   ├── Auth.tsx          # 🔐 Login/Register page
│   │   ├── Home.tsx          # 🏠 Dashboard/landing page
│   │   ├── UploadPDF.tsx     # 📄 PDF upload & analysis
│   │   ├── UploadPicture.tsx # 📸 Image upload & analysis
│   │   ├── AskQuestions.tsx  # 💬 Q&A chat interface
│   │   ├── History.tsx       # 📚 User activity history
│   │   ├── Schedule.tsx      # 📅 Study scheduling
│   │   ├── RatingFeedback.tsx# ⭐ User feedback system
│   │   └── ...               # More pages
│   │
│   ├── App.tsx               # 🎯 Main app component & routing
│   ├── global.css            # 🎨 Global styles (Tailwind CSS)
│   └── vite-env.d.ts         # TypeScript environment types
│
├── server/                   # Backend Express application
│   ├── services/             # Business logic services
│   │   ├── ai.ts            # 🤖 AI/Chat functionality
│   │   └── files.ts         # 📁 File upload/processing
│   ├── routes/              # API route handlers
│   │   └── demo.ts          # Example routes
│   └── index.ts             # 🛠 Express server setup
│
├── shared/                  # Shared utilities between client/server
│   └── api.ts               # Shared API types
│
├── public/                  # Static assets
│   ├── placeholder.svg      # Default images
│   └── robots.txt          # SEO configuration
│
├── uploads/                 # File upload storage (auto-created)
│
├── package.json             # 📦 Dependencies and scripts
├── vite.config.ts           # ⚡ Vite configuration
├── tailwind.config.ts       # 🎨 Tailwind CSS configuration
├── tsconfig.json            # 📝 TypeScript configuration
├── README.md               # 📖 Project documentation
└── DEVELOPMENT.md          # 👨‍💻 This development guide
```

## 🔧 Development Workflow

### **Daily Development Process:**

```bash
# 1. Open VS Code
code .

# 2. Pull latest changes (if team project)
git pull

# 3. Install any new dependencies
npm install

# 4. Start development server
npm run dev

# 5. Start coding!
# - Edit files in client/ for frontend changes
# - Edit files in server/ for backend changes
# - Changes auto-reload in browser

# 6. Test your changes
# - Use browser at http://localhost:8080
# - Check console for errors
# - Test APIs with Thunder Client

# 7. Commit changes
git add .
git commit -m "Your commit message"
git push
```

### **Key Development Commands:**

```bash
# Type checking (find TypeScript errors)
npm run type-check

# Format code with Prettier
npm run format

# Build for production
npm run build

# Preview production build
npm run preview

# Clean build artifacts
rm -rf dist node_modules/.vite
```

## 🐛 Debugging Guide

### **Frontend Debugging:**

1. **Browser DevTools:**

   ```bash
   # F12 in browser
   # Console tab - for JavaScript errors
   # Network tab - for API calls
   # Sources tab - for breakpoints
   ```

2. **VS Code Debugging:**

   ```bash
   # Press F5 → "Debug Frontend (Chrome)"
   # Set breakpoints in .tsx files
   # Step through code with F10/F11
   ```

3. **React DevTools:**
   ```bash
   # Install React Developer Tools browser extension
   # Inspect React components and state
   ```

### **Backend Debugging:**

1. **VS Code Debugging:**

   ```bash
   # Press F5 → "Debug Backend (Node.js)"
   # Set breakpoints in .ts files
   # Inspect variables and call stack
   ```

2. **Console Logging:**

   ```typescript
   // In server files
   console.log("Debug info:", data);
   console.error("Error:", error);
   ```

3. **API Testing:**
   ```bash
   # Use Thunder Client extension
   # Test endpoints: /api/ping, /api/files/*, /api/ai/*
   ```

## 📝 Code Organization

### **Frontend Structure:**

```typescript
// pages/ExamplePage.tsx - Page components
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/lib/contexts';

export default function ExamplePage() {
  const { language, t } = useLanguage();
  const [state, setState] = useState();

  return (
    <div>
      <h1>{t('title')}</h1>
      <Button onClick={() => {}}>
        {t('button')}
      </Button>
    </div>
  );
}
```

```typescript
// hooks/use-example.ts - Custom hooks
import { useState, useEffect } from "react";

export function useExample() {
  const [data, setData] = useState(null);

  useEffect(() => {
    // Side effects
  }, []);

  return { data, setData };
}
```

### **Backend Structure:**

```typescript
// services/example.ts - Business logic
import { RequestHandler } from "express";

export const handleExample: RequestHandler = async (req, res) => {
  try {
    // Process request
    const result = await processData(req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
```

## 🔍 Troubleshooting

### **Common Issues:**

1. **Port 8080 already in use:**

   ```bash
   # Kill process on port 8080
   npx kill-port 8080

   # Or use different port
   PORT=3000 npm run dev
   ```

2. **Dependencies issues:**

   ```bash
   # Clear and reinstall
   rm -rf node_modules package-lock.json
   npm install
   ```

3. **TypeScript errors:**

   ```bash
   # Restart TS server in VS Code
   Ctrl+Shift+P → "TypeScript: Restart TS Server"
   ```

4. **Build failures:**

   ```bash
   # Check for type errors
   npm run type-check

   # Clean build
   npm run build
   ```

5. **Hot reload not working:**
   ```bash
   # Restart development server
   Ctrl+C (stop server)
   npm run dev (restart)
   ```

### **VS Code Specific Issues:**

1. **Extensions not working:**

   ```bash
   # Reload VS Code window
   Ctrl+Shift+P → "Developer: Reload Window"
   ```

2. **IntelliSense not working:**

   ```bash
   # Check TypeScript version
   Ctrl+Shift+P → "TypeScript: Select TypeScript Version"
   # Choose "Use Workspace Version"
   ```

3. **Debugger not hitting breakpoints:**
   ```bash
   # Ensure source maps are enabled
   # Check launch.json configuration
   # Restart debug session
   ```

## 🎯 Testing Features

### **Manual Testing Checklist:**

- [ ] **Authentication:** Login/Register works
- [ ] **PDF Upload:** Can upload and analyze PDFs
- [ ] **Image Upload:** Can upload and analyze images
- [ ] **AI Chat:** Can ask questions and get responses
- [ ] **Voice Features:** Speech recognition and synthesis
- [ ] **Quiz Generation:** Can create quizzes from content
- [ ] **History:** Past activities are saved
- [ ] **Scheduling:** Can set study schedules
- [ ] **Theme Toggle:** Light/Dark mode works
- [ ] **Language Toggle:** English/Tamil switching
- [ ] **Mobile Responsive:** Works on different screen sizes

### **API Testing:**

```bash
# Test with Thunder Client or curl

# Ping test
GET http://localhost:8080/api/ping

# File upload test
POST http://localhost:8080/api/files/upload
Content-Type: multipart/form-data
files: [select PDF file]

# AI chat test
POST http://localhost:8080/api/ai/chat
Content-Type: application/json
{
  "text": "What is photosynthesis?",
  "language": "en"
}
```

Happy coding! 🚀
