#!/usr/bin/env python3
"""
IBM Granite AI Service using Python
Enhanced implementation with IBM Granite model
"""

import json
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from typing import Dict, Any, Optional

app = Flask(__name__)
CORS(app)

# Configuration
HUGGINGFACE_TOKEN = "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"
GRANITE_MODEL = "ibm-granite/granite-3.0-8b-instruct"

class GraniteAI:
    def __init__(self):
        self.api_url = f"https://api-inference.huggingface.co/models/{GRANITE_MODEL}"
        self.headers = {
            "Authorization": f"Bearer {HUGGINGFACE_TOKEN}",
            "Content-Type": "application/json"
        }
        self.timeout = 60  # Increased timeout for better reliability
    
    def call_granite(self, prompt: str, max_tokens: int = 1000) -> str:
        """Call IBM Granite model via HuggingFace API"""
        try:
            payload = {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": max_tokens,
                    "temperature": 0.7,
                    "do_sample": True,
                    "return_full_text": False,
                    "stop": ["Human:", "User:", "Question:"]
                }
            }
            
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 503:
                # Model loading, wait and retry
                print("Model is loading, retrying...")
                import time
                time.sleep(10)
                response = requests.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=self.timeout
                )
            
            if response.status_code != 200:
                raise Exception(f"HuggingFace API error: {response.status_code} - {response.text}")
            
            result = response.json()
            
            if isinstance(result, list) and len(result) > 0:
                if "generated_text" in result[0]:
                    return result[0]["generated_text"].strip()
                elif "text" in result[0]:
                    return result[0]["text"].strip()
            elif isinstance(result, dict) and "generated_text" in result:
                return result["generated_text"].strip()
            
            raise Exception(f"Unexpected response format: {result}")
                
        except Exception as e:
            print(f"Error calling Granite model: {e}")
            raise e
    
    def build_educational_prompt(self, question: str, context: str = "", language: str = "en", answer_length: str = "2") -> str:
        """Build educational prompt for IBM Granite"""
        lang_instruction = "Please respond in Tamil language (தமிழ்)." if language == "ta" else "Please respond in English."
        
        length_instructions = {
            "1": "Provide a concise answer (1-2 sentences, suitable for 1 mark question).",
            "2": "Provide a detailed answer (1-2 paragraphs, suitable for 2 mark question).",
            "5": "Provide a comprehensive answer with examples and explanations (3-4 paragraphs, suitable for 5 mark question)."
        }
        
        length_instruction = length_instructions.get(answer_length, length_instructions["2"])
        
        context_part = f"\n\nStudy Material Context:\n{context}" if context else ""
        
        prompt = f"""You are StudyMate, an intelligent educational assistant powered by IBM Granite AI. You help students learn by providing clear, accurate, and educational answers.

{lang_instruction} {length_instruction}

Educational Guidelines:
- Provide accurate and factual information
- Use simple language appropriate for students
- Include examples when helpful
- Break down complex concepts into understandable parts
- If unsure, acknowledge limitations{context_part}

Student Question: {question}

Educational Answer:"""
        
        return prompt
    
    def build_quiz_prompt(self, context: str, language: str = "en") -> str:
        """Build prompt for quiz generation"""
        lang_instruction = "Generate the quiz in Tamil language (தமிழ்)." if language == "ta" else "Generate the quiz in English."
        
        prompt = f"""You are StudyMate, an educational assistant. {lang_instruction}

Create a comprehensive quiz based on the following study material. Include different question types to test various levels of understanding.

Study Material:
{context}

Please create:
1. **Multiple Choice Questions (2 questions)**
   - Each with 4 options (a, b, c, d)
   - Include the correct answer

2. **Fill in the Blanks (2 questions)**
   - Use underscores for blanks
   - Provide the correct answers

3. **Short Answer Questions (1 question, 2 marks)**
   - Requires brief explanation

4. **Long Answer Question (1 question, 5 marks)**
   - Requires detailed explanation

Format your response clearly with headings and proper numbering.

Quiz:"""
        
        return prompt
    
    def build_qa_generation_prompt(self, context: str, language: str = "en") -> str:
        """Build prompt for Q&A generation"""
        lang_instruction = "Generate questions and answers in Tamil language (தமிழ்)." if language == "ta" else "Generate questions and answers in English."
        
        prompt = f"""You are StudyMate, an educational assistant. {lang_instruction}

Based on the following study material, generate 5 important questions and their detailed answers that would help students understand the key concepts.

Study Material:
{context}

Create questions that:
- Test understanding of main concepts
- Cover different aspects of the material
- Range from basic to advanced difficulty
- Include both factual and analytical questions

Format:
**Q1:** [Question]
**A1:** [Detailed Answer]

**Q2:** [Question]
**A2:** [Detailed Answer]

Continue for Q3, Q4, and Q5.

Generated Questions and Answers:"""
        
        return prompt
    
    def process_request(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process AI request and return response"""
        try:
            request_type = data.get("type", "question")
            text = data.get("text", "")
            context = data.get("context", "")
            language = data.get("language", "en")
            answer_length = data.get("answerLength", "2")
            
            # Build appropriate prompt based on request type
            if request_type == "quiz" or request_type == "generate-quiz":
                prompt = self.build_quiz_prompt(context or text, language)
                max_tokens = 1500
            elif request_type == "generate_qa" or request_type == "generate-qa":
                prompt = self.build_qa_generation_prompt(context or text, language)
                max_tokens = 1500
            else:  # Default to question answering
                prompt = self.build_educational_prompt(text, context, language, answer_length)
                max_tokens = 1000
            
            # Call IBM Granite model
            response = self.call_granite(prompt, max_tokens)
            
            # Generate flowchart if applicable
            flowchart = None
            if any(keyword in text.lower() or keyword in response.lower() 
                   for keyword in ['process', 'algorithm', 'steps', 'flowchart', 'diagram', 'flow']):
                flowchart = self.generate_flowchart(text, response, language)
            
            return {
                "response": response,
                "flowchart": flowchart,
                "confidence": 0.95,
                "model": "IBM Granite 3.0 8B Instruct"
            }
            
        except Exception as e:
            print(f"Error processing request: {e}")
            return self.get_fallback_response(data)
    
    def generate_flowchart(self, topic: str, explanation: str, language: str = "en") -> Optional[str]:
        """Generate a flowchart description using IBM Granite"""
        try:
            lang_instruction = "Create flowchart in Tamil language (தமிழ்)." if language == "ta" else "Create flowchart in English."
            
            prompt = f"""Create a simple text-based flowchart for educational purposes. {lang_instruction}

Topic: {topic}
Explanation: {explanation}

Create a step-by-step flowchart using this format:
[Start] → [Step 1] → [Step 2] → [Decision?] → [Yes/No paths] → [End]

Use simple boxes and arrows. Include decision points where applicable.

Flowchart:"""
            
            return self.call_granite(prompt, 500)
        except:
            return None
    
    def get_fallback_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Provide educational fallback response when Granite model fails"""
        text = data.get("text", "")
        context = data.get("context", "")
        language = data.get("language", "en")
        
        if language == "ta":
            fallback_message = f"""மன்னிக்கவும், தற்போது AI சேவை கிடைக்கவில்லை. உங்கள் கேள்வி: "{text}"

StudyMate இங்கே உதவ தயாராக உள்ளது:
• கணிதம் மற்றும் அறிவியல் கேள்விகள்
• வரலாறு மற்றும் சமூக அறிவியல்
• மொழி மற்றும் இலக்கியம்
• குறிப்பு மற்றும் வினாக்கள் உருவாக்கம்

தயவுசெய்து உங்கள் கேள்வியை மீண்டும் கேளுங்கள்."""
        else:
            fallback_message = f"""I apologize, but the AI service is temporarily unavailable. Your question: "{text}"

StudyMate is here to help with:
• Mathematics and Science concepts
• History and Social Studies
• Language and Literature  
• Study notes and quiz generation

Please try asking your question again in a moment."""
        
        return {
            "response": fallback_message,
            "confidence": 0.5,
            "model": "StudyMate Fallback",
            "error": "AI service temporarily unavailable"
        }

# Initialize AI service
granite_ai = GraniteAI()

@app.route('/api/ai/chat', methods=['POST'])
def chat():
    """Handle chat requests"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
            
        result = granite_ai.process_request(data)
        return jsonify(result)
    except Exception as e:
        print(f"Chat endpoint error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/ai/generate-quiz', methods=['POST'])
def generate_quiz():
    """Handle quiz generation requests"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
            
        data["type"] = "generate-quiz"
        result = granite_ai.process_request(data)
        return jsonify(result)
    except Exception as e:
        print(f"Quiz generation error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/ai/generate-qa', methods=['POST'])
def generate_qa():
    """Handle Q&A generation requests"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
            
        data["type"] = "generate-qa"
        result = granite_ai.process_request(data)
        return jsonify(result)
    except Exception as e:
        print(f"Q&A generation error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy", 
        "model": GRANITE_MODEL,
        "service": "StudyMate IBM Granite AI"
    })

@app.route('/api/ping', methods=['GET'])
def ping():
    """Ping endpoint for testing"""
    return jsonify({
        "message": "StudyMate IBM Granite AI Service is running",
        "model": GRANITE_MODEL,
        "timestamp": requests.packages.urllib3.util.parse_url('https://httpbin.org/json').host
    })

if __name__ == '__main__':
    print("🚀 Starting StudyMate IBM Granite AI Service...")
    print(f"📚 Using model: {GRANITE_MODEL}")
    print(f"🌐 Service will be available at: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
