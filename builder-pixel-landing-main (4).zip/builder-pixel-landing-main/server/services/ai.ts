import { RequestHandler } from "express";

// Configuration for IBM Granite AI Service
const GRANITE_AI_SERVICE_URL =
  process.env.GRANITE_AI_SERVICE_URL || "http://localhost:5000";
const HUGGINGFACE_TOKEN = "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";

interface AIRequest {
  text: string;
  context?: string;
  language?: string;
  answerLength?: "1" | "2" | "5";
  type?: "question" | "generate_qa" | "quiz" | "explain";
}

interface AIResponse {
  response: string;
  confidence?: number;
  flowchart?: string;
}

class StudyMateAI {
  private async callGraniteAI(data: any): Promise<string> {
    try {
      console.log("🤖 Calling IBM Granite AI service...");

      const response = await fetch(`${GRANITE_AI_SERVICE_URL}/api/ai/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
        signal: AbortSignal.timeout(90000), // 90 second timeout
      });

      if (!response.ok) {
        throw new Error(`Granite AI service error: ${response.status}`);
      }

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      console.log("✅ IBM Granite AI response received");
      return result.response || "No response from AI service";
    } catch (error) {
      console.error("❌ IBM Granite AI service error:", error);
      throw error;
    }
  }

  private async generateResponse(
    prompt: string,
    context?: string,
  ): Promise<string> {
    try {
      // Try IBM Granite AI first
      const data = {
        text: prompt,
        context: context,
        type: "question",
      };

      const response = await this.callGraniteAI(data);
      return response;
    } catch (error) {
      console.error("AI generation error, using fallback:", error);
      return this.generateEducationalResponse(prompt, context);
    }
  }

  private async generateEducationalResponse(
    prompt: string,
    context?: string,
  ): Promise<string> {
    const question = this.extractQuestion(prompt);
    const questionLower = question.toLowerCase();

    // Math-related questions
    if (this.isMathQuestion(questionLower)) {
      return this.generateMathResponse(question, context);
    }

    // Science-related questions
    if (this.isScienceQuestion(questionLower)) {
      return this.generateScienceResponse(question, context);
    }

    // History-related questions
    if (this.isHistoryQuestion(questionLower)) {
      return this.generateHistoryResponse(question, context);
    }

    // General educational questions
    return this.generateGeneralResponse(question, context);
  }

  private extractQuestion(prompt: string): string {
    const questionMatch = prompt.match(/Question:\s*([^\n]+)/);
    if (questionMatch) return questionMatch[1];

    const lines = prompt.split("\n");
    for (const line of lines) {
      if (line.includes("?") || line.length > 10) {
        return line.trim();
      }
    }

    return prompt.substring(0, 200);
  }

  private isMathQuestion(question: string): boolean {
    const mathKeywords = [
      "equation",
      "solve",
      "calculate",
      "math",
      "algebra",
      "geometry",
      "formula",
      "number",
      "add",
      "subtract",
      "multiply",
      "divide",
      "quadratic",
      "linear",
      "polynomial",
      "derivative",
      "integral",
      "graph",
      "function",
      "variable",
      "coefficient",
    ];
    return mathKeywords.some((keyword) => question.includes(keyword));
  }

  private isScienceQuestion(question: string): boolean {
    const scienceKeywords = [
      "physics",
      "chemistry",
      "biology",
      "experiment",
      "theory",
      "atom",
      "molecule",
      "energy",
      "force",
      "motion",
      "mass",
      "velocity",
      "acceleration",
      "gravity",
      "chemical",
      "reaction",
      "cell",
      "organism",
      "evolution",
      "ecosystem",
      "photosynthesis",
    ];
    return scienceKeywords.some((keyword) => question.includes(keyword));
  }

  private isHistoryQuestion(question: string): boolean {
    const historyKeywords = [
      "history",
      "war",
      "revolution",
      "ancient",
      "medieval",
      "modern",
      "empire",
      "civilization",
      "culture",
      "event",
      "century",
      "independence",
      "freedom",
      "leader",
      "ruler",
      "treaty",
    ];
    return historyKeywords.some((keyword) => question.includes(keyword));
  }

  private generateMathResponse(question: string, context?: string): string {
    if (question.includes("equation") || question.includes("solve")) {
      return `To solve mathematical equations, follow these steps:

1. **Identify the type of equation** (linear, quadratic, etc.)
2. **Isolate the variable** by performing the same operation on both sides
3. **Simplify step by step** until you get the solution
4. **Check your answer** by substituting back into the original equation

For example, to solve 2x + 5 = 15:
- Subtract 5 from both sides: 2x = 10
- Divide both sides by 2: x = 5
- Check: 2(5) + 5 = 15 ✓

${context ? `\nBased on your study material: ${context.substring(0, 200)}...` : ""}

Would you like me to help with a specific equation?`;
    }

    if (question.includes("formula") || question.includes("calculate")) {
      return `Mathematical calculations require understanding the right formulas:

**Basic Formulas:**
- Area of rectangle: length × width
- Area of circle: πr²
- Distance: speed × time
- Percentage: (part/whole) × 100

**Steps for calculations:**
1. Identify what you need to find
2. Choose the appropriate formula
3. Substitute known values
4. Perform the calculation
5. Include proper units in your answer

${context ? `\nFrom your materials: ${context.substring(0, 200)}...` : ""}

What specific calculation do you need help with?`;
    }

    return `Mathematics is about understanding patterns and relationships. 

**Key problem-solving strategies:**
- Read the problem carefully
- Identify what's given and what's needed
- Choose the right method or formula
- Work step by step
- Check your answer

${context ? `\nContext from your study material: ${context.substring(0, 200)}...` : ""}

Feel free to ask about specific math topics!`;
  }

  private generateScienceResponse(question: string, context?: string): string {
    if (question.includes("experiment") || question.includes("lab")) {
      return `Scientific experiments help us understand how the world works:

**Experimental Method:**
1. **Observation** - Notice something interesting
2. **Hypothesis** - Make an educated guess
3. **Experiment** - Test your hypothesis
4. **Data Collection** - Record results carefully
5. **Analysis** - What do the results mean?
6. **Conclusion** - Accept, reject, or modify hypothesis

**Important Tips:**
- Control variables to ensure fair testing
- Repeat experiments for reliable results
- Record all observations accurately
- Safety first in all experiments

${context ? `\nFrom your study materials: ${context.substring(0, 200)}...` : ""}

What specific experiment or concept would you like to explore?`;
    }

    if (
      question.includes("force") ||
      question.includes("motion") ||
      question.includes("physics")
    ) {
      return `Physics explains how objects move and interact:

**Newton's Laws of Motion:**
1. **First Law** - Objects at rest stay at rest unless acted upon by force
2. **Second Law** - Force = Mass × Acceleration (F = ma)
3. **Third Law** - For every action, there's an equal and opposite reaction

**Key Concepts:**
- **Velocity** - speed with direction
- **Acceleration** - change in velocity over time
- **Momentum** - mass × velocity
- **Energy** - ability to do work

${context ? `\nBased on your materials: ${context.substring(0, 200)}...` : ""}

Which physics concept would you like me to explain further?`;
    }

    return `Science is about understanding the natural world through observation and experimentation.

**Main branches:**
- **Physics** - matter, energy, and their interactions
- **Chemistry** - composition and behavior of substances
- **Biology** - living organisms and life processes

**Scientific thinking involves:**
- Asking questions
- Making observations
- Forming hypotheses
- Testing ideas
- Drawing conclusions

${context ? `\nFrom your study content: ${context.substring(0, 200)}...` : ""}

What scientific topic interests you most?`;
  }

  private generateHistoryResponse(question: string, context?: string): string {
    if (question.includes("war") || question.includes("conflict")) {
      return `Historical conflicts have shaped our world:

**Major Global Conflicts:**
- **World War I (1914-1918)** - "The Great War"
- **World War II (1939-1945)** - Global struggle against fascism
- **Cold War (1947-1991)** - Ideological conflict between superpowers

**Causes of Historical Conflicts:**
- Competition for resources
- Territorial disputes
- Religious differences
- Economic interests
- Political ideologies

**Impact on Society:**
- Changes in borders and governments
- Technological advancement
- Social and cultural shifts
- Economic transformations

${context ? `\nFrom your study materials: ${context.substring(0, 200)}...` : ""}

Which historical period or event would you like to explore?`;
    }

    if (question.includes("independence") || question.includes("freedom")) {
      return `Independence movements have been crucial in shaping modern nations:

**Key Independence Movements:**
- **American Revolution (1776)** - Colonial independence from Britain
- **Indian Independence (1947)** - End of British colonial rule
- **African Decolonization (1950s-1960s)** - Multiple nations gained independence

**Common Factors:**
- Colonial oppression and exploitation
- Growing national consciousness
- Influential leaders and movements
- International support
- Economic and social pressures

**Methods Used:**
- Non-violent resistance (Gandhi's approach)
- Armed struggle
- Diplomatic negotiations
- Mass movements and protests

${context ? `\nBased on your materials: ${context.substring(0, 200)}...` : ""}

Which independence movement would you like to learn more about?`;
    }

    return `History helps us understand how past events shape our present:

**Why Study History:**
- Learn from past mistakes
- Understand current events
- Appreciate cultural heritage
- Develop critical thinking

**Historical Analysis:**
- **Chronology** - when events happened
- **Causation** - why events occurred
- **Context** - circumstances surrounding events
- **Significance** - impact and importance

**Key Skills:**
- Analyzing primary sources
- Understanding different perspectives
- Connecting past and present
- Evaluating historical evidence

${context ? `\nFrom your study content: ${context.substring(0, 200)}...` : ""}

What historical topic would you like to explore?`;
  }

  private generateGeneralResponse(question: string, context?: string): string {
    return `I'm here to help with your studies! Let me provide some guidance:

**Study Tips:**
- Break complex topics into smaller parts
- Use active learning techniques
- Practice regularly with problems
- Connect new information to what you know
- Ask questions when unsure

**How I can help:**
- Explain concepts step by step
- Create practice questions
- Generate quizzes for review
- Provide examples and analogies
- Clarify difficult topics

${context ? `\nBased on your uploaded materials: ${context.substring(0, 200)}...` : ""}

**Your Question:** "${question}"

To give you the most helpful answer, could you provide more details about:
- Which subject this relates to
- What specific aspect you're struggling with
- What level of explanation you need

Feel free to ask follow-up questions anytime!`;
  }

  private generateFallbackResponse(prompt: string): string {
    const question = this.extractQuestion(prompt);
    return `I understand you're asking: "${question}"

As your StudyMate AI assistant, I'm here to help with your educational needs. While I'm processing your question, here's how I can assist:

**I can help with:**
- Mathematics (algebra, geometry, calculus)
- Science (physics, chemistry, biology)
- History and social studies
- Language and literature
- General study skills

**For best results:**
- Be specific about your subject area
- Include any relevant context
- Let me know your grade level or course
- Ask follow-up questions for clarification

Would you like to rephrase your question or provide more context? I'm ready to help you learn!`;
  }

  async processRequest(request: AIRequest): Promise<AIResponse> {
    const {
      text,
      context,
      language = "en",
      answerLength = "2",
      type = "question",
    } = request;

    try {
      // Prepare data for IBM Granite AI service
      const graniteData = {
        text,
        context,
        language,
        answerLength,
        type,
      };

      console.log("🚀 Sending request to IBM Granite AI:", {
        type,
        language,
        answerLength,
      });

      // Call IBM Granite AI service directly
      const endpoint =
        type === "generate_qa"
          ? "/api/ai/generate-qa"
          : type === "quiz"
            ? "/api/ai/generate-quiz"
            : "/api/ai/chat";

      const response = await fetch(`${GRANITE_AI_SERVICE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(graniteData),
        signal: AbortSignal.timeout(90000),
      });

      if (!response.ok) {
        throw new Error(`Granite AI service error: ${response.status}`);
      }

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      console.log("✅ IBM Granite AI response received successfully");

      return {
        response: result.response?.trim() || "No response generated",
        confidence: result.confidence || 0.9,
        flowchart: result.flowchart,
      };
    } catch (error) {
      console.error("❌ IBM Granite AI failed, using fallback:", error);

      // Fallback to local educational responses
      let prompt = "";
      switch (type) {
        case "question":
          prompt = this.buildQuestionPrompt(
            text,
            context,
            language,
            answerLength,
          );
          break;
        case "generate_qa":
          prompt = this.buildQAGenerationPrompt(context || text, language);
          break;
        case "quiz":
          prompt = this.buildQuizPrompt(context || text, language);
          break;
        case "explain":
          prompt = this.buildExplanationPrompt(text, context, language);
          break;
        default:
          prompt = this.buildQuestionPrompt(
            text,
            context,
            language,
            answerLength,
          );
      }

      const fallbackResponse = await this.generateResponse(prompt, context);

      return {
        response: fallbackResponse.trim(),
        confidence: 0.7,
      };
    }
  }

  private buildQuestionPrompt(
    question: string,
    context?: string,
    language: string = "en",
    answerLength: string = "2",
  ): string {
    return `Question: ${question}\n\n${context ? `Context: ${context}\n\n` : ""}Language: ${language}\nAnswer Length: ${answerLength} marks`;
  }

  private buildQAGenerationPrompt(
    content: string,
    language: string = "en",
  ): string {
    // Generate Q&A based on content
    const lines = content.split("\n").filter((line) => line.trim().length > 0);
    const topics = lines.slice(0, 10); // Take first 10 lines as topics

    let qa = `**Generated Questions and Answers:**\n\n`;

    for (let i = 0; i < Math.min(5, topics.length); i++) {
      const topic = topics[i].replace(/^[-•*]\s*/, "").trim();
      if (topic.length > 10) {
        qa += `**Q${i + 1}:** What can you tell me about ${topic}?\n`;
        qa += `**A${i + 1}:** ${topic} is an important concept in this study material. `;
        qa += `It relates to the main topics covered and requires understanding of key principles. `;
        qa += `For detailed explanation, please refer to the specific section in your materials.\n\n`;
      }
    }

    if (qa === `**Generated Questions and Answers:**\n\n`) {
      qa += `**Q1:** What are the main topics covered in this material?\n`;
      qa += `**A1:** The material covers several important educational concepts that are relevant for study and examination preparation.\n\n`;

      qa += `**Q2:** How can I best understand this content?\n`;
      qa += `**A2:** Break down the material into smaller sections, practice with examples, and ask specific questions about areas you find challenging.\n\n`;
    }

    return qa;
  }

  private buildQuizPrompt(content: string, language: string = "en"): string {
    const isSimpleContent = content.length < 200;

    if (isSimpleContent) {
      return `**Quiz Based on Your Content:**

**Multiple Choice Questions:**

1. What is the main focus of this study material?
   a) Basic concepts
   b) Advanced theories
   c) Practical applications
   d) All of the above
   **Answer: d) All of the above**

2. Which approach is best for studying this content?
   a) Memorization only
   b) Understanding concepts
   c) Ignoring details
   d) Skipping examples
   **Answer: b) Understanding concepts**

**Fill in the Blanks:**

1. The key to mastering this subject is _______ and regular practice.
   **Answer: understanding**

2. When studying, it's important to _______ concepts rather than just memorize.
   **Answer: comprehend/understand**

**Short Answer (2 marks):**
Explain why understanding concepts is more important than memorization in learning.

**Long Answer (5 marks):**
Describe a comprehensive study strategy for mastering the topics covered in this material. Include methods for understanding, practicing, and retaining information.`;
    }

    return `**Quiz Generated from Your Study Material:**

**Multiple Choice Questions:**

1. Based on the content provided, what is a key concept discussed?
   a) Basic principles
   b) Advanced applications
   c) Core fundamentals
   d) All of the above
   **Answer: d) All of the above**

2. What study approach is recommended for this material?
   a) Surface reading
   b) Deep understanding
   c) Quick memorization
   d) Casual review
   **Answer: b) Deep understanding**

**Fill in the Blanks:**

1. Effective studying requires _______ understanding of core concepts.
   **Answer: thorough**

2. The material covers important _______ that students need to master.
   **Answer: topics/concepts**

**Short Answer (2 marks):**
Identify two main themes from the study material and explain their significance.

**Long Answer (5 marks):**
Analyze the key concepts presented in the material and discuss how they connect to broader understanding of the subject. Provide examples where applicable.`;
  }

  private buildExplanationPrompt(
    topic: string,
    context?: string,
    language: string = "en",
  ): string {
    return `Explain: ${topic}\n\n${context ? `Context: ${context}\n\n` : ""}Language: ${language}`;
  }
}

export const studyMateAI = new StudyMateAI();

export const handleAIRequest: RequestHandler = async (req, res) => {
  try {
    console.log(`AI request received: ${req.method} ${req.path}`);
    console.log("Request body:", JSON.stringify(req.body, null, 2));

    const request: AIRequest = req.body;

    if (!request.text && !request.context) {
      console.log("Bad request: Missing text and context");
      return res.status(400).json({
        error: "Either 'text' or 'context' is required",
      });
    }

    console.log("Processing AI request...");
    const response = await studyMateAI.processRequest(request);
    console.log("AI response generated successfully");
    res.json(response);
  } catch (error) {
    console.error("AI request failed:", error);

    // Provide helpful fallback response
    const fallbackResponse = {
      response: `I'm here to help with your studies! ${req.body?.text ? `Your question: "${req.body.text}"` : ""}\n\nI can assist with:\n- Explaining concepts\n- Solving problems\n- Creating quizzes\n- Study guidance\n\nPlease try asking your question again, and I'll do my best to help!`,
      confidence: 0.5,
    };

    console.log("Sending fallback AI response");
    res.json(fallbackResponse);
  }
};
