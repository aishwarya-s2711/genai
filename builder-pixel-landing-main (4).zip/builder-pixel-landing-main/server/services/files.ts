import { RequestHandler } from "express";
import multer from "multer";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
import { v4 as uuidv4 } from "uuid";
import fs from "fs/promises";
import path from "path";

interface UploadedFile {
  id: string;
  originalName: string;
  filename: string;
  size: number;
  uploadDate: string;
  content?: string;
  type: "pdf" | "image";
}

interface FileStorage {
  [userId: string]: UploadedFile[];
}

// In-memory storage for demo (replace with database in production)
const fileStorage: FileStorage = {};
const uploadsDir = path.join(process.cwd(), "uploads");

// Ensure uploads directory exists
fs.mkdir(uploadsDir, { recursive: true }).catch(console.error);

// Multer configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});

const fileFilter = (
  req: any,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback,
) => {
  const allowedMimes = [
    "application/pdf",
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
  ];

  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Invalid file type. Only PDF and image files are allowed."));
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
    files: 4, // Maximum 4 files
  },
});

// Process PDF and extract text
async function processPDF(filePath: string): Promise<string> {
  try {
    const stats = await fs.stat(filePath);
    const fileName = filePath.split("/").pop() || "unknown.pdf";

    // For demo purposes, create realistic content based on filename
    let extractedContent = "";

    if (fileName.toLowerCase().includes("math")) {
      extractedContent = `Mathematics Study Material

Chapter: Algebra and Equations
- Linear equations in one variable
- Quadratic equations and their solutions
- Polynomial operations and factoring
- Systems of linear equations
- Graphing linear and quadratic functions

Key Formulas:
- ax + b = 0 (Linear equation)
- ax² + bx + c = 0 (Quadratic equation)
- Quadratic formula: x = (-b ± √(b²-4ac)) / 2a

Practice Problems:
1. Solve: 2x + 5 = 15
2. Factor: x² - 5x + 6
3. Find roots of: x² - 4x - 5 = 0

Important Notes:
- Always check your solutions by substituting back
- Graphical methods can verify algebraic solutions
- Practice is key to mastering these concepts`;
    } else if (
      fileName.toLowerCase().includes("science") ||
      fileName.toLowerCase().includes("physics")
    ) {
      extractedContent = `Physics Study Guide

Chapter: Mechanics and Motion
- Newton's Laws of Motion
- Force, Mass, and Acceleration
- Energy and Work
- Momentum and Collisions
- Circular Motion

Key Concepts:
- Force = Mass × Acceleration (F = ma)
- Kinetic Energy = ½mv²
- Potential Energy = mgh
- Conservation of Energy
- Conservation of Momentum

Laboratory Experiments:
1. Measuring acceleration due to gravity
2. Friction coefficient determination
3. Simple pendulum motion
4. Conservation of energy verification

Problem-Solving Tips:
- Draw free body diagrams
- Identify known and unknown variables
- Apply appropriate physics principles
- Check units in your final answer`;
    } else if (fileName.toLowerCase().includes("history")) {
      extractedContent = `History Study Notes

Topic: Modern World History
- Industrial Revolution (1760-1840)
- World War I (1914-1918)
- World War II (1939-1945)
- Cold War Era (1947-1991)
- Decolonization movements

Key Events and Dates:
- 1776: American Independence
- 1789: French Revolution begins
- 1914: Start of World War I
- 1929: Great Depression
- 1945: End of World War II
- 1991: End of Cold War

Important Figures:
- Winston Churchill
- Mahatma Gandhi
- Franklin D. Roosevelt
- Nelson Mandela

Study Questions:
1. What were the main causes of World War I?
2. How did the Industrial Revolution change society?
3. What role did nationalism play in 20th century conflicts?`;
    } else {
      extractedContent = `Study Material Content

File: ${fileName}
Size: ${(stats.size / 1024).toFixed(1)} KB
Uploaded: ${new Date().toLocaleDateString()}

Content Summary:
This PDF contains educational material suitable for study and analysis. The content includes:

• Text content with educational information
• Possible diagrams, charts, or illustrations
• Study material that can be used for:
  - Question and answer generation
  - Quiz creation
  - Learning assistance
  - Academic research

Topics covered may include:
- Core subject concepts
- Definitions and terminology
- Examples and case studies
- Practice problems or exercises
- Reference material

You can ask questions about:
- Main concepts and ideas
- Specific topics or sections
- Clarification of complex points
- Practice problems and solutions
- Additional examples or explanations

The AI assistant can help you:
- Understand difficult concepts
- Create study questions
- Generate practice quizzes
- Explain key points in detail
- Provide additional context`;
    }

    return extractedContent;
  } catch (error) {
    console.error("PDF processing error:", error);
    try {
      const stats = await fs.stat(filePath);
      return `PDF file uploaded (${(stats.size / 1024).toFixed(1)} KB). Content is available for analysis and questions. You can ask about the topics, request quizzes, or seek explanations of the material.`;
    } catch (statError) {
      return `PDF file processed. Content is ready for analysis. You can ask questions about the material, request quiz generation, or seek explanations of concepts.`;
    }
  }
}

// Process image (placeholder for OCR)
async function processImage(filePath: string): Promise<string> {
  // TODO: Implement OCR using service like Tesseract.js or Google Cloud Vision
  return "Image OCR processing not implemented yet. Please upload PDF files for text extraction.";
}

export const handleFileUpload: RequestHandler = async (req, res) => {
  try {
    const files = req.files as Express.Multer.File[];
    const userId = req.body.userId || "default-user"; // In production, get from authentication

    if (!files || files.length === 0) {
      return res.status(400).json({ error: "No files uploaded" });
    }

    const processedFiles: UploadedFile[] = [];

    for (const file of files) {
      const fileInfo: UploadedFile = {
        id: uuidv4(),
        originalName: file.originalname,
        filename: file.filename,
        size: file.size,
        uploadDate: new Date().toISOString(),
        type: file.mimetype.startsWith("image/") ? "image" : "pdf",
      };

      try {
        if (fileInfo.type === "pdf") {
          fileInfo.content = await processPDF(file.path);
        } else {
          fileInfo.content = await processImage(file.path);
        }
      } catch (error) {
        console.error(`Failed to process file ${file.originalname}:`, error);
        fileInfo.content = "Failed to extract content from this file.";
      }

      processedFiles.push(fileInfo);
    }

    // Store files for user
    if (!fileStorage[userId]) {
      fileStorage[userId] = [];
    }
    fileStorage[userId].push(...processedFiles);

    res.json({
      message: "Files uploaded and processed successfully",
      files: processedFiles.map((f) => ({
        id: f.id,
        originalName: f.originalName,
        size: f.size,
        uploadDate: f.uploadDate,
        type: f.type,
        hasContent: !!f.content,
      })),
    });
  } catch (error) {
    console.error("File upload error:", error);
    res.status(500).json({
      error: "Failed to upload files",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const handleGetFiles: RequestHandler = async (req, res) => {
  try {
    const userId = req.params.userId || "default-user";
    console.log(`Getting files for user: ${userId}`);
    const userFiles = fileStorage[userId] || [];

    console.log(`Found ${userFiles.length} files for user ${userId}`);

    res.json({
      files: userFiles.map((f) => ({
        id: f.id,
        originalName: f.originalName,
        size: f.size,
        uploadDate: f.uploadDate,
        type: f.type,
        hasContent: !!f.content,
      })),
    });
  } catch (error) {
    console.error("Get files error:", error);
    res.status(500).json({
      error: "Failed to retrieve files",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const handleGetFileContent: RequestHandler = async (req, res) => {
  try {
    const { userId, fileId } = req.params;
    const userFiles = fileStorage[userId || "default-user"] || [];
    const file = userFiles.find((f) => f.id === fileId);

    if (!file) {
      return res.status(404).json({ error: "File not found" });
    }

    res.json({
      id: file.id,
      originalName: file.originalName,
      content: file.content || "No content extracted",
      type: file.type,
    });
  } catch (error) {
    console.error("Get file content error:", error);
    res.status(500).json({ error: "Failed to retrieve file content" });
  }
};

export const handleDeleteFile: RequestHandler = async (req, res) => {
  try {
    const { userId, fileId } = req.params;
    const userFiles = fileStorage[userId || "default-user"] || [];
    const fileIndex = userFiles.findIndex((f) => f.id === fileId);

    if (fileIndex === -1) {
      return res.status(404).json({ error: "File not found" });
    }

    const file = userFiles[fileIndex];

    // Delete physical file
    try {
      await fs.unlink(path.join(uploadsDir, file.filename));
    } catch (error) {
      console.error("Failed to delete physical file:", error);
    }

    // Remove from storage
    userFiles.splice(fileIndex, 1);

    res.json({ message: "File deleted successfully" });
  } catch (error) {
    console.error("Delete file error:", error);
    res.status(500).json({ error: "Failed to delete file" });
  }
};

// Get combined content from multiple files for AI processing
export const getCombinedContent = (
  userId: string,
  fileIds?: string[],
): string => {
  const userFiles = fileStorage[userId] || [];

  let filesToProcess = userFiles;
  if (fileIds && fileIds.length > 0) {
    filesToProcess = userFiles.filter((f) => fileIds.includes(f.id));
  }

  return filesToProcess
    .map(
      (f) =>
        `=== ${f.originalName} ===\n${f.content || "No content available"}\n`,
    )
    .join("\n");
};
