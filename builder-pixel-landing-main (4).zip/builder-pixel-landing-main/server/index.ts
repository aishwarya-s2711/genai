import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleAIRequest } from "./services/ai";
import {
  upload,
  handleFileUpload,
  handleGetFiles,
  handleGetFileContent,
  handleDeleteFile,
  getCombinedContent,
} from "./services/files";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Request logging middleware
  app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
  });

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // AI Routes
  app.post("/api/ai/chat", handleAIRequest);
  app.post("/api/ai/generate-qa", (req, res, next) => {
    req.body.type = "generate_qa";
    handleAIRequest(req, res, next);
  });
  app.post("/api/ai/generate-quiz", (req, res, next) => {
    req.body.type = "quiz";
    handleAIRequest(req, res, next);
  });

  // File Upload Routes
  app.post("/api/files/upload", upload.array("files", 4), handleFileUpload);
  app.get("/api/files/:userId", handleGetFiles);
  app.get("/api/files/:userId/:fileId", handleGetFileContent);
  app.delete("/api/files/:userId/:fileId", handleDeleteFile);

  // Combined content for AI processing
  app.post("/api/files/combined-content", (req, res) => {
    try {
      const { userId, fileIds } = req.body;
      const content = getCombinedContent(userId || "default-user", fileIds);
      res.json({ content });
    } catch (error) {
      console.error("Combined content error:", error);
      res.status(500).json({ error: "Failed to get combined content" });
    }
  });

  // Log all API requests for debugging
  app.use((req, res, next) => {
    if (req.path.startsWith("/api")) {
      console.log(`API request: ${req.method} ${req.path}`);
    }
    next();
  });

  // Global error handler
  app.use((error: any, req: any, res: any, next: any) => {
    console.error("Server error:", error);
    res.status(500).json({
      error: "Internal server error",
      message: error.message,
    });
  });

  return app;
}
