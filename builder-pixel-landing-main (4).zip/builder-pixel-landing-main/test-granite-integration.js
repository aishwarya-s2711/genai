#!/usr/bin/env node

/**
 * Test script for IBM Granite AI integration
 * This script tests the connection between Node.js and Python services
 */

const fetch = require("node-fetch").default || require("node-fetch");

const GRANITE_SERVICE_URL = "http://localhost:5000";
const NODE_SERVICE_URL = "http://localhost:8080";

console.log("🧪 Testing IBM Granite AI Integration...\n");

async function testGraniteService() {
  try {
    console.log("🔍 Testing Python Granite AI service...");

    // Test health endpoint
    const healthResponse = await fetch(`${GRANITE_SERVICE_URL}/health`);
    if (!healthResponse.ok) {
      throw new Error(`Health check failed: ${healthResponse.status}`);
    }

    const healthData = await healthResponse.json();
    console.log("✅ Granite AI service health:", healthData);

    // Test chat endpoint
    const chatResponse = await fetch(`${GRANITE_SERVICE_URL}/api/ai/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: "What is photosynthesis?",
        language: "en",
        answerLength: "2",
      }),
    });

    if (!chatResponse.ok) {
      throw new Error(`Chat test failed: ${chatResponse.status}`);
    }

    const chatData = await chatResponse.json();
    console.log("✅ Granite AI chat test successful");
    console.log(
      "📝 Response preview:",
      chatData.response?.substring(0, 100) + "...",
    );

    return true;
  } catch (error) {
    console.error("❌ Granite AI service test failed:", error.message);
    return false;
  }
}

async function testNodeService() {
  try {
    console.log("\n🔍 Testing Node.js service...");

    // Test ping endpoint
    const pingResponse = await fetch(`${NODE_SERVICE_URL}/api/ping`);
    if (!pingResponse.ok) {
      throw new Error(`Ping failed: ${pingResponse.status}`);
    }

    const pingData = await pingResponse.json();
    console.log("✅ Node.js service health:", pingData);

    // Test AI integration through Node.js
    const aiResponse = await fetch(`${NODE_SERVICE_URL}/api/ai/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: "What is gravity?",
        language: "en",
        answerLength: "2",
      }),
    });

    if (!aiResponse.ok) {
      throw new Error(`AI integration test failed: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    console.log("✅ Node.js AI integration test successful");
    console.log(
      "📝 Response preview:",
      aiData.response?.substring(0, 100) + "...",
    );

    return true;
  } catch (error) {
    console.error("❌ Node.js service test failed:", error.message);
    return false;
  }
}

async function runTests() {
  console.log("🚀 Starting IBM Granite AI Integration Tests\n");

  const graniteOk = await testGraniteService();
  const nodeOk = await testNodeService();

  console.log("\n📊 Test Results:");
  console.log(`🤖 Granite AI Service: ${graniteOk ? "✅ PASS" : "❌ FAIL"}`);
  console.log(`🌐 Node.js Service: ${nodeOk ? "✅ PASS" : "❌ FAIL"}`);

  if (graniteOk && nodeOk) {
    console.log(
      "\n🎉 All tests passed! IBM Granite AI integration is working correctly.",
    );
    console.log("💡 You can now use StudyMate with IBM Granite AI features.");
  } else {
    console.log(
      "\n⚠️  Some tests failed. Please check the services are running:",
    );
    console.log("   - Python service: python3 python_ai_service.py");
    console.log("   - Node.js service: npm run dev");
  }

  console.log("\n🔗 Useful URLs:");
  console.log(`   🌐 StudyMate App: ${NODE_SERVICE_URL}`);
  console.log(`   🤖 Granite AI Service: ${GRANITE_SERVICE_URL}/health`);
  console.log(`   🧪 API Test Page: ${NODE_SERVICE_URL}/api-test.html`);
}

// Handle unhandled rejections
process.on("unhandledRejection", (error) => {
  console.error("❌ Unhandled error:", error.message);
  process.exit(1);
});

// Run the tests
runTests().catch((error) => {
  console.error("❌ Test runner failed:", error.message);
  process.exit(1);
});
