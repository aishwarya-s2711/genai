# IBM Granite AI Integration for StudyMate

This document explains how to run StudyMate with IBM Granite AI model integration.

## 🤖 About IBM Granite AI

StudyMate now uses IBM Granite 3.0 8B Instruct model through HuggingFace Inference API for:

- **Intelligent Question Answering** - Natural language responses to student questions
- **Quiz Generation** - Automatic creation of multiple choice, fill-in-the-blank, and essay questions
- **Q&A Generation** - Generate practice questions from study materials
- **Multi-language Support** - English and Tamil language support
- **Educational Flowcharts** - Visual learning aids for complex processes

## 🚀 Quick Start

### Option 1: Automatic Setup (Recommended)

```bash
# Install Python dependencies and start both services
npm run granite:start
```

### Option 2: Manual Setup

1. **Install Python Dependencies**

   ```bash
   pip3 install -r requirements.txt
   ```

2. **Start IBM Granite AI Service**

   ```bash
   # In terminal 1
   python3 python_ai_service.py
   ```

3. **Start Node.js Development Server**
   ```bash
   # In terminal 2
   npm run dev
   ```

## 📋 Prerequisites

- **Python 3.8+** - For running the IBM Granite AI service
- **Node.js 18+** - For the main StudyMate application
- **Internet Connection** - Required for HuggingFace API calls

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
# IBM Granite AI Configuration
GRANITE_AI_SERVICE_URL=http://localhost:5000
HUGGINGFACE_TOKEN=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
```

### Python Service Configuration

The Python service runs on port `5000` by default. You can modify this in `python_ai_service.py`:

```python
# Change port if needed
app.run(host='0.0.0.0', port=5000, debug=True)
```

## 🌐 Service Endpoints

### Main Application

- **StudyMate App**: http://localhost:8080
- **API Test Page**: http://localhost:8080/api-test.html

### IBM Granite AI Service

- **Health Check**: http://localhost:5000/health
- **Chat API**: http://localhost:5000/api/ai/chat
- **Quiz Generation**: http://localhost:5000/api/ai/generate-quiz
- **Q&A Generation**: http://localhost:5000/api/ai/generate-qa

## 🧪 Testing the Integration

1. **Open the API test page**: http://localhost:8080/api-test.html
2. **Test AI Chat**: Click "Test AI Chat" button
3. **Test Quiz Generation**: Click "Test Quiz Generation" button
4. **Test Q&A Generation**: Click "Test Q&A Generation" button

## 🔄 Fallback System

If the IBM Granite AI service is unavailable, StudyMate automatically falls back to:

- Built-in educational response system
- Pattern-based question answering
- Local quiz generation templates

## 📚 Usage Examples

### Question Answering

```json
POST /api/ai/chat
{
  "text": "What is photosynthesis?",
  "language": "en",
  "answerLength": "2"
}
```

### Quiz Generation

```json
POST /api/ai/generate-quiz
{
  "context": "Photosynthesis is the process by which plants make food using sunlight, water, and carbon dioxide.",
  "language": "en"
}
```

### Tamil Language Support

```json
POST /api/ai/chat
{
  "text": "ஒளிச்சேர்க்கை என்றால் என்ன?",
  "language": "ta",
  "answerLength": "2"
}
```

## 🛠️ Troubleshooting

### Common Issues

**1. Python Service Won't Start**

```bash
# Check Python version
python3 --version

# Install dependencies
pip3 install -r requirements.txt

# Run service manually
python3 python_ai_service.py
```

**2. API Connection Failed**

- Check if Python service is running on port 5000
- Verify `GRANITE_AI_SERVICE_URL` in environment variables
- Check firewall settings

**3. HuggingFace API Errors**

- Verify internet connection
- Check HuggingFace token validity
- Model may be loading (wait 10-20 seconds and retry)

**4. Timeout Errors**

- IBM Granite model may take time to load initially
- Increase timeout in `python_ai_service.py` if needed

### Debug Mode

Enable detailed logging by setting debug mode:

```python
# In python_ai_service.py
app.run(host='0.0.0.0', port=5000, debug=True)
```

## 🔒 Security Notes

- The provided HuggingFace token is for demonstration purposes
- For production use, generate your own token at https://huggingface.co/settings/tokens
- Store sensitive tokens in environment variables, not in code

## 📊 Performance

- **First Request**: 10-30 seconds (model loading)
- **Subsequent Requests**: 2-5 seconds
- **Concurrent Requests**: Supported with queuing
- **Rate Limits**: Based on HuggingFace free tier limits

## 🚀 Deployment

For production deployment:

1. **Use a dedicated server** for the Python AI service
2. **Set up proper environment variables**
3. **Configure reverse proxy** (nginx/Apache)
4. **Enable HTTPS** for secure communication
5. **Set up monitoring** for both services

## 🆘 Support

If you encounter issues:

1. Check the console logs in both services
2. Test API endpoints manually using the test page
3. Verify all dependencies are installed correctly
4. Ensure both services can communicate

## 🎯 Next Steps

- **Fine-tune prompts** for better educational responses
- **Add more language support** (Hindi, Spanish, etc.)
- **Implement caching** for frequently asked questions
- **Add voice synthesis** for audio responses
- **Create subject-specific models** for specialized content

---

**Happy Learning with IBM Granite AI! 🎓🤖**
