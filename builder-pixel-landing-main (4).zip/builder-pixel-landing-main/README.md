# StudyMate - AI Learning Assistant with IBM Granite AI

🤖 **Powered by IBM Granite 3.0 8B Instruct Model** for intelligent educational assistance

## 🚀 How to Run in VS Code

### Prerequisites

Before starting, make sure you have these installed:

```bash
# Check if Node.js is installed (version 18+ required)
node --version

# Check if npm is installed
npm --version

# If not installed, download from: https://nodejs.org/
```

### 1. Open in VS Code

```bash
# Clone the repository (if not already done)
git clone <your-repo-url>
cd studymate

# Open in VS Code
code .
```

### 2. Install Dependencies

```bash
# Install all project dependencies
npm install

# This will install both frontend and backend dependencies
# Check package.json for all dependencies
```

### 3. Environment Setup (Optional)

```bash
# Create environment file if needed
touch .env

# Add any environment variables (currently not required)
# PING_MESSAGE=hello
# GRANITE_AI_SERVICE_URL=http://localhost:5000
```

### 4. Run with IBM Granite AI (Recommended)

```bash
# Option 1: Automatic setup (recommended)
npm run granite:start

# Option 2: Manual setup
# Terminal 1 - Start IBM Granite AI service
python3 python_ai_service.py

# Terminal 2 - Start main application
npm run dev
```

### 4. Run Standard Mode (Without IBM Granite AI)

```bash
# Start the development server
npm run dev

# This command does the following:
# - Starts Vite development server for frontend (React + TypeScript)
# - Starts Express server for backend APIs
# - Enables hot reload for both frontend and backend
# - Opens browser automatically to http://localhost:8080
```

### Alternative Commands:

```bash
# Run only frontend (Vite dev server)
npm run dev:client

# Run only backend (Express server)
npm run dev:server

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📁 Project Structure

```
studymate/
├── client/                 # Frontend React application
│   ├── components/         # Reusable UI components
│   │   ├── ui/            # Shadcn/ui components
│   │   └── Header.tsx     # Main navigation header
│   ├── hooks/             # Custom React hooks
│   │   ├── use-voice.ts   # Voice recognition & synthesis
│   │   └── use-toast.ts   # Toast notifications
│   ├── lib/               # Utility libraries
│   │   ├── contexts.tsx   # Theme & Language contexts
│   │   └── utils.ts       # Helper functions
│   ├── pages/             # Application pages/routes
│   │   ├── Auth.tsx       # Login/Register page
│   │   ├── Home.tsx       # Dashboard/landing page
│   │   ├── UploadPDF.tsx  # PDF upload & analysis
│   │   ├── UploadPicture.tsx # Image upload & analysis
│   │   ├── AskQuestions.tsx  # Q&A chat interface
│   │   ├── History.tsx    # User activity history
│   │   ├── Schedule.tsx   # Study scheduling
│   │   └── RatingFeedback.tsx # User feedback
│   ├── App.tsx            # Main app component
│   └─��� global.css         # Global styles (Tailwind)
├── server/                # Backend Express application
│   ├── services/          # Business logic services
│   │   ├── ai.ts         # AI/Chat functionality with Granite integration
│   │   └── files.ts      # File upload/processing
│   ├── routes/           # API route handlers
│   └── index.ts          # Express server setup
├── python_ai_service.py  # IBM Granite AI service (Python)
├── requirements.txt      # Python dependencies
├── start-granite-ai.sh   # Startup script for Granite AI
├── GRANITE_AI_SETUP.md   # Granite AI integration guide
├── shared/               # Shared utilities between client/server
├── public/               # Static assets
├── package.json          # Dependencies and scripts
├── vite.config.ts        # Vite configuration
├── tailwind.config.ts    # Tailwind CSS configuration
└── tsconfig.json         # TypeScript configuration
```

## 🔧 VS Code Setup & Extensions

### Recommended Extensions:

1. **TypeScript and JavaScript Language Features** (Built-in)
2. **ES7+ React/Redux/React-Native snippets**
3. **Tailwind CSS IntelliSense**
4. **Auto Rename Tag**
5. **Prettier - Code formatter**
6. **ESLint**
7. **GitLens**
8. **Thunder Client** (for API testing)

### Install Extensions:

```bash
# Open VS Code Quick Open (Ctrl+P) and paste these commands:
ext install ms-vscode.vscode-typescript-next
ext install dsznajder.es7-react-js-snippets
ext install bradlc.vscode-tailwindcss
ext install formulahendry.auto-rename-tag
ext install esbenp.prettier-vscode
ext install dbaeumer.vscode-eslint
ext install eamodio.gitlens
ext install rangav.vscode-thunder-client
```

### VS Code Settings (`.vscode/settings.json`):

```json
{
  "typescript.preferences.importModuleSpecifier": "relative",
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "tailwindCSS.includeLanguages": {
    "typescript": "javascript",
    "typescriptreact": "javascript"
  },
  "files.associations": {
    "*.css": "tailwindcss"
  }
}
```

## 🐛 Debugging Setup

### Debug Configuration (`.vscode/launch.json`):

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Debug Frontend",
      "type": "chrome",
      "request": "launch",
      "url": "http://localhost:8080",
      "webRoot": "${workspaceFolder}/client",
      "sourceMapPathOverrides": {
        "webpack:///./src/*": "${webRoot}/*"
      }
    },
    {
      "name": "Debug Backend",
      "type": "node",
      "request": "launch",
      "program": "${workspaceFolder}/server/index.ts",
      "outFiles": ["${workspaceFolder}/dist/**/*.js"],
      "runtimeArgs": ["-r", "ts-node/register"],
      "env": {
        "NODE_ENV": "development"
      }
    }
  ]
}
```

## 🤖 IBM Granite AI Features

StudyMate integrates IBM Granite 3.0 8B Instruct model for enhanced educational AI capabilities:

### ✨ AI-Powered Features:

- **🧠 Intelligent Question Answering** - Natural language responses to any educational question
- **📝 Automatic Quiz Generation** - Create multiple choice, fill-in-the-blank, and essay questions
- **❓ Q&A Generation** - Generate practice questions from study materials
- **🌍 Multi-language Support** - English and Tamil (தமிழ்) language support
- **📊 Educational Flowcharts** - Visual learning aids for complex processes
- **🎯 Context-Aware Responses** - Answers based on uploaded PDF content

### 🔄 Fallback System:

- **Primary**: IBM Granite AI via HuggingFace API
- **Fallback**: Built-in educational response system
- **Offline Mode**: Local pattern-based responses

### 🚀 Performance:

- **Model**: IBM Granite 3.0 8B Instruct
- **Response Time**: 2-5 seconds (after initial load)
- **Languages**: English, Tamil (தமிழ்)
- **Context Length**: Up to 8K tokens
- **Confidence Scoring**: AI confidence levels for responses

## 🚀 Quick Start Guide

### Step-by-Step:

1. **Open Terminal in VS Code** (`Ctrl + ` ` or View → Terminal)

2. **Install Dependencies:**

   ```bash
   npm install
   ```

3. **Start Development Server:**

   ```bash
   npm run dev
   ```

4. **Open Browser:**
   - Automatic: Browser should open to `http://localhost:8080`
   - Manual: Navigate to `http://localhost:8080`

5. **Start Developing:**
   - Frontend code: Edit files in `client/` folder
   - Backend code: Edit files in `server/` folder
   - Changes auto-reload thanks to Vite and nodemon

## 📝 Key Features to Test

### 1. **Authentication**

- Go to `/auth` to test login/register
- User data stored in localStorage

### 2. **PDF Upload & Analysis**

- Go to `/upload-pdf`
- Upload PDF files (max 4, up to 10MB each)
- Get AI-powered analysis and summaries
- Ask questions about PDF content

### 3. **Image Upload & Analysis**

- Go to `/upload-picture`
- Upload images (max 4)
- Get intelligent content analysis
- Generate quizzes from images

### 4. **AI Chat Interface**

- Go to `/ask-questions`
- Chat with AI assistant
- Voice input/output support
- Multi-language support (English/Tamil)

### 5. **Quiz Generation**

- Upload content first
- Generate multiple choice, fill-in-blanks, short/long answer questions
- Save to history

### 6. **History & Scheduling**

- `/history` - View past activities
- `/schedule` - Set study schedules with notifications

## 🛠 Development Tips

### File Watching:

```bash
# Both frontend and backend auto-reload on file changes
# Frontend: Vite HMR (Hot Module Replacement)
# Backend: Nodemon restarts server on changes
```

### API Testing:

```bash
# Use Thunder Client extension or curl
# Example API endpoints:
curl http://localhost:8080/api/ping
curl http://localhost:8080/api/files/default-user
```

### Database:

```bash
# Currently uses localStorage for demo
# No external database required
# File uploads stored in ./uploads/ folder
```

### Environment Variables:

```bash
# Optional .env file:
PING_MESSAGE=hello
# Add more as needed
```

## 🐞 Common Issues & Solutions

### Port Already in Use:

```bash
# Kill process on port 8080
npx kill-port 8080

# Or use different port
PORT=3000 npm run dev
```

### Dependencies Issues:

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### TypeScript Errors:

```bash
# Restart TypeScript server in VS Code
Ctrl+Shift+P → "TypeScript: Restart TS Server"
```

### Build Issues:

```bash
# Clean build
npm run build

# Check for errors
npm run type-check
```

## 📚 Technology Stack

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS
- **Backend:** Express.js, Node.js, TypeScript
- **UI Components:** Shadcn/ui, Radix UI
- **State Management:** React Context API
- **File Handling:** Multer (backend), File API (frontend)
- **Voice Features:** Web Speech API
- **AI Integration:** Custom service with fallbacks
- **Storage:** localStorage (client), File system (server)

## 🔄 Development Workflow

1. **Make Changes:** Edit files in VS Code
2. **Auto Reload:** See changes instantly in browser
3. **Debug:** Use browser dev tools or VS Code debugger
4. **Test APIs:** Use Thunder Client or Postman
5. **Commit:** Use Git integration in VS Code
6. **Deploy:** Build and deploy to your preferred platform

## 📞 Support

If you encounter issues:

1. Check the browser console for errors
2. Check VS Code terminal for server errors
3. Verify all dependencies are installed
4. Ensure Node.js version is 18+
5. Clear browser cache and localStorage

Happy coding! 🚀
